using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using RimWorld;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(BillStack), "DoListing")]
public static class Patch_BillStack_DoListing_Patches
{
	public delegate FloatMenuOption GenerateSurgeryOptionDelegate(Pawn pawn, Thing thingForMedBills, RecipeDef recipe, IEnumerable<ThingDef> missingIngredients, AcceptanceReport report, int index, BodyPartRecord part = null);

	public static GenerateSurgeryOptionDelegate method_GenerateSurgeryOptionDelegate;

	public static AccessTools.FieldRef<FloatMenuOption, string> field_FloatMenuOption_label;

	static Patch_BillStack_DoListing_Patches()
	{
		method_GenerateSurgeryOptionDelegate = AccessTools.MethodDelegate<GenerateSurgeryOptionDelegate>(AccessTools.Method(typeof(HealthCardUtility), "GenerateSurgeryOption"));
		field_FloatMenuOption_label = AccessTools.FieldRefAccess<string>(typeof(FloatMenuOption), "labelInt");
	}

	[HarmonyPrefix]
	public static void Prefix(BillStack __instance, ref Func<List<FloatMenuOption>> recipeOptionsMaker)
	{
		Func<List<FloatMenuOption>> oldRecipeOptionsMaker = recipeOptionsMaker;
		Func<List<FloatMenuOption>> newRecipeOptionsMaker = delegate
		{
			List<FloatMenuOption> list = oldRecipeOptionsMaker();
			IBillGiver billGiver = __instance.billGiver;
			if (billGiver is Pawn pawn)
			{
				List<FloatMenuOption> avaiableExperimentalSurgeryOptions = GetAvaiableExperimentalSurgeryOptions(pawn, pawn);
				if (!avaiableExperimentalSurgeryOptions.NullOrEmpty())
				{
					if (list.Count == 1 && list[0].Label == "NoneBrackets".Translate())
					{
						list.RemoveAt(0);
					}
					list.AddRange(avaiableExperimentalSurgeryOptions);
				}
			}
			else
			{
				List<FloatMenuOption> availablePrototypeOptions = GetAvailablePrototypeOptions(billGiver);
				if (!availablePrototypeOptions.NullOrEmpty())
				{
					if (list.Count == 1 && list[0].Label == "NoneBrackets".Translate())
					{
						list.RemoveAt(0);
					}
					list.AddRange(availablePrototypeOptions);
				}
			}
			return list;
		};
		recipeOptionsMaker = newRecipeOptionsMaker;
	}

	public static List<FloatMenuOption> GetAvaiableExperimentalSurgeryOptions(Pawn pawn, Thing thingForMedBills)
	{
		List<FloatMenuOption> list = new List<FloatMenuOption>();
		int index = 0;
		foreach (RecipeDef recipe in thingForMedBills.def.AllRecipes)
		{
			if (!recipe.IsAvailableOnlyForPrototyping())
			{
				continue;
			}
			AcceptanceReport report = recipe.Worker.AvailableReport(pawn);
			if (!report.Accepted && report.Reason.NullOrEmpty())
			{
				continue;
			}
			IEnumerable<ThingDef> missingIngredients = recipe.PotentiallyMissingIngredients(null, thingForMedBills.MapHeld);
			if (missingIngredients.Any((ThingDef x) => x.isTechHediff) || missingIngredients.Any((ThingDef x) => x.IsDrug) || (missingIngredients.Any() && recipe.dontShowIfAnyIngredientMissing))
			{
				continue;
			}
			if (recipe.targetsBodyPart)
			{
				foreach (BodyPartRecord part in recipe.Worker.GetPartsToApplyOn(pawn, recipe))
				{
					if (recipe.AvailableOnNow(pawn, part))
					{
						FloatMenuOption option = method_GenerateSurgeryOptionDelegate(pawn, thingForMedBills, recipe, missingIngredients, report, index, part);
						field_FloatMenuOption_label(option) = "RR_ExperimentalSurgeryPrefix".Translate() + " " + field_FloatMenuOption_label(option);
						list.Add(option);
						index++;
					}
				}
			}
			else
			{
				FloatMenuOption option2 = method_GenerateSurgeryOptionDelegate(pawn, thingForMedBills, recipe, missingIngredients, report, index);
				field_FloatMenuOption_label(option2) = "RR_ExperimentalSurgeryPrefix".Translate() + " " + field_FloatMenuOption_label(option2);
				list.Add(option2);
				index++;
			}
		}
		return list;
	}

	public static List<FloatMenuOption> GetAvailablePrototypeOptions(IBillGiver billGiver)
	{
		Thing asThing = billGiver as Thing;
		if (asThing == null)
		{
			return null;
		}
		List<FloatMenuOption> retList = new List<FloatMenuOption>();
		foreach (RecipeDef recipe in asThing.def.AllRecipes)
		{
			if (!recipe.IsAvailableOnlyForPrototyping() || !recipe.AvailableOnNow(asThing))
			{
				continue;
			}
			FloatMenuOption option = new FloatMenuOption("RR_PrototypePrefix".Translate() + " " + recipe.LabelCap, delegate
			{
				OnClick(billGiver, asThing, recipe, null);
			}, recipe.UIIconThing, null, forceBasicStyle: false, MenuOptionPriority.Default, null, null, 29f, (Rect rect) => ExtraPartOnGUI(rect, recipe, null));
			retList.Add(option);
			foreach (Ideo ideo in Faction.OfPlayer.ideos.AllIdeos)
			{
				foreach (Precept_Building precept_Building in ideo.cachedPossibleBuildings)
				{
					if (precept_Building.ThingDef == recipe.ProducedThingDef)
					{
						FloatMenuOption preceptOption = new FloatMenuOption("RR_PrototypePrefix".Translate() + " " + "RecipeMake".Translate(precept_Building.def.LabelCap).CapitalizeFirst(), delegate
						{
							OnClick(billGiver, asThing, recipe, precept_Building);
						}, recipe.UIIconThing, null, forceBasicStyle: false, MenuOptionPriority.Default, null, null, 29f, (Rect rect) => ExtraPartOnGUI(rect, recipe, precept_Building));
						retList.Add(option);
					}
				}
			}
		}
		return retList;
	}

	public static void OnClick(IBillGiver asBillGiver, Thing asThing, RecipeDef recipe, Precept_ThingStyle precept)
	{
		List<Pawn> freeColonists = asThing.Map.mapPawns.FreeColonists;
		if (!freeColonists.Any((Pawn p) => recipe.PawnSatisfiesSkillRequirements(p)))
		{
			Bill.CreateNoPawnsWithSkillDialog(recipe);
		}
		Bill bill = recipe.MakeNewBill(precept);
		asBillGiver.BillStack.AddBill(bill);
		if (recipe.conceptLearned != null)
		{
			PlayerKnowledgeDatabase.KnowledgeDemonstrated(recipe.conceptLearned, KnowledgeAmount.Total);
		}
		if (TutorSystem.TutorialMode)
		{
			TutorSystem.Notify_Event("AddBill-" + recipe.LabelCap.Resolve());
		}
	}

	public static bool ExtraPartOnGUI(Rect rect, RecipeDef recipe, Precept_ThingStyle precept)
	{
		return Widgets.InfoCardButton(rect.x + 5f, rect.y + (rect.height - 24f) / 2f, recipe, precept);
	}
}
