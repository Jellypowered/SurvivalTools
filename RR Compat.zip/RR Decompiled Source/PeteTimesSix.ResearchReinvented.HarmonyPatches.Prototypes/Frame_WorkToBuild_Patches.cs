using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Frame), "WorkToBuild", MethodType.Getter)]
public static class Frame_WorkToBuild_Patches
{
	[HarmonyPostfix]
	public static float Postfix(float __result, Frame __instance)
	{
		if (Current.ProgramState != ProgramState.Playing)
		{
			return __result;
		}
		if (PrototypeKeeper.Instance.IsPrototype(__instance))
		{
			return __result * PrototypeUtilities.PROTOTYPE_WORK_MULTIPLIER;
		}
		return __result;
	}
}
