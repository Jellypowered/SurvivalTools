using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Toils_Recipe), "MakeUnfinishedThingIfNeeded")]
public static class Toils_Recipe_MakeUnfinishedThingIfNeeded_Patches
{
	[HarmonyPostfix]
	public static void Toils_Recipe_MakeUnfinishedThingIfNeeded(Toil __result)
	{
		__result.AddPreInitAction(delegate
		{
			Toil toil = __result;
			Pawn actor = toil.actor;
			Job curJob = actor.jobs.curJob;
			RecipeDef recipeDef = curJob.RecipeDef;
			if (curJob.GetTarget(TargetIndex.B).Thing is UnfinishedThing unfinishedThing && ((recipeDef != null && recipeDef.IsAvailableOnlyForPrototyping()) || (recipeDef.ProducedThingDef != null && recipeDef.ProducedThingDef.IsAvailableOnlyForPrototyping())))
			{
				if (ResearchReinvented_Debug.debugPrintouts)
				{
					Log.Message($"Marking {unfinishedThing} as prototype");
				}
				PrototypeKeeper.Instance.MarkAsPrototype(unfinishedThing);
			}
		});
	}
}
