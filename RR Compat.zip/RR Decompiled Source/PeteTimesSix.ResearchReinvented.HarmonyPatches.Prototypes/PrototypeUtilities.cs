using System;
using System.Collections.Generic;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Data;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

public static class PrototypeUtilities
{
	public static float EXPERIMENTAL_SURGERY_SUCCESS_MODIFIER;

	public static float EXPERIMENTAL_SURGERY_MAX_SUCCESS_CHANCE;

	private static float PROTOTYPE_QUALITY_MULTIPLIER_MIN;

	private static float PROTOTYPE_QUALITY_MULTIPLIER_MAX;

	private static float PROTOTYPE_HEALTH_MULTIPLIER_MIN;

	private static float PROTOTYPE_HEALTH_MULTIPLIER_MAX;

	public static float PROTOTYPE_WORK_MULTIPLIER;

	private static float PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MIN;

	private static float PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MAX;

	private static float PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MIN;

	private static float PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MAX;

	private static ResearchProjectDef cacheBuiltForProject;

	private static ResearchOpportunity[] _prototypeOpportunitiesCache;

	private static AccessTools.FieldRef<CompApparelVerbOwner_Charged, int> CompApparelVerbOwner_Charged_remainingCharges;

	public static IEnumerable<ResearchOpportunity> PrototypeOpportunities
	{
		get
		{
			if (cacheBuiltForProject != Find.ResearchManager.GetProject())
			{
				_prototypeOpportunitiesCache = ResearchOpportunityManager.Instance.GetFilteredOpportunities(null, HandlingMode.Special_Prototype).ToArray();
				cacheBuiltForProject = Find.ResearchManager.GetProject();
			}
			return _prototypeOpportunitiesCache;
		}
	}

	static PrototypeUtilities()
	{
		EXPERIMENTAL_SURGERY_SUCCESS_MODIFIER = 0.65f;
		EXPERIMENTAL_SURGERY_MAX_SUCCESS_CHANCE = 0.9f;
		PROTOTYPE_QUALITY_MULTIPLIER_MIN = 0.3f;
		PROTOTYPE_QUALITY_MULTIPLIER_MAX = 0.8f;
		PROTOTYPE_HEALTH_MULTIPLIER_MIN = 0.4f;
		PROTOTYPE_HEALTH_MULTIPLIER_MAX = 0.9f;
		PROTOTYPE_WORK_MULTIPLIER = 2f;
		PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MIN = 0.4f;
		PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MAX = 0.8f;
		PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MIN = 0.1f;
		PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MAX = 0.5f;
		cacheBuiltForProject = null;
		_prototypeOpportunitiesCache = Array.Empty<ResearchOpportunity>();
		CompApparelVerbOwner_Charged_remainingCharges = AccessTools.FieldRefAccess<int>(typeof(CompApparelVerbOwner_Charged), "remainingCharges");
	}

	public static void ClearPrototypeOpportunityCache()
	{
		cacheBuiltForProject = null;
		_prototypeOpportunitiesCache = Array.Empty<ResearchOpportunity>();
	}

	public static void DoPrototypeHealthDecrease(Thing product, RecipeDef usedRecipe)
	{
		float mult = Rand.Range(PROTOTYPE_HEALTH_MULTIPLIER_MIN, PROTOTYPE_HEALTH_MULTIPLIER_MAX);
		if (ResearchReinvented_Debug.debugPrintouts)
		{
			Log.Message($"Prototype health multiplier: {mult}");
		}
		product.HitPoints = (int)Math.Max(1f, (float)product.HitPoints * mult);
	}

	public static void DoPrototypeBadComps(Thing product, RecipeDef usedRecipe)
	{
		product.TryGetComp<CompBreakdownable>()?.DoBreakdown();
		CompApparelVerbOwner_Charged reloadComp1 = product.TryGetComp<CompApparelVerbOwner_Charged>();
		if (reloadComp1 != null)
		{
			if (reloadComp1.Props.destroyOnEmpty)
			{
				float mult = Rand.Range(PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MIN, PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MAX);
				if (ResearchReinvented_Debug.debugPrintouts)
				{
					Log.Message($"Prototype disposable verbOwner fuel multiplier: {mult}");
				}
				CompApparelVerbOwner_Charged_remainingCharges(reloadComp1) = Math.Max(1, (int)Math.Round((float)CompApparelVerbOwner_Charged_remainingCharges(reloadComp1) * mult));
			}
			else
			{
				float mult2 = Rand.Range(PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MIN, PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MAX);
				if (ResearchReinvented_Debug.debugPrintouts)
				{
					Log.Message($"Prototype refuelable verbOwner fuel multiplier: {mult2}");
				}
				CompApparelVerbOwner_Charged_remainingCharges(reloadComp1) = Math.Max(1, (int)Math.Round((float)CompApparelVerbOwner_Charged_remainingCharges(reloadComp1) * mult2));
			}
		}
		CompEquippableAbilityReloadable reloadComp2 = product.TryGetComp<CompEquippableAbilityReloadable>();
		if (reloadComp2 != null)
		{
			float mult3 = Rand.Range(PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MIN, PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MAX);
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"Prototype refuelable apparel fuel multiplier: {mult3}");
			}
			reloadComp2.RemainingCharges = Math.Max(1, (int)Math.Round((float)reloadComp2.RemainingCharges * mult3));
		}
		CompRefuelable refuelComp = product.TryGetComp<CompRefuelable>();
		if (refuelComp == null)
		{
			return;
		}
		if (refuelComp.Props.destroyOnNoFuel)
		{
			float mult4 = Rand.Range(PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MIN, PROTOTYPE_FUEL_DISPOSABLE_MULTIPLIER_MAX);
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"Prototype disposable fuel multiplier: {mult4}");
			}
			refuelComp.ConsumeFuel(refuelComp.Fuel * (1f - mult4));
		}
		else
		{
			float mult5 = Rand.Range(PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MIN, PROTOTYPE_FUEL_REFUELABLE_MULTIPLIER_MAX);
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"Prototype refuelable fuel multiplier: {mult5}");
			}
			refuelComp.ConsumeFuel(refuelComp.Fuel * (1f - mult5));
		}
	}

	public static QualityCategory DoPrototypeQualityDecreaseThing(QualityCategory category, Pawn worker, Thing product, RecipeDef usedRecipe)
	{
		if (product.def.IsAvailableOnlyForPrototyping() || (usedRecipe != null && usedRecipe.IsAvailableOnlyForPrototyping()))
		{
			byte asByte = (byte)category;
			float mult = Rand.Range(PROTOTYPE_QUALITY_MULTIPLIER_MIN, PROTOTYPE_QUALITY_MULTIPLIER_MAX);
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"Prototype quality multiplier: {mult}");
			}
			return (QualityCategory)Math.Max((byte)0, (byte)Math.Round((float)(int)asByte * mult));
		}
		return category;
	}

	public static QualityCategory DoPrototypeQualityDecreaseRecipe(QualityCategory category, Pawn worker, Thing product, RecipeDef usedRecipe)
	{
		if (product.def.IsAvailableOnlyForPrototyping() || (usedRecipe != null && usedRecipe.IsAvailableOnlyForPrototyping()))
		{
			byte asByte = (byte)category;
			float mult = Rand.Range(PROTOTYPE_QUALITY_MULTIPLIER_MIN, PROTOTYPE_QUALITY_MULTIPLIER_MAX);
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"Prototype quality multiplier: {mult}");
			}
			return (QualityCategory)Math.Max((byte)0, (byte)Math.Round((float)(int)asByte * mult));
		}
		return category;
	}

	public static void DoPostFailToFinishThingResearch(Pawn worker, float totalWork, float doneWork, ThingDef productDef, RecipeDef usedRecipe)
	{
		if (!worker.CanNowDoResearch())
		{
			return;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_Prototype, (ResearchOpportunity op) => op.requirement.MetBy(usedRecipe) || op.requirement.MetBy(productDef));
		if (opportunity == null)
		{
			return;
		}
		if (ResearchReinvented_Debug.debugPrintouts)
		{
			Log.Message(string.Format("pawn {0} finished (failure) thing {1} {2} and there's an opportunity {3}", worker.LabelCap, productDef.LabelCap, (usedRecipe != null) ? usedRecipe.LabelCap.ToString() : "", opportunity.ShortDesc));
		}
		doneWork = Math.Max(doneWork, totalWork / 5f);
		doneWork = Math.Max(doneWork, 1200f);
		float workMultiplier = 1f;
		if (worker.skills != null)
		{
			if (usedRecipe != null)
			{
				if (usedRecipe.workSpeedStat != null)
				{
					workMultiplier = worker.GetStatValue(usedRecipe.workSpeedStat);
				}
			}
			else
			{
				workMultiplier = worker.GetStatValue(StatDefOf.ConstructionSpeed);
			}
		}
		float amount = doneWork * BaseResearchAmounts.DoneWorkMultiplier;
		float modifier = worker.GetStatValue(StatDefOf.ResearchSpeed);
		float xp = doneWork * ResearchXPAmounts.DoneWorkMultiplier;
		opportunity.ResearchChunkPerformed(worker, HandlingMode.Special_Prototype, amount, modifier, xp, (usedRecipe != null) ? usedRecipe.LabelCap.ToString() : productDef.LabelCap.ToString());
	}

	public static void DoPostFailToFinishTerrainResearch(Pawn worker, float totalWork, float doneWork, TerrainDef terrainDef)
	{
		if (!worker.CanNowDoResearch())
		{
			return;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_Prototype, terrainDef);
		if (opportunity != null)
		{
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"pawn {worker.LabelCap} finished (failure) terrain {terrainDef.LabelCap} and there's an opportunity {opportunity.ShortDesc}");
			}
			doneWork = Math.Max(doneWork, totalWork / 5f);
			doneWork = Math.Max(doneWork, 1200f);
			float workMultiplier = 1f;
			if (worker.skills != null)
			{
				workMultiplier = worker.GetStatValue(StatDefOf.ConstructionSpeed);
			}
			float amount = doneWork * BaseResearchAmounts.DoneWorkMultiplier;
			float modifier = worker.GetStatValue(StatDefOf.ResearchSpeed) * workMultiplier;
			float xp = doneWork * ResearchXPAmounts.DoneWorkMultiplier;
			opportunity.ResearchChunkPerformed(worker, HandlingMode.Special_Prototype, amount, modifier, xp, terrainDef.LabelCap);
		}
	}

	public static void DoPostFinishThingResearch(Pawn worker, float totalWork, Thing product, RecipeDef usedRecipe)
	{
		if (!worker.CanNowDoResearch())
		{
			return;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_Prototype, (ResearchOpportunity op) => op.requirement.MetBy(usedRecipe) || op.requirement.MetBy(product.def));
		if (opportunity == null)
		{
			return;
		}
		if (ResearchReinvented_Debug.debugPrintouts)
		{
			Log.Message(string.Format("pawn {0} finished thing {1} {2} and there's an opportunity {3}", worker.LabelCap, product.LabelCap, (usedRecipe != null) ? usedRecipe.LabelCap.ToString() : "", opportunity.ShortDesc));
		}
		totalWork = Math.Max(totalWork, 1200f);
		float workMultiplier = 1f;
		if (worker.skills != null)
		{
			if (usedRecipe != null)
			{
				if (usedRecipe.workSpeedStat != null)
				{
					workMultiplier = worker.GetStatValue(usedRecipe.workSpeedStat);
				}
			}
			else
			{
				workMultiplier = worker.GetStatValue(StatDefOf.ConstructionSpeed);
			}
		}
		float amount = totalWork * BaseResearchAmounts.DoneWorkMultiplier;
		float modifier = worker.GetStatValue(StatDefOf.ResearchSpeed) * workMultiplier;
		float xp = totalWork * ResearchXPAmounts.DoneWorkMultiplier;
		opportunity.ResearchChunkPerformed(worker, HandlingMode.Special_Prototype, amount, modifier, xp, (usedRecipe != null) ? usedRecipe.LabelCap.ToString() : product.LabelCapNoCount);
	}

	public static void DoPostFinishTerrainResearch(Pawn worker, float totalWork, TerrainDef terrainDef)
	{
		if (!worker.CanNowDoResearch())
		{
			return;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_Prototype, terrainDef);
		if (opportunity != null)
		{
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"pawn {worker.LabelCap} finished terrain {terrainDef.LabelCap} and there's an opportunity {opportunity.ShortDesc}");
			}
			totalWork = Math.Max(totalWork, 1200f);
			float workMultiplier = 1f;
			if (worker.skills != null)
			{
				workMultiplier = worker.GetStatValue(StatDefOf.ConstructionSpeed);
			}
			float amount = totalWork * BaseResearchAmounts.DoneWorkMultiplier;
			float modifier = worker.GetStatValue(StatDefOf.ResearchSpeed) * workMultiplier;
			float xp = totalWork * ResearchXPAmounts.DoneWorkMultiplier;
			opportunity.ResearchChunkPerformed(worker, HandlingMode.Special_Prototype, amount, modifier, xp, terrainDef.LabelCap);
		}
	}

	public static void DoPostFinishSurgeryResearch(Pawn target, Pawn worker, float totalWork, RecipeDef usedRecipe)
	{
		if (!worker.CanNowDoResearch() || usedRecipe == null)
		{
			return;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_Prototype, usedRecipe);
		if (opportunity != null)
		{
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"pawn {worker.LabelCap} finished surgery {usedRecipe.LabelCap} and there's an opportunity {opportunity.ShortDesc}");
			}
			totalWork = Math.Max(totalWork, 1200f);
			float amount = totalWork * BaseResearchAmounts.DoneWorkMultiplier;
			float modifier = worker.GetStatValue(StatDefOf.ResearchSpeed);
			float xp = totalWork * ResearchXPAmounts.DoneWorkMultiplier;
			opportunity.ResearchChunkPerformed(worker, HandlingMode.Special_Prototype, amount, modifier, xp, usedRecipe.LabelCap.ToString());
		}
	}
}
