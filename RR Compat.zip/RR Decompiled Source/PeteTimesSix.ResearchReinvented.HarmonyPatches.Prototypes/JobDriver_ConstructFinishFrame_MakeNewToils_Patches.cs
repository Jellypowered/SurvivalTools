using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch]
public static class JobDriver_ConstructFinishFrame_MakeNewToils_Patches
{
	private static readonly CodeMatch[] toMatch = new CodeMatch[5]
	{
		new CodeMatch(OpCodes.Ldsfld, AccessTools.Field(typeof(StatDefOf), "ConstructSuccessChance")),
		new CodeMatch(OpCodes.Ldc_I4_1),
		new CodeMatch(OpCodes.Ldc_I4_M1),
		new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(StatExtension), "GetStatValue")),
		new CodeMatch(OpCodes.Stloc_S)
	};

	[HarmonyTargetMethods]
	public static IEnumerable<MethodBase> CalculateMethods(Harmony instance)
	{
		IEnumerable<MethodInfo> candidates = typeof(JobDriver_ConstructFinishFrame).GetNestedTypes(AccessTools.all).SelectMany((Type t) => AccessTools.GetDeclaredMethods(t));
		foreach (MethodInfo method in candidates)
		{
			List<CodeInstruction> instructions = PatchProcessor.GetCurrentInstructions(method);
			if (new CodeMatcher(instructions).MatchStartForward(toMatch).IsValid)
			{
				yield return method;
			}
		}
	}

	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> JobDriver_ConstructFinishFrame_MakeNewToils_initAction_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		CodeInstruction[] toInsert = new CodeInstruction[3]
		{
			new CodeInstruction(OpCodes.Ldloc_1),
			new CodeInstruction(OpCodes.Ldloc_0),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(JobDriver_ConstructFinishFrame_MakeNewToils_Patches), "PrototypeFailureChanceIncrease"))
		};
		codeMatcher.MatchEndForward(toMatch);
		codeMatcher.Insert(toInsert);
		codeMatcher.End();
		if (codeMatcher.IsInvalid)
		{
			Log.Warning("RR: failed to apply transpiler on JobDriver_ConstructFinishFrame_MakeNewToils_initAction!");
			return instructions;
		}
		return codeMatcher.InstructionEnumeration();
	}

	public static float PrototypeFailureChanceIncrease(float statValue, Frame frame, Pawn pawn)
	{
		if (PrototypeKeeper.Instance.IsPrototype(frame))
		{
			return statValue * 0.75f;
		}
		return statValue;
	}
}
