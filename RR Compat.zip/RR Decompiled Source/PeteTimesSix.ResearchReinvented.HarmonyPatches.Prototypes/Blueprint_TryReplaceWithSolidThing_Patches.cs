using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Blueprint), "TryReplaceWithSolidThing")]
public static class Blueprint_TryReplaceWithSolidThing_Patches
{
	[HarmonyPostfix]
	public static void Postfix(Blueprint __instance, Pawn workerPawn, ref Thing createdThing, ref bool jobEnded)
	{
		if (createdThing is Frame frame)
		{
			BuildableDef buildable = frame.def.entityDefToBuild;
			if (buildable.IsAvailableOnlyForPrototyping(evenIfFinished: true))
			{
				PrototypeKeeper.Instance.MarkAsPrototype(createdThing);
			}
		}
	}
}
