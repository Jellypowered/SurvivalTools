using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Frame), "CompleteConstruction")]
[HarmonyBefore(new string[] { "OskarPotocki.VEF", "Uuugggg.rimworld.Replace_Stuff.main", "WorldbuilderMod" })]
public static class Frame_CompleteConstruction_Patches
{
	private static bool checkedIsPrototype;

	private static Thing checkedProduct;

	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> FullTranspiler(IEnumerable<CodeInstruction> instructions)
	{
		object thingLocal = FindThingLocal(instructions);
		if (thingLocal == null)
		{
			Log.Warning("RR: Frame_CompleteConstruction_Patches - failed to apply patches (could not locate Thing local index)");
			return instructions;
		}
		IEnumerable<CodeInstruction> moddedInstructions = TranspilerForQuality(instructions, thingLocal);
		moddedInstructions = TranspilerSpawn(moddedInstructions, thingLocal);
		moddedInstructions = TranspilerPostFoundationSet(moddedInstructions, thingLocal);
		return TranspilerPostTerrainSet(moddedInstructions, thingLocal);
	}

	private static object FindThingLocal(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher thingLocalFinder = new CodeMatcher(instructions);
		CodeMatch[] thing_using_instructions = new CodeMatch[2]
		{
			new CodeMatch(OpCodes.Ldloc_S),
			new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(ThingCompUtility), "TryGetComp", new Type[1] { typeof(Thing) }).MakeGenericMethod(typeof(CompQuality)))
		};
		thingLocalFinder.MatchStartForward(thing_using_instructions);
		if (thingLocalFinder.IsInvalid)
		{
			return null;
		}
		return thingLocalFinder.Instruction.operand;
	}

	public static IEnumerable<CodeInstruction> TranspilerForQuality(IEnumerable<CodeInstruction> instructions, object thingLocal)
	{
		CodeMatch[] finally_instructions = new CodeMatch[4]
		{
			new CodeMatch(OpCodes.Ldarg_1),
			new CodeMatch(OpCodes.Ldsfld, AccessTools.Field(typeof(SkillDefOf), "Construction")),
			new CodeMatch(OpCodes.Ldc_I4_1),
			new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(QualityUtility), "GenerateQualityCreatedByPawn", new Type[3]
			{
				typeof(Pawn),
				typeof(SkillDef),
				typeof(bool)
			}))
		};
		CodeInstruction[] add_prototype_decrease_instructions = new CodeInstruction[3]
		{
			new CodeInstruction(OpCodes.Ldloc_S, (byte)5),
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(Frame_CompleteConstruction_Patches), "PostQuality"))
		};
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchEndForward(finally_instructions);
		if (!codeMatcher.IsInvalid)
		{
			codeMatcher.Advance();
			codeMatcher.Insert(add_prototype_decrease_instructions);
			return codeMatcher.InstructionEnumeration();
		}
		Log.Warning("RR: Frame_CompleteConstruction_Patches - TranspilerForQuality - failed to apply patch (instructions not found)");
		return instructions;
	}

	private static QualityCategory PostQuality(QualityCategory category, Thing product, Pawn worker)
	{
		return PrototypeUtilities.DoPrototypeQualityDecreaseThing(category, worker, product, null);
	}

	public static IEnumerable<CodeInstruction> TranspilerSpawn(IEnumerable<CodeInstruction> instructions, object thingLocal)
	{
		CodeMatch[] spawn_instructions = new CodeMatch[11]
		{
			new CodeMatch(OpCodes.Ldloc_S, thingLocal),
			new CodeMatch(OpCodes.Ldarg_0),
			new CodeMatch(OpCodes.Call, AccessTools.PropertyGetter(typeof(Thing), "Position")),
			new CodeMatch(OpCodes.Ldloc_1),
			new CodeMatch(OpCodes.Ldarg_0),
			new CodeMatch(OpCodes.Call, AccessTools.PropertyGetter(typeof(Thing), "Rotation")),
			new CodeMatch(OpCodes.Ldc_I4_1),
			new CodeMatch(OpCodes.Ldc_I4_0),
			new CodeMatch(OpCodes.Ldc_I4_0),
			new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(GenSpawn), "Spawn", new Type[7]
			{
				typeof(Thing),
				typeof(IntVec3),
				typeof(Map),
				typeof(Rot4),
				typeof(WipeMode),
				typeof(bool),
				typeof(bool)
			})),
			new CodeMatch(OpCodes.Pop)
		};
		CodeInstruction[] add_prespawn_instructions = new CodeInstruction[4]
		{
			new CodeInstruction(OpCodes.Ldarg_0),
			new CodeInstruction(OpCodes.Ldloc_S, thingLocal),
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(Frame_CompleteConstruction_Patches), "PreSpawn"))
		};
		CodeInstruction[] add_postspawn_instructions = new CodeInstruction[4]
		{
			new CodeInstruction(OpCodes.Ldarg_0),
			new CodeInstruction(OpCodes.Ldloc_S, thingLocal),
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(Frame_CompleteConstruction_Patches), "PostSpawn"))
		};
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchStartForward(spawn_instructions);
		int invalidStage;
		if (codeMatcher.IsInvalid)
		{
			invalidStage = 1;
		}
		else
		{
			codeMatcher.Insert(add_prespawn_instructions);
			codeMatcher.MatchEndForward(spawn_instructions);
			if (!codeMatcher.IsInvalid)
			{
				codeMatcher.Advance();
				codeMatcher.Insert(add_postspawn_instructions);
				return codeMatcher.InstructionEnumeration();
			}
			invalidStage = 2;
		}
		Log.Warning($"RR: Frame_CompleteConstruction_Patches - TranspilerSpawn - failed to apply patch (instructions not found, stage {invalidStage})");
		return instructions;
	}

	private static void PreSpawn(Frame frame, Thing product, Pawn worker)
	{
		checkedProduct = product;
		checkedIsPrototype = product.def.IsAvailableOnlyForPrototyping() || PrototypeKeeper.Instance.IsPrototype(frame);
		if (checkedIsPrototype)
		{
			PrototypeUtilities.DoPrototypeHealthDecrease(product, null);
			PrototypeKeeper.Instance.UnmarkAsPrototype(frame);
		}
	}

	private static void PostSpawn(Frame frame, Thing product, Pawn worker)
	{
		if (checkedProduct == product && checkedIsPrototype)
		{
			PrototypeUtilities.DoPrototypeBadComps(product, null);
			PrototypeKeeper.Instance.MarkAsPrototype(product);
			PrototypeUtilities.DoPostFinishThingResearch(worker, frame.WorkToBuild * PrototypeUtilities.PROTOTYPE_WORK_MULTIPLIER, product, null);
		}
	}

	public static IEnumerable<CodeInstruction> TranspilerPostTerrainSet(IEnumerable<CodeInstruction> instructions, object thingLocal)
	{
		CodeMatch[] set_terrain_instructions = new CodeMatch[1]
		{
			new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(TerrainGrid), "SetTerrain", new Type[2]
			{
				typeof(IntVec3),
				typeof(TerrainDef)
			}))
		};
		CodeInstruction[] add_terrain_instructions = new CodeInstruction[8]
		{
			new CodeInstruction(OpCodes.Ldloc_1),
			new CodeInstruction(OpCodes.Ldarg_0),
			new CodeInstruction(OpCodes.Ldarg_0),
			new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(Frame), "def")),
			new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(ThingDef), "entityDefToBuild")),
			new CodeInstruction(OpCodes.Castclass, typeof(TerrainDef)),
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(Frame_CompleteConstruction_Patches), "PostSetTerrain"))
		};
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchEndForward(set_terrain_instructions);
		if (!codeMatcher.IsInvalid)
		{
			codeMatcher.Advance();
			codeMatcher.Insert(add_terrain_instructions);
			foreach (CodeInstruction item in codeMatcher.Instructions())
			{
				yield return item;
			}
			yield break;
		}
		Log.Warning("Frame_CompleteConstruction_Patches - TranspilerPostTerrainSet - failed to apply patch (instructions not found)");
		foreach (CodeInstruction instruction in instructions)
		{
			yield return instruction;
		}
	}

	public static IEnumerable<CodeInstruction> TranspilerPostFoundationSet(IEnumerable<CodeInstruction> instructions, object thingLocal)
	{
		CodeMatch[] set_terrain_instructions = new CodeMatch[1]
		{
			new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(TerrainGrid), "SetFoundation", new Type[2]
			{
				typeof(IntVec3),
				typeof(TerrainDef)
			}))
		};
		CodeInstruction[] add_terrain_instructions = new CodeInstruction[8]
		{
			new CodeInstruction(OpCodes.Ldloc_1),
			new CodeInstruction(OpCodes.Ldarg_0),
			new CodeInstruction(OpCodes.Ldarg_0),
			new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(Frame), "def")),
			new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(ThingDef), "entityDefToBuild")),
			new CodeInstruction(OpCodes.Castclass, typeof(TerrainDef)),
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(Frame_CompleteConstruction_Patches), "PostSetFoundation"))
		};
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchEndForward(set_terrain_instructions);
		if (!codeMatcher.IsInvalid)
		{
			codeMatcher.Advance();
			codeMatcher.Insert(add_terrain_instructions);
			foreach (CodeInstruction item in codeMatcher.Instructions())
			{
				yield return item;
			}
			yield break;
		}
		Log.Warning("Frame_CompleteConstruction_Patches - TranspilerPostFoundationSet - failed to apply patch (instructions not found)");
		foreach (CodeInstruction instruction in instructions)
		{
			yield return instruction;
		}
	}

	private static void PostSetTerrain(Map map, Frame frame, TerrainDef terrainDef, Pawn worker)
	{
		if (!terrainDef.temporary)
		{
			if (terrainDef.IsAvailableOnlyForPrototyping(evenIfFinished: true) || PrototypeKeeper.Instance.IsPrototype(frame))
			{
				PrototypeKeeper.Instance.MarkTerrainAsPrototype(frame.Position, map, terrainDef);
				PrototypeUtilities.DoPostFinishTerrainResearch(worker, frame.WorkToBuild, terrainDef);
				PrototypeKeeper.Instance.UnmarkAsPrototype(frame);
			}
			else
			{
				PrototypeKeeper.Instance.UnmarkTerrainAsPrototype(frame.Position, map);
			}
		}
	}

	private static void PostSetFoundation(Map map, Frame frame, TerrainDef terrainDef, Pawn worker)
	{
		if (!terrainDef.temporary)
		{
			if (terrainDef.IsAvailableOnlyForPrototyping(evenIfFinished: true) || PrototypeKeeper.Instance.IsPrototype(frame))
			{
				PrototypeKeeper.Instance.MarkFoundationTerrainAsPrototype(frame.Position, map, terrainDef);
				PrototypeUtilities.DoPostFinishTerrainResearch(worker, frame.WorkToBuild, terrainDef);
				PrototypeKeeper.Instance.UnmarkAsPrototype(frame);
			}
			else
			{
				PrototypeKeeper.Instance.UnmarkFoundationTerrainAsPrototype(frame.Position, map);
			}
		}
	}
}
