using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Bill), "PawnAllowedToStartAnew")]
public static class Bill_PawnAllowedToStartAnew_Patches
{
	[HarmonyPostfix]
	public static bool Postfix(bool __result, Bill __instance, Pawn p)
	{
		if (!__result)
		{
			return __result;
		}
		if (__instance.recipe.IsAvailableOnlyForPrototyping())
		{
			if (!p.CanEverDoResearch())
			{
				JobFailReason.Is(StringsCache.JobFail_IncapableOfResearch);
				return false;
			}
			Pawn_WorkSettings workSettings = p.workSettings;
			if (workSettings == null || !workSettings.WorkIsActive(WorkTypeDefOf.Research))
			{
				JobFailReason.Is("NotAssignedToWorkType".Translate(WorkTypeDefOf.Research.gerundLabel).CapitalizeFirst());
				return false;
			}
		}
		return __result;
	}
}
