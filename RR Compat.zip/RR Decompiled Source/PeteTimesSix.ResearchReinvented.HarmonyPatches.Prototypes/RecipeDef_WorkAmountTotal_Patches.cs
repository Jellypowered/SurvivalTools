using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(RecipeDef), "WorkAmountTotal")]
public static class RecipeDef_WorkAmountTotal_Patches
{
	[HarmonyPostfix]
	public static float Postfix(float __result, RecipeDef __instance)
	{
		if (Current.ProgramState != ProgramState.Playing)
		{
			return __result;
		}
		if (!__instance.IsAvailableOnlyForPrototyping())
		{
			return __result;
		}
		return __result * PrototypeUtilities.PROTOTYPE_WORK_MULTIPLIER;
	}
}
