using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Toils_Recipe), "DoRecipeWork")]
public static class Toils_Recipe_DoRecipeWork_Patches
{
	[HarmonyPostfix]
	public static void Toils_Recipe_DoRecipeWork_Postfix(Toil __result)
	{
		__result.AddPreTickIntervalAction(delegate(int delta)
		{
			Toil toil = __result;
			Pawn actor = toil.actor;
			Job curJob = actor.CurJob;
			Thing thing = curJob.GetTarget(TargetIndex.A).Thing;
			if (thing != null && actor.CanEverDoResearch())
			{
				ResearchOpportunity firstFilteredOpportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_Tooling, thing);
				if (firstFilteredOpportunity != null)
				{
					float num = 1f;
					if (actor.skills != null)
					{
						num = ((curJob.RecipeDef.workSpeedStat == null) ? 1f : actor.GetStatValue(curJob.RecipeDef.workSpeedStat));
					}
					float amount = num * actor.GetStatValue(StatDefOf.ResearchSpeed) * 0.00825f;
					firstFilteredOpportunity.ResearchTickPerformed(amount, actor, delta);
				}
			}
		});
	}
}
