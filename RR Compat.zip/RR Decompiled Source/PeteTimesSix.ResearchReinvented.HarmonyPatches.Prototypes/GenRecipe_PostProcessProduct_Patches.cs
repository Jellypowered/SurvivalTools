using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(GenRecipe), "PostProcessProduct")]
public static class GenRecipe_PostProcessProduct_Patches
{
	[HarmonyPostfix]
	public static void Postfix(Thing product, RecipeDef recipeDef, Pawn worker, Precept_ThingStyle precept = null)
	{
		if (product.def.IsAvailableOnlyForPrototyping() || (recipeDef != null && recipeDef.IsAvailableOnlyForPrototyping()))
		{
			PrototypeUtilities.DoPrototypeHealthDecrease(product, recipeDef);
			PrototypeUtilities.DoPrototypeBadComps(product, recipeDef);
			PrototypeKeeper.Instance.MarkAsPrototype(product);
			PrototypeUtilities.DoPostFinishThingResearch(worker, recipeDef.WorkAmountTotal(product), product, recipeDef);
		}
	}

	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		IEnumerator<CodeInstruction> enumerator = instructions.GetEnumerator();
		CodeInstruction[] finally_instructions = new CodeInstruction[5]
		{
			new CodeInstruction(OpCodes.Ldarg_2),
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(RecipeDef), "workSkill")),
			new CodeInstruction(OpCodes.Ldc_I4_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(QualityUtility), "GenerateQualityCreatedByPawn", new Type[3]
			{
				typeof(Pawn),
				typeof(SkillDef),
				typeof(bool)
			}))
		};
		CodeInstruction[] add_prototype_decrease_instructions = new CodeInstruction[4]
		{
			new CodeInstruction(OpCodes.Ldarg_2),
			new CodeInstruction(OpCodes.Ldarg_0),
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(PrototypeUtilities), "DoPrototypeQualityDecreaseRecipe"))
		};
		CodeInstruction[] matchedInstructions;
		bool found;
		IEnumerable<CodeInstruction> iteratedOver = TranspilerUtils.IterateTo(enumerator, finally_instructions, out matchedInstructions, out found);
		foreach (CodeInstruction item in iteratedOver)
		{
			yield return item;
		}
		if (!found)
		{
			Log.Warning("GenRecipe_PostProcessProduct_Patches - failed to apply patch (instructions not found)");
		}
		else
		{
			CodeInstruction[] array = add_prototype_decrease_instructions;
			for (int i = 0; i < array.Length; i++)
			{
				yield return array[i];
			}
		}
		while (enumerator.MoveNext())
		{
			yield return enumerator.Current;
		}
	}
}
