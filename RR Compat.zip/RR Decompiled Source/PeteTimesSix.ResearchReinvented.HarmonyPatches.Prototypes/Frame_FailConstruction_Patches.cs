using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Frame), "FailConstruction")]
public static class Frame_FailConstruction_Patches
{
	[HarmonyPostfix]
	public static void Frame_FailConstruction_Postfix(Frame __instance, Pawn worker)
	{
		if (PrototypeKeeper.Instance.IsPrototype(__instance) || __instance.def.entityDefToBuild.IsAvailableOnlyForPrototyping(evenIfFinished: true))
		{
			if (__instance.def.entityDefToBuild is TerrainDef terrainDef)
			{
				PrototypeUtilities.DoPostFailToFinishTerrainResearch(worker, __instance.WorkToBuild, __instance.workDone, terrainDef);
			}
			else if (__instance.def.entityDefToBuild is ThingDef thingDef)
			{
				PrototypeUtilities.DoPostFailToFinishThingResearch(worker, __instance.WorkToBuild, __instance.workDone, thingDef, null);
			}
			PrototypeKeeper.Instance.UnmarkAsPrototype(__instance);
		}
	}
}
