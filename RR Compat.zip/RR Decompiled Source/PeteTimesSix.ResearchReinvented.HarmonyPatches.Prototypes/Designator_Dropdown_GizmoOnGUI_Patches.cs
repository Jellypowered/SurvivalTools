using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using RimWorld;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Designator_Dropdown), "GizmoOnGUI")]
public static class Designator_Dropdown_GizmoOnGUI_Patches
{
	[HarmonyPostfix]
	public static void Postfix(GizmoResult __result, Designator_Dropdown __instance, Designator ___activeDesignator, Vector2 topLeft, float maxWidth)
	{
		if (___activeDesignator != null && ___activeDesignator is Designator_Place placeDesignator && placeDesignator.PlacingDef.IsAvailableOnlyForPrototyping(evenIfFinished: true))
		{
			float width = __instance.GetWidth(maxWidth);
			Designator_Build_GizmoOnGUI_Patches.DrawPrototypeLabel(topLeft, width);
		}
	}
}
