using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using RimWorld;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Designator_Build), "GizmoOnGUI")]
public static class Designator_Build_GizmoOnGUI_Patches
{
	private static Color CyanishTransparentBG = new Color(0.5f, 0.75f, 1f, 0.5f);

	private static Color CyanishTransparent = new Color(0.5f, 1f, 1f, 0.8f);

	[HarmonyPostfix]
	public static void Postfix(GizmoResult __result, Designator_Build __instance, BuildableDef ___entDef, Vector2 topLeft, float maxWidth)
	{
		if (__instance.PlacingDef.IsAvailableOnlyForPrototyping(evenIfFinished: true))
		{
			float width = __instance.GetWidth(maxWidth);
			DrawPrototypeLabel(topLeft, width);
		}
	}

	internal static void DrawPrototypeLabel(Vector2 topLeft, float width)
	{
		Text.Font = GameFont.Tiny;
		TaggedString protoLabel = "RR_PrototypeLabel".Translate();
		float height = Text.CalcHeight(protoLabel, width);
		Rect labelRect = new Rect(topLeft.x + 2f, topLeft.y + 13f, width - 4f, height);
		GUI.color = CyanishTransparentBG;
		GUI.DrawTexture(labelRect, TexUI.GrayTextBG);
		Text.Anchor = TextAnchor.UpperCenter;
		GUI.color = CyanishTransparent;
		Widgets.Label(labelRect, protoLabel);
		Text.Anchor = TextAnchor.UpperLeft;
		Text.Font = GameFont.Small;
		GUI.color = Color.white;
	}
}
