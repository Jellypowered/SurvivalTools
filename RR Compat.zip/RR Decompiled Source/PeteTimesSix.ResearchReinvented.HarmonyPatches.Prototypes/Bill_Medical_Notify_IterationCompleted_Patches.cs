using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;

[HarmonyPatch(typeof(Bill_Medical), "Notify_IterationCompleted")]
public static class Bill_Medical_Notify_IterationCompleted_Patches
{
	[HarmonyPostfix]
	public static void Postfix(Bill_Medical __instance, Pawn billDoer)
	{
		if (billDoer.CanNowDoResearch())
		{
			RecipeDef recipe = __instance.recipe;
			if (recipe != null && recipe.IsAvailableOnlyForPrototyping())
			{
				PrototypeUtilities.DoPostFinishSurgeryResearch(__instance.GiverPawn, billDoer, recipe.WorkAmountTotal(null), recipe);
			}
		}
	}
}
