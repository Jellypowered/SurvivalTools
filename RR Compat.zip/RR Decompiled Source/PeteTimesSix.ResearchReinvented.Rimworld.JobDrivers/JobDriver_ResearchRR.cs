using System;
using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.ModCompat;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;

public class JobDriver_ResearchRR : JobDriver_RRBase
{
	private const TargetIndex ResearchBenchIndex = TargetIndex.A;

	protected Building_ResearchBench ResearchBench => job.targetA.Thing as Building_ResearchBench;

	public override bool TryMakePreToilReservations(bool errorOnFailed)
	{
		return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
	}

	protected override IEnumerable<Toil> MakeNewToils()
	{
		ResearchOpportunity opportunity = WorkGiver_ResearcherRR.OpportunityCache;
		ResearchProjectDef currentProject = Find.ResearchManager.GetProject();
		if (currentProject == null || opportunity == null)
		{
			if (currentProject == null)
			{
				Log.WarningOnce("RR: Generated JobDriver_ResearchRR job with no active project!", 456654 + pawn.thingIDNumber);
			}
			else
			{
				Log.WarningOnce($"RR: Generated JobDriver_ResearchRR job {job} but could not find the matching opportunity!", 456654 + pawn.thingIDNumber);
			}
			yield return Toils_General.Wait(1);
			yield break;
		}
		this.FailOn(() => currentProject != Find.ResearchManager.GetProject());
		this.FailOn(() => opportunity.CurrentAvailability != OpportunityAvailability.Available);
		if (ResearchData.active)
		{
			this.FailOn(delegate
			{
				CompRefuelable compRefuelable = ResearchBench.TryGetComp<CompRefuelable>();
				return compRefuelable != null && !compRefuelable.HasFuel;
			});
		}
		this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
		this.FailOnBurningImmobile(TargetIndex.A);
		this.FailOn(() => !ResearchBench.CanUseNow());
		yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.InteractionCell);
		Toil research = new Toil();
		research.tickIntervalAction = delegate(int delta)
		{
			Pawn actor = research.actor;
			float num = actor.GetStatValue(StatDefOf.ResearchSpeed) * 0.00825f;
			num *= ResearchBench.GetStatValue(StatDefOf.ResearchSpeedFactor);
			actor.GainComfortFromCellIfPossible(1, chairsOnly: true);
			if (ResearchData.active)
			{
				CompRefuelable comp = ResearchBench.GetComp<CompRefuelable>();
				if (comp != null && comp.Props.consumeFuelOnlyWhenUsed)
				{
					comp.ConsumeTickIntervalFuel(delta);
				}
			}
			if (opportunity.ResearchTickPerformed(num, actor, delta))
			{
				ReadyForNextToil();
			}
		};
		research.FailOn(() => ResearchBench.IsForbidden(pawn));
		research.FailOn((Func<bool>)delegate
		{
			CompPowerTrader comp = ResearchBench.GetComp<CompPowerTrader>();
			return (comp != null && !comp.PowerOn) ? true : false;
		});
		research.AddEndCondition(() => (!opportunity.IsFinished && opportunity.CurrentAvailability == OpportunityAvailability.Available) ? JobCondition.Ongoing : JobCondition.Succeeded);
		research.WithEffect(EffecterDefOf.Research, TargetIndex.A);
		research.AddFailCondition(() => !ResearchBench.CanUseNow());
		research.defaultCompleteMode = ToilCompleteMode.Never;
		research.FailOnCannotTouch(TargetIndex.A, PathEndMode.InteractionCell);
		research.activeSkill = () => SkillDefOf.Intellectual;
		yield return research;
	}
}
