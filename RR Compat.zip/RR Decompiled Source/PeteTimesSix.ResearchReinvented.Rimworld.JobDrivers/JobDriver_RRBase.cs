using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;

public abstract class JobDriver_RRBase : JobDriver
{
}
