using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.DefOfs;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;

public class JobDriver_InterrogatePrisoner : JobDriver
{
	public static readonly int REPETITIONS = 4;

	protected Pawn Talkee => (Pawn)job.targetA.Thing;

	public override bool TryMakePreToilReservations(bool errorOnFailed)
	{
		return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
	}

	protected override string ReportStringProcessed(string str)
	{
		if (Talkee.guest.IsInteractionEnabled(PrisonerInteractionModeDefOf_Custom.RR_ScienceInterrogation))
		{
			return "RR_jobReport_ScienceInterrogation".Translate(Talkee);
		}
		return base.ReportStringProcessed(str);
	}

	protected override IEnumerable<Toil> MakeNewToils()
	{
		this.FailOnDespawnedOrNull(TargetIndex.A);
		this.FailOnMentalState(TargetIndex.A);
		this.FailOnNotAwake(TargetIndex.A);
		this.FailOn(() => !Talkee.IsPrisonerOfColony || !Talkee.guest.PrisonerIsSecure);
		yield return Toils_Interpersonal.GotoPrisoner(pawn, Talkee, PrisonerInteractionModeDefOf_Custom.RR_ScienceInterrogation);
		yield return Toils_Interpersonal.WaitToBeAbleToInteract(pawn);
		for (int i = 0; i < REPETITIONS; i++)
		{
			yield return Toils_Interpersonal.GotoPrisoner(pawn, Talkee, PrisonerInteractionModeDefOf_Custom.RR_ScienceInterrogation);
			yield return Toils_Interpersonal.GotoInteractablePosition(TargetIndex.A);
			yield return ScienceInterrogationRequest(pawn, Talkee);
			yield return Toils_Interpersonal.GotoPrisoner(pawn, Talkee, PrisonerInteractionModeDefOf_Custom.RR_ScienceInterrogation);
			yield return Toils_Interpersonal.GotoInteractablePosition(TargetIndex.A);
			yield return ScienceInterrogationReply(pawn, Talkee);
		}
		yield return Toils_Interpersonal.GotoPrisoner(pawn, Talkee, PrisonerInteractionModeDefOf_Custom.RR_ScienceInterrogation);
		yield return Toils_Interpersonal.GotoInteractablePosition(TargetIndex.A).FailOn(() => !Talkee.guest.ScheduledForInteraction);
		yield return Toils_Interpersonal.SetLastInteractTime(TargetIndex.A);
		yield return ScienceInterrogationFinalize(pawn, Talkee);
	}

	public static Toil ScienceInterrogationRequest(Pawn warden, Pawn talkee)
	{
		Toil toil = ToilMaker.MakeToil("ScienceInterrogation");
		toil.initAction = delegate
		{
			InteractionDef rR_ScienceInterrogation_Demand = InteractionDefOf_Custom.RR_ScienceInterrogation_Demand;
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"warden to talkee: {warden} {warden?.interactions} {warden?.jobs} {warden?.jobs?.curDriver} {warden?.records} talkee: {talkee} {talkee?.guest} def: {rR_ScienceInterrogation_Demand}");
			}
			if (!warden.interactions.TryInteractWith(talkee, rR_ScienceInterrogation_Demand))
			{
				warden.jobs.curDriver.ReadyForNextToil();
			}
			else
			{
				warden.records.Increment(RecordDefOf.PrisonersChatted);
			}
		};
		toil.FailOn(() => !talkee.guest.ScheduledForInteraction);
		toil.socialMode = RandomSocialMode.Off;
		toil.defaultCompleteMode = ToilCompleteMode.Delay;
		toil.defaultDuration = 200;
		toil.activeSkill = () => SkillDefOf.Social;
		return toil;
	}

	public static Toil ScienceInterrogationReply(Pawn warden, Pawn talkee)
	{
		Toil toil = ToilMaker.MakeToil("ScienceInterrogation");
		toil.initAction = delegate
		{
			InteractionDef interactionDef = InteractionDefOf_Custom.RR_ScienceInterrogation_Reply_Reluctant;
			if (talkee.needs?.mood != null)
			{
				float curLevelPercentage = talkee.needs.mood.CurLevelPercentage;
				if ((double)curLevelPercentage < 0.5)
				{
					float chance = 1f - curLevelPercentage * 2f;
					if (Rand.Chance(chance))
					{
						interactionDef = InteractionDefOf_Custom.RR_ScienceInterrogation_Reply_Resistant;
					}
				}
				else
				{
					float chance2 = (curLevelPercentage - 0.5f) * 2f;
					if (Rand.Chance(chance2))
					{
						interactionDef = InteractionDefOf_Custom.RR_ScienceInterrogation_Reply_Cooperative;
					}
				}
			}
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"talkee to warden: {warden} {warden?.interactions} {warden?.jobs} {warden?.jobs?.curDriver} {warden?.records} talkee: {talkee} {talkee?.guest} def: {interactionDef}");
			}
			if (!warden.interactions.TryInteractWith(talkee, interactionDef))
			{
				warden.jobs.curDriver.ReadyForNextToil();
			}
			else
			{
				warden.records.Increment(RecordDefOf.PrisonersChatted);
			}
		};
		toil.FailOn(() => !talkee.guest.ScheduledForInteraction);
		toil.socialMode = RandomSocialMode.Off;
		toil.defaultCompleteMode = ToilCompleteMode.Delay;
		toil.defaultDuration = 200;
		toil.activeSkill = () => SkillDefOf.Social;
		return toil;
	}

	public static Toil ScienceInterrogationFinalize(Pawn pawn, Pawn talkee)
	{
		Toil toil = ToilMaker.MakeToil("NoteResultsOfInterrogation");
		toil.initAction = delegate
		{
			pawn.interactions.TryInteractWith(talkee, InteractionDefOf_Custom.RR_ScienceInterrogationFinalize);
		};
		toil.socialMode = RandomSocialMode.Off;
		toil.defaultCompleteMode = ToilCompleteMode.Delay;
		toil.defaultDuration = 350;
		toil.activeSkill = () => SkillDefOf.Social;
		return toil;
	}
}
