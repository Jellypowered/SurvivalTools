using System;
using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.ModCompat;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Rimworld.Toils;
using PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;

public class JobDriver_Analyse : JobDriver_RRBase
{
	public const int JobEndInterval = 4000;

	private const TargetIndex TargetThingIndex = TargetIndex.A;

	private const TargetIndex ResearchBenchIndex = TargetIndex.B;

	private const TargetIndex StorageCellWhenDoneIndex = TargetIndex.B;

	private const TargetIndex TargetThingPlacementIndex = TargetIndex.C;

	protected Thing TargetThing => job.targetA.Thing;

	protected Building_ResearchBench ResearchBench => job.targetB.Thing as Building_ResearchBench;

	public override bool TryMakePreToilReservations(bool errorOnFailed)
	{
		if (pawn.Reserve(job.GetTarget(TargetIndex.B), job, 1, -1, null, errorOnFailed) && pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, 1, null, errorOnFailed))
		{
			return true;
		}
		return false;
	}

	protected override IEnumerable<Toil> MakeNewToils()
	{
		Thing unminifiedThing = TargetThing.GetInnerIfMinified();
		ResearchOpportunity opportunity = WorkGiver_Analyse.OpportunityCache[unminifiedThing.def].FirstOrDefault();
		ResearchProjectDef currentProject = Find.ResearchManager.GetProject();
		if (currentProject == null || opportunity == null)
		{
			if (currentProject == null)
			{
				Log.WarningOnce("RR: Generated JobDriver_Analyse job with no active project!", 456654 + pawn.thingIDNumber);
			}
			else
			{
				Log.WarningOnce($"RR: Generated JobDriver_Analyse job {job} but could not find the matching opportunity!", 456654 + pawn.thingIDNumber);
			}
			yield return Toils_General.Wait(1);
			yield break;
		}
		this.FailOn(() => currentProject != Find.ResearchManager.GetProject());
		this.FailOn(() => opportunity.CurrentAvailability != OpportunityAvailability.Available);
		if (ResearchData.active && ResearchReinventedMod.Settings.researchDataCompatMode == ResearchData.ResearchDataCompatMode.AllBenchResearch)
		{
			this.FailOn(delegate
			{
				CompRefuelable comp = ResearchBench.GetComp<CompRefuelable>();
				return comp != null && !comp.HasFuel;
			});
		}
		this.FailOnBurningImmobile(TargetIndex.B);
		yield return Toils_Reserve.Reserve(TargetIndex.A);
		yield return Toils_Reserve.Reserve(TargetIndex.B);
		yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch).FailOnSomeonePhysicallyInteracting(TargetIndex.A).FailOnDestroyedNullOrForbidden(TargetIndex.A);
		yield return Toils_Reserve.Release(TargetIndex.A);
		yield return Toils_Haul.StartCarryThing(TargetIndex.A);
		yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.InteractionCell).FailOnDestroyedOrNull(TargetIndex.A);
		yield return Toils_ClearCell.ClearDefaultIngredientPlaceCell(TargetIndex.B);
		Toil findPlaceTarget = Toils_JobTransforms.SetTargetToIngredientPlaceCell(TargetIndex.B, TargetIndex.A, TargetIndex.C);
		yield return findPlaceTarget;
		yield return Toils_Haul.PlaceHauledThingInCell(TargetIndex.C, findPlaceTarget, storageMode: false);
		Toil research = new Toil();
		research.tickIntervalAction = delegate(int delta)
		{
			Pawn actor = research.actor;
			float num = actor.GetStatValue(StatDefOf.ResearchSpeed) * 0.00825f;
			num *= ResearchBench.GetStatValue(StatDefOf.ResearchSpeedFactor);
			actor.GainComfortFromCellIfPossible(1, chairsOnly: true);
			if (ResearchData.active && ResearchReinventedMod.Settings.researchDataCompatMode == ResearchData.ResearchDataCompatMode.AllBenchResearch)
			{
				CompRefuelable comp = ResearchBench.GetComp<CompRefuelable>();
				if (comp != null && comp.Props.consumeFuelOnlyWhenUsed)
				{
					comp.ConsumeTickIntervalFuel(delta);
				}
			}
			if (opportunity.ResearchTickPerformed(num, actor, delta))
			{
				ReadyForNextToil();
			}
		};
		research.WithEffect(EffecterDefOf.Research, TargetIndex.B);
		research.FailOn(() => ResearchBench.IsForbidden(pawn));
		research.FailOn(() => TargetThing.IsForbidden(pawn));
		research.FailOn((Func<bool>)delegate
		{
			CompPowerTrader comp = ResearchBench.GetComp<CompPowerTrader>();
			return (comp != null && !comp.PowerOn) ? true : false;
		});
		research.AddEndCondition(() => (!opportunity.IsFinished && opportunity.CurrentAvailability == OpportunityAvailability.Available) ? JobCondition.Ongoing : JobCondition.Succeeded);
		research.WithProgressBar(TargetIndex.B, () => (opportunity == null) ? 0f : opportunity.ProgressFraction);
		research.defaultCompleteMode = ToilCompleteMode.Never;
		research.activeSkill = () => SkillDefOf.Intellectual;
		yield return research;
		yield return Toils_Jump.JumpIf(research, () => !opportunity.IsFinished);
		yield return Toils_Haul_Custom.FindStorageForThing(TargetIndex.A, TargetIndex.B);
		yield return Toils_Haul.StartCarryThing(TargetIndex.A);
		yield return Toils_Goto.GotoCell(TargetIndex.B, PathEndMode.Touch).FailOnDestroyedOrNull(TargetIndex.A);
		yield return Toils_Haul.PlaceHauledThingInCell(TargetIndex.B, null, storageMode: true);
	}
}
