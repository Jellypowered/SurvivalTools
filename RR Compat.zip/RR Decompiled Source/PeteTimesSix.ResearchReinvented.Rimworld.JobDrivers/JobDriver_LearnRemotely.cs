using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;

public class JobDriver_LearnRemotely : JobDriver
{
	public class ExceptionToken
	{
		public bool hasException;
	}

	public virtual Thing TargetThing => job.targetA.Thing;

	public virtual TargetIndex TargetThingIndex => TargetIndex.A;

	public override bool TryMakePreToilReservations(bool errorOnFailed)
	{
		return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
	}

	protected override IEnumerable<Toil> MakeNewToils()
	{
		if (!(job.commTarget is Faction faction))
		{
			Log.WarningOnce("RR: Generated JobDriver_LearnRemotely job but commsTarget was not a faction!", 451654 + pawn.thingIDNumber);
			yield return Toils_General.Wait(1);
			yield break;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Social, faction);
		ResearchProjectDef currentProject = Find.ResearchManager.GetProject();
		if (currentProject == null || opportunity == null)
		{
			if (currentProject == null)
			{
				Log.WarningOnce("RR: Generated JobDriver_LearnRemotely job with no active project!", 453654 + pawn.thingIDNumber);
			}
			else
			{
				Log.WarningOnce($"RR: Generated JobDriver_LearnRemotely job {job} but could not find the matching opportunity!", 456654 + pawn.thingIDNumber);
			}
			yield return Toils_General.Wait(1);
			yield break;
		}
		this.FailOn(() => currentProject != Find.ResearchManager.GetProject());
		this.FailOn(() => opportunity.CurrentAvailability != OpportunityAvailability.Available);
		ExceptionToken token = new ExceptionToken();
		this.FailOn(() => !token.hasException && FactionLectureManager.Instance.IsOnCooldown((opportunity.requirement as ROComp_RequiresFaction).faction));
		this.FailOnDespawnedOrNull(TargetIndex.A);
		yield return Toils_Goto.GotoCell(TargetIndex.A, PathEndMode.InteractionCell).FailOn((Toil to) => !((Building_CommsConsole)to.actor.jobs.curJob.GetTarget(TargetIndex.A).Thing).CanUseCommsNow);
		Toil research = new Toil();
		research.FailOnDespawnedNullOrForbidden(TargetThingIndex);
		research.defaultCompleteMode = ToilCompleteMode.Delay;
		research.defaultDuration = 3000;
		research.FailOnCannotTouch(TargetThingIndex, PathEndMode.InteractionCell);
		research.activeSkill = () => SkillDefOf.Intellectual;
		research.initAction = delegate
		{
			token.hasException = true;
			FactionLectureManager.Instance.PutOnCooldown((opportunity.requirement as ROComp_RequiresFaction).faction);
		};
		research.tickIntervalAction = delegate(int delta)
		{
			Pawn actor = research.actor;
			float amount = actor.GetStatValue(StatDefOf.ResearchSpeed) * 0.00825f;
			actor.GainComfortFromCellIfPossible(1, chairsOnly: true);
			if (opportunity.ResearchTickPerformed(amount, actor, delta))
			{
				ReadyForNextToil();
			}
		};
		research.WithProgressBarToilDelay(TargetThingIndex);
		research.FailOn(() => TargetThing.IsForbidden(pawn));
		research.FailOn((Toil to) => !((Building_CommsConsole)to.actor.jobs.curJob.GetTarget(TargetIndex.A).Thing).CanUseCommsNow);
		research.AddEndCondition(() => (!opportunity.IsFinished && opportunity.CurrentAvailability == OpportunityAvailability.Available) ? JobCondition.Ongoing : JobCondition.Succeeded);
		yield return research;
		yield return Toils_General.Wait(2);
	}
}
