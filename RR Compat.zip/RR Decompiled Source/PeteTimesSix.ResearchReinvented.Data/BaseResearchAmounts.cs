namespace PeteTimesSix.ResearchReinvented.Data;

public static class BaseResearchAmounts
{
	public static float AdministerIngestibleObserver => 50f;

	public static float OnIngestIngester => 25f;

	public static float OnTendObserver => 25f;

	public static float InteractionBrainstorm => 15f;

	public static float InteractionLearnFromPrisoner => 50f;

	public static float DoneWorkMultiplier => 0.004166667f;
}
