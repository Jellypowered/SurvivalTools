namespace PeteTimesSix.ResearchReinvented.Data;

public static class ResearchXPAmounts
{
	public static float AdministerIngestibleObserver => 100f;

	public static float OnIngestIngester => 100f;

	public static float OnTendObserver => 200f;

	public static float DoneWorkMultiplier => 1f / 24f;
}
