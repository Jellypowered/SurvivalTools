using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Utilities;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.Toils;

public static class Toils_Goto_Custom
{
	public static Toil GoAdjacentToThing(TargetIndex ind, bool cardinalOnly = false)
	{
		Toil toil = new Toil();
		toil.initAction = delegate
		{
			Pawn actor = toil.actor;
			IEnumerable<IntVec3> source = AdjacencyHelper.GenReachableAdjacentCells(actor.jobs.curJob.GetTarget(ind).Thing, actor, cardinalOnly);
			if (source.Any())
			{
				IntVec3 intVec = source.InRandomOrder().First();
				actor.pather.StartPath(intVec, PathEndMode.OnCell);
			}
		};
		toil.defaultCompleteMode = ToilCompleteMode.PatherArrival;
		toil.FailOnDespawnedOrNull(ind);
		return toil;
	}
}
