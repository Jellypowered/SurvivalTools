using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.Toils;

public static class Toils_Haul_Custom
{
	public static Toil FindStorageForThing(TargetIndex thingIndex, TargetIndex destinationCellIndex)
	{
		Toil toil = new Toil();
		toil.initAction = delegate
		{
			Pawn actor = toil.actor;
			Job curJob = actor.jobs.curJob;
			Thing thing = actor.CurJob.GetTarget(thingIndex).Thing;
			StoreUtility.TryFindBestBetterStoreCellFor(thing, actor, actor.Map, StoragePriority.Unstored, actor.Faction, out var foundCell);
			if (foundCell.IsValid)
			{
				curJob.SetTarget(destinationCellIndex, new LocalTargetInfo(foundCell));
				curJob.SetTarget(thingIndex, new LocalTargetInfo(thing));
				curJob.count = 99999;
			}
		};
		toil.defaultCompleteMode = ToilCompleteMode.Instant;
		toil.FailOnDespawnedOrNull(thingIndex);
		return toil;
	}
}
