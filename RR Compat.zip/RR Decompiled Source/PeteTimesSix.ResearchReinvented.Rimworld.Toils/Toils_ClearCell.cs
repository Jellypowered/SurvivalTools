using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.Toils;

public static class Toils_ClearCell
{
	public static Toil ClearDefaultIngredientPlaceCell(TargetIndex buildingIndex)
	{
		Toil toil = new Toil();
		toil.initAction = delegate
		{
			Pawn actor = toil.actor;
			Thing underlyingBuilding = actor.jobs.curJob.GetTarget(buildingIndex).Thing;
			IEnumerable<IntVec3> source = IngredientPlaceCellsInOrder(underlyingBuilding);
			if (source.Any())
			{
				IntVec3 c = source.First();
				IEnumerable<Thing> source2 = from t in c.GetThingList(actor.MapHeld)
					where t != underlyingBuilding
					select t;
				if (source2.Any())
				{
					IEnumerable<IntVec3> enumerable = IngredientPlaceCellsInOrder(underlyingBuilding).Skip(1);
					IEnumerator<IntVec3> enumerator = enumerable.GetEnumerator();
					foreach (Thing current in source2.ToList())
					{
						if (current.Spawned && current.def.EverHaulable)
						{
							while (enumerator.MoveNext())
							{
								IntVec3 current2 = enumerator.Current;
								if (IsEmptyEnoughSpot(current, underlyingBuilding.MapHeld, current2))
								{
									List<Thing> list = (from t in current2.GetThingList(actor.MapHeld)
										where t.def.EverHaulable
										select t).ToList();
									if (!list.Any())
									{
										current.Position = current2;
										break;
									}
									bool flag = false;
									foreach (Thing current3 in list)
									{
										flag = current3.TryAbsorbStack(current, respectStackLimit: true);
										if (flag)
										{
											break;
										}
									}
									if (flag)
									{
										break;
									}
								}
							}
						}
					}
				}
			}
		};
		toil.defaultCompleteMode = ToilCompleteMode.Instant;
		return toil;
	}

	private static IEnumerable<IntVec3> IngredientPlaceCellsInOrder(Thing destination, int fallBackRadius = 15)
	{
		IntVec3 interactCell = destination.Position;
		IBillGiver billGiver = destination as IBillGiver;
		List<IntVec3> cellsAlreadySent = new List<IntVec3>();
		IEnumerable<IntVec3> desiredPlaceCells;
		if (billGiver != null)
		{
			interactCell = (billGiver as Thing).InteractionCell;
			desiredPlaceCells = billGiver.IngredientStackCells.OrderBy((IntVec3 c) => c.LengthHorizontalSquared);
		}
		else
		{
			desiredPlaceCells = from c in GenAdj.CellsOccupiedBy(destination)
				orderby c.DistanceTo(destination.Position)
				select c;
		}
		foreach (IntVec3 item in desiredPlaceCells)
		{
			yield return item;
		}
		cellsAlreadySent.AddRange(desiredPlaceCells);
		for (int i = 0; i < fallBackRadius; i++)
		{
			IntVec3 cell = interactCell + GenRadial.RadialPattern[i];
			if (!cellsAlreadySent.Contains(cell))
			{
				Building edifice = cell.GetEdifice(destination.Map);
				if (edifice == null || edifice.def.passability != Traversability.Impassable || edifice.def.surfaceType != SurfaceType.None)
				{
					yield return cell;
				}
			}
		}
	}

	private static bool IsEmptyEnoughSpot(Thing haulable, Map map, IntVec3 c)
	{
		if (GenPlace.HaulPlaceBlockerIn(haulable, c, map, checkBlueprintsAndFrames: true) != null)
		{
			return false;
		}
		if (c == haulable.Position && haulable.Spawned)
		{
			return false;
		}
		if (c.ContainsStaticFire(map))
		{
			return false;
		}
		if (haulable != null && haulable.def.BlocksPlanting() && map.zoneManager.ZoneAt(c) is Zone_Growing)
		{
			return false;
		}
		Building edifice = c.GetEdifice(map);
		if (edifice != null && edifice is Building_Trap)
		{
			return false;
		}
		return true;
	}
}
