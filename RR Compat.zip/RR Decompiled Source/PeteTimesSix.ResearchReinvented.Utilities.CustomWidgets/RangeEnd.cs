namespace PeteTimesSix.ResearchReinvented.Utilities.CustomWidgets;

internal enum RangeEnd : byte
{
	None,
	Min,
	Max
}
