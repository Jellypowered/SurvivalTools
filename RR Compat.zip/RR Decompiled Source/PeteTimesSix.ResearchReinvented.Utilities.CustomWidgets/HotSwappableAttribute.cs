using System;

namespace PeteTimesSix.ResearchReinvented.Utilities.CustomWidgets;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
public class HotSwappableAttribute : Attribute
{
}
