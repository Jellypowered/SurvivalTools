using System;
using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Rimworld;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace PeteTimesSix.ResearchReinvented.Utilities.CustomWidgets;

[StaticConstructorOnStartup]
[HotSwappable]
public static class CategoriesVisualizer
{
	private static readonly Texture2D FadeGradient = ContentFinder<Texture2D>.Get("UI/fadeGradient");

	private static readonly Color WindowBGBorderColor = new ColorInt(97, 108, 122).ToColor;

	public static void DrawCategories(Rect rect)
	{
		TextAnchor anchor = Text.Anchor;
		Color color = GUI.color;
		float maxImportanceMultiplier = 1f;
		float maxResearchSpeedMultiplier = 0f;
		List<ResearchOpportunityCategoryDef> categories = DefDatabase<ResearchOpportunityCategoryDef>.AllDefsListForReading.OrderByDescending((ResearchOpportunityCategoryDef d) => d.priority).ToList();
		foreach (ResearchOpportunityCategoryDef category in categories)
		{
			if (category.Settings.enabled)
			{
				if (category.Settings.importanceMultiplier > maxImportanceMultiplier)
				{
					maxImportanceMultiplier = category.Settings.importanceMultiplier;
				}
				if (category.Settings.researchSpeedMultiplier > maxResearchSpeedMultiplier)
				{
					maxResearchSpeedMultiplier = category.Settings.researchSpeedMultiplier;
				}
			}
		}
		Rect graphRect = rect.ContractedBy(10f);
		Rect botAxis = graphRect.BottomPartPixels(20f);
		graphRect.height -= 30f;
		Rect fractionsRect = graphRect.LeftPart(0.6f);
		Rect researchSpeedRect = graphRect.RightPart(0.4f);
		float fractionWidthBase = fractionsRect.width / maxImportanceMultiplier;
		float fractionHeight = fractionsRect.height / (float)categories.Count;
		float centerLine = fractionsRect.x + fractionsRect.width;
		GUI.color = WindowBGBorderColor;
		Widgets.DrawBox(rect, 2);
		float hundredPercentOffset = centerLine + researchSpeedRect.width * (1f / maxResearchSpeedMultiplier);
		Text.Anchor = TextAnchor.MiddleCenter;
		Widgets.DrawBoxSolid(botAxis.TopPartPixels(2f), GUI.color);
		Rect fractionAxis = botAxis.LeftPart(0.6f).OffsetBy(0f, 2f);
		Rect researchSpeedAxis = botAxis.RightPart(0.4f).OffsetBy(0f, 2f);
		Widgets.DrawBoxSolid(fractionAxis.LeftPartPixels(2f).OffsetBy(-1f, -1f), GUI.color);
		Widgets.DrawBoxSolid(researchSpeedAxis.RightPartPixels(2f).OffsetBy(1f, -1f), GUI.color);
		Widgets.DrawBoxSolid(new Rect(hundredPercentOffset - 1f, rect.y, 2f, botAxis.y - rect.y + 1f), GUI.color);
		Widgets.Label(fractionAxis, "RR_setting_category_fractionAxis".Translate());
		Widgets.Label(researchSpeedAxis, "RR_setting_category_researchSpeedAxis".Translate());
		GUI.color = Color.white;
		for (int i = 0; i < categories.Count; i++)
		{
			ResearchOpportunityCategoryDef category2 = categories[i];
			float categoryY = fractionsRect.y + (float)i * fractionHeight;
			if (!category2.Settings.enabled)
			{
				GUI.color = Color.white;
				Rect categoryOffRect = new Rect(researchSpeedRect.x, categoryY, fractionHeight, fractionHeight).ContractedBy(3f);
				GUI.DrawTexture(categoryOffRect, Textures.forbiddenOverlayTex);
			}
			else
			{
				float widthTotal = fractionWidthBase * category2.Settings.importanceMultiplier;
				float widthNormal = fractionWidthBase * category2.Settings.importanceMultiplierCounted;
				if (category2.Settings.importanceMultiplierCounted > 0f)
				{
					Rect categoryNormRect = new Rect(centerLine - widthNormal, categoryY, widthNormal, fractionHeight);
					Widgets.DrawBoxSolidWithOutline(categoryNormRect, Color.Lerp(category2.color, Color.black, 0.8f), Color.Lerp(category2.color, Color.black, 0.5f));
				}
				if (category2.Settings.infiniteOverflow)
				{
					float widthExtra = fractionsRect.width - widthNormal;
					Rect categoryFadeoutRect = new Rect(fractionsRect.x, categoryY, widthExtra, fractionHeight);
					GUI.color = Color.Lerp(category2.color, Color.black, 0.75f);
					GUI.DrawTextureWithTexCoords(categoryFadeoutRect, FadeGradient, new Rect(0f, 0f, 1f, 1f));
				}
				else
				{
					float widthExtra2 = fractionWidthBase * (category2.Settings.importanceMultiplier - category2.Settings.importanceMultiplierCounted);
					Rect categoryExtraRect = new Rect(centerLine - (widthNormal + widthExtra2), categoryY, widthExtra2, fractionHeight);
					GUI.color = Color.Lerp(category2.color, Color.black, 0.5f);
					Widgets.DrawBoxSolidWithOutline(categoryExtraRect, Color.Lerp(category2.color, Color.black, 0.9f), Color.Lerp(category2.color, Color.black, 0.75f));
				}
				Rect categoryFullRect = new Rect(centerLine - widthTotal, categoryY, widthTotal, fractionHeight);
				float iterations = category2.Settings.targetIterations;
				float offset = 0f;
				Color outerColor = Color.Lerp(category2.color, Color.black, 0.6f);
				Color innerColor = Color.Lerp(category2.color, Color.black, 0.7f);
				while (iterations > 0f)
				{
					float width = Math.Min(1f, iterations) * (widthTotal / category2.Settings.targetIterations);
					Rect iterRect = categoryFullRect.RightPartPixels(width);
					iterRect.x -= offset;
					GUI.color = outerColor;
					Widgets.DrawBox(iterRect.ContractedBy(1f));
					offset += width;
					iterations -= 1f;
				}
				if (category2.Settings.importanceStatic > 0f)
				{
					float widthStatic = fractionsRect.width * category2.Settings.importanceStatic;
					float offset2 = fractionHeight * 0.5f - 4f;
					Rect categoryStaticRect = new Rect(fractionsRect.x + (fractionsRect.width - widthStatic), categoryY + offset2, widthStatic, 8f);
					Widgets.DrawBoxSolidWithOutline(categoryStaticRect, Color.Lerp(category2.color, Color.black, 0.8f), Color.Lerp(category2.color, Color.black, 0.5f));
				}
				if (category2.Settings.enabled)
				{
					float widthSpeed = researchSpeedRect.width * (category2.Settings.researchSpeedMultiplier / maxResearchSpeedMultiplier);
					Rect speedRect = new Rect(researchSpeedRect.x, categoryY + fractionHeight / 2f - 2f, widthSpeed, 4f);
					Widgets.DrawBoxSolid(speedRect, WindowBGBorderColor);
					Rect speedEndCapRect = new Rect(researchSpeedRect.x + widthSpeed - 1f, categoryY + fractionHeight / 2f - 5f, 2f, 10f);
					Widgets.DrawBoxSolid(speedEndCapRect, WindowBGBorderColor);
					Rect speedLabelRect = new Rect(researchSpeedRect.x + 10f, categoryY, researchSpeedRect.width - 10f, fractionHeight);
					Text.Anchor = TextAnchor.MiddleLeft;
					GUI.color = Color.white;
					Widgets.Label(speedLabelRect, (category2.Settings.researchSpeedMultiplier * 100f).ToString("F0") + "%");
				}
			}
			Text.Anchor = TextAnchor.MiddleRight;
			GUI.color = category2.color;
			Rect categoryLabelRect = new Rect(fractionsRect.x, categoryY, fractionsRect.width - 10f, fractionHeight);
			Widgets.Label(categoryLabelRect, category2.LabelCap);
			Rect categoryRect = new Rect(graphRect.x, categoryY, graphRect.width, fractionHeight);
			if (Widgets.ButtonInvisible(categoryRect))
			{
				ResearchReinventedMod.Settings.temp_activeTab = SettingTab.CATEGORY_CONFIG;
				ResearchReinventedMod.Settings.temp_selectedCategory = category2;
				SoundDefOf.Tick_High.PlayOneShotOnCamera();
			}
		}
		GUI.color = WindowBGBorderColor;
		Widgets.DrawBoxSolid(new Rect(centerLine - 1f, rect.y, 2f, rect.height), GUI.color);
		Text.Anchor = anchor;
		GUI.color = color;
	}
}
