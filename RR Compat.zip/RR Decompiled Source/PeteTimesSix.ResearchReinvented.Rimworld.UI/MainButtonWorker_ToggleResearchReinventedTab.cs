using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.UI;

public class MainButtonWorker_ToggleResearchReinventedTab : MainButtonWorker_ToggleTab
{
	public override float ButtonBarPercent => Find.ResearchManager.GetProject()?.ProgressPercent ?? 0f;
}
