using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.UI;

public static class Widgets_Extra
{
	private static float TEXT_EPSILON = 1f;

	private static GUIContent tmpTextGUIContent = new GUIContent();

	private const float SIDE_OF_CAUTION = 2f;

	public static void LabelFitHeightAware(Rect rect, string label, bool withBacking = true)
	{
		GameFont storedFont = Text.Font;
		IEnumerable<string> words = Words(label);
		int wordCount = words.Count();
		int maxLinesSmall = MaxLinesIn(rect, GameFont.Small);
		int maxLinesTiny = MaxLinesIn(rect, GameFont.Tiny);
		if (words.Any((string word) => CalcSizeInFont(word, GameFont.Small).x + TEXT_EPSILON > rect.width))
		{
			if (words.Any((string word) => CalcSizeInFont(word, GameFont.Tiny).x + TEXT_EPSILON > rect.width))
			{
				if (NewLinesNeededFor(rect.width, GameFont.Small, label) <= maxLinesSmall)
				{
					Text.Font = GameFont.Small;
					Widgets.Label(rect, label);
				}
				else
				{
					Text.Font = GameFont.Tiny;
					if (NewLinesNeededFor(rect.width, GameFont.Tiny, label) <= maxLinesTiny)
					{
						Widgets.Label(rect, label);
					}
					else
					{
						Widgets.Label(rect, label.Truncate(rect.width * (float)maxLinesTiny));
					}
				}
			}
			else
			{
				Text.Font = GameFont.Tiny;
				if (NewLinesNeededFor(rect.width, GameFont.Tiny, label) <= maxLinesTiny)
				{
					Widgets.Label(rect, label);
				}
				else
				{
					Widgets.Label(rect, label.Truncate(rect.width * (float)maxLinesTiny));
				}
			}
		}
		else if (NewLinesNeededFor(rect.width, GameFont.Small, label) <= maxLinesSmall)
		{
			Text.Font = GameFont.Small;
			Widgets.Label(rect, label);
		}
		else
		{
			Text.Font = GameFont.Tiny;
			if (NewLinesNeededFor(rect.width, GameFont.Tiny, label) <= maxLinesTiny)
			{
				Widgets.Label(rect, label);
			}
			else
			{
				Widgets.Label(rect, label.Truncate(rect.width * (float)maxLinesTiny));
			}
		}
		Text.Font = storedFont;
	}

	private static Vector2 CalcSizeInFont(string text, GameFont font)
	{
		GUIStyle guiStyle = font switch
		{
			GameFont.Tiny => Text.fontStyles[0], 
			GameFont.Small => Text.fontStyles[1], 
			GameFont.Medium => Text.fontStyles[2], 
			_ => throw new NotImplementedException(), 
		};
		tmpTextGUIContent.text = text.StripTags();
		return guiStyle.CalcSize(tmpTextGUIContent);
	}

	public static int NewLinesNeededFor(float rectWidth, GameFont font, string text, bool includeFirst = true)
	{
		int newLines = 0;
		float widthAccum = 0f;
		float widthAccumSinceLastWhitespace = 0f;
		int lastWhitespaceIndex = -1;
		for (int i = 0; i < text.Length; i++)
		{
			char ch = text[i];
			float width = CalcSizeInFont(ch.ToString(), GameFont.Small).x;
			widthAccum += width;
			widthAccumSinceLastWhitespace += width;
			if (char.IsWhiteSpace(ch))
			{
				lastWhitespaceIndex = i;
				widthAccumSinceLastWhitespace = 0f;
			}
			if (widthAccum + 2f > rectWidth)
			{
				widthAccum = ((lastWhitespaceIndex == -1 || !(widthAccumSinceLastWhitespace <= rectWidth)) ? 0f : widthAccumSinceLastWhitespace);
				newLines++;
				lastWhitespaceIndex = -1;
				widthAccumSinceLastWhitespace = 0f;
			}
		}
		if (includeFirst)
		{
			newLines++;
		}
		return newLines;
	}

	private static int MaxLinesIn(Rect rect, GameFont font)
	{
		return Math.Max(1, (int)Math.Floor(rect.height / Text.LineHeightOf(font)));
	}

	private static IEnumerable<string> Words(string text)
	{
		List<string> words = new List<string>();
		int wordCount = 0;
		int wordStartIndex = -1;
		int index;
		for (index = 0; index < text.Length && char.IsWhiteSpace(text[index]); index++)
		{
		}
		while (index < text.Length)
		{
			wordStartIndex = index;
			for (; index < text.Length && !char.IsWhiteSpace(text[index]); index++)
			{
			}
			words.Add(text.Substring(wordStartIndex, index - wordStartIndex));
			wordCount++;
			for (; index < text.Length && char.IsWhiteSpace(text[index]); index++)
			{
			}
		}
		return words;
	}
}
