using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.UI;

public static class ResearchWidgets
{
	public static void ThingDefIcon(Rect iconBox, ThingDef thingDef, bool doButton = true)
	{
		if (thingDef.uiIcon != null && thingDef.uiIcon != BaseContent.BadTex)
		{
			Widgets.DefIcon(iconBox, thingDef);
		}
		else if (thingDef.IsCorpse && thingDef.ingestible?.sourceDef?.uiIcon != null && thingDef.ingestible?.sourceDef?.uiIcon != BaseContent.BadTex)
		{
			Widgets.DefIcon(iconBox, thingDef.ingestible.sourceDef);
		}
		else if (thingDef.race != null || thingDef.IsCorpse)
		{
			Widgets.DrawTextureFitted(iconBox, Textures.genericPawnIcon, 1f);
		}
		else
		{
			Widgets.DrawTextureFitted(iconBox, Textures.genericIcon, 1f);
		}
		if (thingDef.IsCorpse)
		{
			Rect shrunkBox = new Rect(iconBox.x + iconBox.width / 2f, iconBox.y + iconBox.height / 2f, iconBox.width / 2f, iconBox.height / 2f);
			Widgets.DrawTextureFitted(shrunkBox, Textures.corpseIconOverlay, 1f);
		}
		if (doButton && Widgets.ButtonInvisible(iconBox))
		{
			Find.WindowStack.Add(new Dialog_InfoCard(thingDef));
		}
	}

	internal static void TerrainDefIcon(Rect iconBox, TerrainDef terrainDef, bool doButton = true)
	{
		Widgets.DefIcon(iconBox, terrainDef);
		if (doButton && Widgets.ButtonInvisible(iconBox))
		{
			Find.WindowStack.Add(new Dialog_InfoCard(terrainDef));
		}
	}

	internal static void RecipeDefIcon(Rect iconBox, RecipeDef recipeDef, bool doButton = true)
	{
		if (recipeDef.UIIconThing != null)
		{
			Widgets.ThingIcon(iconBox, recipeDef.UIIconThing);
		}
		else
		{
			bool hadThingIcon = false;
			ThingDef fixedIngredient = null;
			if (recipeDef.ingredients.Count == 1 && recipeDef.ingredients[0].IsFixedIngredient)
			{
				fixedIngredient = recipeDef.ingredients[0].FixedIngredient;
			}
			else
			{
				List<IngredientCount> fixedIngredients = recipeDef.ingredients.Where((IngredientCount i) => i.IsFixedIngredient).ToList();
				if (fixedIngredients.Count == 1)
				{
					fixedIngredient = fixedIngredients[0].FixedIngredient;
				}
			}
			if (fixedIngredient != null && fixedIngredient.uiIcon != null && fixedIngredient.uiIcon != BaseContent.BadTex)
			{
				hadThingIcon = true;
				Widgets.DefIcon(iconBox, fixedIngredient);
			}
			if (!hadThingIcon)
			{
				if (recipeDef.IsSurgery)
				{
					Widgets.DrawTextureFitted(iconBox, Textures.medicalInvasiveIcon, 1f);
				}
				else
				{
					Widgets.DrawTextureFitted(iconBox, Textures.medicalNoninvasiveIcon, 1f);
				}
			}
		}
		if (doButton && Widgets.ButtonInvisible(iconBox))
		{
			Find.WindowStack.Add(new Dialog_InfoCard(recipeDef));
		}
	}
}
