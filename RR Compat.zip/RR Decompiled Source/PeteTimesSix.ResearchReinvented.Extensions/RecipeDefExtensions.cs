using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Extensions;

public static class RecipeDefExtensions
{
	public static ResearchProjectDef cacheBuiltForProject = null;

	public static Dictionary<RecipeDef, ResearchOpportunity> _prototypeOpportunitiesMappedCache = new Dictionary<RecipeDef, ResearchOpportunity>();

	public static Dictionary<RecipeDef, ResearchOpportunity> PrototypeOpportunitiesMappedCache
	{
		get
		{
			if (cacheBuiltForProject != Find.ResearchManager.GetProject())
			{
				_prototypeOpportunitiesMappedCache.Clear();
				foreach (ResearchOpportunity op in PrototypeUtilities.PrototypeOpportunities)
				{
					if (op.requirement is ROComp_RequiresRecipe { AllRecipes: var allRecipes })
					{
						foreach (RecipeDef altRecipe in allRecipes)
						{
							_prototypeOpportunitiesMappedCache[altRecipe] = op;
						}
					}
				}
				cacheBuiltForProject = Find.ResearchManager.GetProject();
			}
			return _prototypeOpportunitiesMappedCache;
		}
	}

	public static HashSet<ResearchProjectDef> AllResearchPrerequisites(this RecipeDef recipe)
	{
		HashSet<ResearchProjectDef> prerequisites = new HashSet<ResearchProjectDef>();
		if (recipe.researchPrerequisite != null)
		{
			prerequisites.Add(recipe.researchPrerequisite);
		}
		if (recipe.researchPrerequisites != null)
		{
			prerequisites.AddRange(recipe.researchPrerequisites);
		}
		return prerequisites;
	}

	public static bool IsAvailableOnlyForPrototyping(this RecipeDef def, bool evenIfFinished = true)
	{
		List<ResearchProjectDef> preregs = new List<ResearchProjectDef>();
		if (def.researchPrerequisite != null)
		{
			preregs.Add(def.researchPrerequisite);
		}
		if (def.researchPrerequisites != null)
		{
			preregs.AddRange(def.researchPrerequisites);
		}
		if (preregs.Count > 0)
		{
			IEnumerable<ResearchProjectDef> unfinishedPreregs = preregs.Where((ResearchProjectDef r) => !r.IsFinished);
			if (!unfinishedPreregs.Any())
			{
				return false;
			}
			if (unfinishedPreregs.Any((ResearchProjectDef r) => Find.ResearchManager.GetProject() != r))
			{
				return false;
			}
			if (!PrototypeOpportunitiesMappedCache.ContainsKey(def))
			{
				return false;
			}
			ResearchOpportunity opportunity = PrototypeOpportunitiesMappedCache[def];
			if (opportunity == null)
			{
				return false;
			}
			if (!evenIfFinished)
			{
				return opportunity.CurrentAvailability == OpportunityAvailability.Available;
			}
			if (opportunity.CurrentAvailability != OpportunityAvailability.Available && opportunity.CurrentAvailability != OpportunityAvailability.Finished)
			{
				return opportunity.CurrentAvailability == OpportunityAvailability.CategoryFinished;
			}
			return true;
		}
		return false;
	}

	public static bool PassesIdeoCheck(this RecipeDef recipe)
	{
		if (!ModsConfig.IdeologyActive)
		{
			return true;
		}
		if (recipe.memePrerequisitesAny == null)
		{
			return true;
		}
		return recipe.memePrerequisitesAny.Any((MemeDef mp) => Faction.OfPlayer.ideos.HasAnyIdeoWithMeme(mp));
	}
}
