using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Extensions;

public static class ThingDefExtensions
{
	public static ResearchProjectDef cacheBuiltForProject = null;

	public static Dictionary<ThingDef, ResearchOpportunity> _prototypeOpportunitiesMappedCache = new Dictionary<ThingDef, ResearchOpportunity>();

	public static Dictionary<ThingDef, ResearchOpportunity> PrototypeOpportunitiesMappedCache
	{
		get
		{
			if (cacheBuiltForProject != Find.ResearchManager.GetProject())
			{
				_prototypeOpportunitiesMappedCache.Clear();
				foreach (ResearchOpportunity op in PrototypeUtilities.PrototypeOpportunities)
				{
					if (op.requirement is ROComp_RequiresThing { AllThings: var allThings })
					{
						foreach (ThingDef altThing in allThings)
						{
							_prototypeOpportunitiesMappedCache[altThing] = op;
						}
					}
				}
				cacheBuiltForProject = Find.ResearchManager.GetProject();
			}
			return _prototypeOpportunitiesMappedCache;
		}
	}

	public static bool IsTrulyRawFood(this ThingDef x)
	{
		if (x.IsNutritionGivingIngestible && !x.IsCorpse && x.ingestible.HumanEdible)
		{
			return (int)x.ingestible.preferability < 7;
		}
		return false;
	}

	public static bool IsInstantBuild(this ThingDef x)
	{
		if (x != null && x.GetStatValueAbstract(StatDefOf.WorkToBuild) == 0f)
		{
			return true;
		}
		return false;
	}

	public static bool IsAvailableOnlyForPrototyping(this ThingDef def)
	{
		if (def.researchPrerequisites != null)
		{
			IEnumerable<ResearchProjectDef> unfinishedPreregs = def.researchPrerequisites.Where((ResearchProjectDef r) => !r.IsFinished);
			if (!unfinishedPreregs.Any())
			{
				return false;
			}
			if (unfinishedPreregs.Any((ResearchProjectDef r) => Find.ResearchManager.GetProject() != r))
			{
				return false;
			}
			return true;
		}
		return false;
	}

	public static bool IsAvailableOnlyForPrototyping(this ThingDef def, bool evenIfFinished = true)
	{
		if (def.researchPrerequisites != null && def.researchPrerequisites.Count > 0)
		{
			IEnumerable<ResearchProjectDef> unfinishedPreregs = def.researchPrerequisites.Where((ResearchProjectDef r) => !r.IsFinished);
			if (!unfinishedPreregs.Any())
			{
				return false;
			}
			if (unfinishedPreregs.Any((ResearchProjectDef r) => Find.ResearchManager.GetProject() != r))
			{
				return false;
			}
			if (!PrototypeOpportunitiesMappedCache.ContainsKey(def))
			{
				return false;
			}
			ResearchOpportunity opportunity = PrototypeOpportunitiesMappedCache[def];
			if (opportunity == null)
			{
				return false;
			}
			if (!evenIfFinished)
			{
				return opportunity.CurrentAvailability == OpportunityAvailability.Available;
			}
			if (opportunity.CurrentAvailability != OpportunityAvailability.Available && opportunity.CurrentAvailability != OpportunityAvailability.Finished)
			{
				return opportunity.CurrentAvailability == OpportunityAvailability.CategoryFinished;
			}
			return true;
		}
		return false;
	}
}
