using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;

namespace PeteTimesSix.ResearchReinvented.Extensions;

public static class SmallExtensions
{
	public static IEnumerable<EnumType> GetFlags<EnumType>(this EnumType e) where EnumType : Enum
	{
		return Enum.GetValues(typeof(EnumType)).Cast<EnumType>().Where(delegate(EnumType v)
		{
			ref EnumType reference = ref e;
			object flag = v;
			return reference.HasFlag((Enum)flag);
		});
	}

	public static Rect OffsetBy(this Rect rect, float x, float y)
	{
		return new Rect(rect.x + x, rect.y + y, rect.width, rect.height);
	}

	public static bool CanUseNow(this Building_ResearchBench bench)
	{
		CompPowerTrader powerComp = bench.GetComp<CompPowerTrader>();
		CompForbiddable forbidComp = bench.GetComp<CompForbiddable>();
		if (bench.Spawned && (powerComp == null || powerComp.PowerOn) && (forbidComp == null || !forbidComp.Forbidden))
		{
			return bench.Faction == Faction.OfPlayer;
		}
		return false;
	}
}
