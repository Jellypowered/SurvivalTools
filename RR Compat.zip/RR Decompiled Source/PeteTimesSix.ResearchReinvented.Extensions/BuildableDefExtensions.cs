using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.HarmonyPatches.Prototypes;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Extensions;

public static class BuildableDefExtensions
{
	public static ResearchProjectDef cacheBuiltForProject = null;

	public static Dictionary<BuildableDef, ResearchOpportunity> _prototypeOpportunitiesMappedCache = new Dictionary<BuildableDef, ResearchOpportunity>();

	public static Dictionary<BuildableDef, ResearchOpportunity> PrototypeOpportunitiesMappedCache
	{
		get
		{
			if (cacheBuiltForProject != Find.ResearchManager.GetProject())
			{
				_prototypeOpportunitiesMappedCache.Clear();
				foreach (ResearchOpportunity op in PrototypeUtilities.PrototypeOpportunities)
				{
					if (op.requirement is ROComp_RequiresThing { AllThings: var allThings })
					{
						foreach (ThingDef thing in allThings)
						{
							_prototypeOpportunitiesMappedCache[thing] = op;
						}
					}
					else if (op.requirement is ROComp_RequiresTerrain { AllTerrains: var allTerrains })
					{
						foreach (TerrainDef terrain in allTerrains)
						{
							_prototypeOpportunitiesMappedCache[terrain] = op;
						}
					}
				}
				cacheBuiltForProject = Find.ResearchManager.GetProject();
			}
			return _prototypeOpportunitiesMappedCache;
		}
	}

	public static bool IsAvailableOnlyForPrototyping(this BuildableDef def, bool evenIfFinished)
	{
		if (def.researchPrerequisites != null && def.researchPrerequisites.Count > 0)
		{
			IEnumerable<ResearchProjectDef> unfinishedPreregs = def.researchPrerequisites.Where((ResearchProjectDef r) => !r.IsFinished);
			if (!unfinishedPreregs.Any())
			{
				return false;
			}
			if (unfinishedPreregs.Any((ResearchProjectDef r) => Find.ResearchManager.GetProject() != r))
			{
				return false;
			}
			if (!PrototypeOpportunitiesMappedCache.ContainsKey(def))
			{
				return false;
			}
			ResearchOpportunity opportunity = PrototypeOpportunitiesMappedCache[def];
			if (opportunity == null)
			{
				return false;
			}
			if (!evenIfFinished)
			{
				return opportunity.CurrentAvailability == OpportunityAvailability.Available;
			}
			if (opportunity.CurrentAvailability != OpportunityAvailability.Available && opportunity.CurrentAvailability != OpportunityAvailability.Finished)
			{
				return opportunity.CurrentAvailability == OpportunityAvailability.CategoryFinished;
			}
			return true;
		}
		return false;
	}
}
