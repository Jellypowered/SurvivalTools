using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Extensions;

public static class DefExtensions
{
	public static bool PassesIdeoCheck(this Def def)
	{
		if (!ModsConfig.IdeologyActive)
		{
			return true;
		}
		if (def is RecipeDef asRecipe)
		{
			return asRecipe.PassesIdeoCheck();
		}
		if (def is BuildableDef { canGenerateDefaultDesignator: false } asBuildable)
		{
			foreach (MemeDef memeDef in DefDatabase<MemeDef>.AllDefsListForReading)
			{
				if (memeDef.AllDesignatorBuildables.Contains(asBuildable) && !Faction.OfPlayer.ideos.HasAnyIdeoWithMeme(memeDef))
				{
					return false;
				}
			}
		}
		return true;
	}
}
