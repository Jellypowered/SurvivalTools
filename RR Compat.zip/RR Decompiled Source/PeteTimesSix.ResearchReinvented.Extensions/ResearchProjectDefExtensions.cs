using System.Collections.Generic;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Extensions;

public static class ResearchProjectDefExtensions
{
	public static bool HasAnyPrerequisites(this ResearchProjectDef project)
	{
		if (project.requiredResearchBuilding == null && project.requiredResearchFacilities.NullOrEmpty())
		{
			if (!ResearchReinventedMod.Settings.kitlessResearch)
			{
				if (ResearchReinventedMod.Settings.kitlessNeolithicResearch)
				{
					return (int)project.techLevel > 2;
				}
				return true;
			}
			return false;
		}
		return true;
	}

	public static bool RequiredToUnlock(this ResearchProjectDef project, IEnumerable<ResearchProjectDef> prerequisites)
	{
		HashSet<ResearchProjectDef> checkedSet = new HashSet<ResearchProjectDef>();
		Queue<ResearchProjectDef> queue = new Queue<ResearchProjectDef>();
		foreach (ResearchProjectDef prerequisite in prerequisites)
		{
			queue.Enqueue(prerequisite);
		}
		while (queue.Count > 0)
		{
			ResearchProjectDef checkedProject = queue.Dequeue();
			if (checkedProject == project)
			{
				return true;
			}
			if (checkedSet.Contains(checkedProject))
			{
				continue;
			}
			checkedSet.Add(checkedProject);
			if (checkedProject.prerequisites != null)
			{
				foreach (ResearchProjectDef prerequisite2 in checkedProject.prerequisites)
				{
					queue.Enqueue(prerequisite2);
				}
			}
			if (checkedProject.hiddenPrerequisites == null)
			{
				continue;
			}
			foreach (ResearchProjectDef prerequisite3 in checkedProject.hiddenPrerequisites)
			{
				queue.Enqueue(prerequisite3);
			}
		}
		return false;
	}
}
