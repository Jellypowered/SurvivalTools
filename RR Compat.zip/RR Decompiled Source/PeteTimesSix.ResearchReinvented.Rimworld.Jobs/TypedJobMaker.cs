using System;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.Jobs;

[Obsolete("Decided not to interfere with the Job system.")]
public static class TypedJobMaker<T> where T : Job, new()
{
	private const int MaxJobPoolSize = 1000;

	public static T MakeJob()
	{
		T job = SimplePool<T>.Get();
		job.loadID = Find.UniqueIDsManager.GetNextJobID();
		return job;
	}

	public static T MakeJob(JobDef def)
	{
		T job = MakeJob();
		job.def = def;
		return job;
	}

	public static T MakeJob(JobDef def, LocalTargetInfo targetA)
	{
		T job = MakeJob();
		job.def = def;
		job.targetA = targetA;
		return job;
	}

	public static T MakeJob(JobDef def, LocalTargetInfo targetA, LocalTargetInfo targetB)
	{
		T job = MakeJob();
		job.def = def;
		job.targetA = targetA;
		job.targetB = targetB;
		return job;
	}

	public static T MakeJob(JobDef def, LocalTargetInfo targetA, LocalTargetInfo targetB, LocalTargetInfo targetC)
	{
		T job = MakeJob();
		job.def = def;
		job.targetA = targetA;
		job.targetB = targetB;
		job.targetC = targetC;
		return job;
	}

	public static T MakeJob(JobDef def, LocalTargetInfo targetA, int expiryInterval, bool checkOverrideOnExpiry = false)
	{
		T job = MakeJob();
		job.def = def;
		job.targetA = targetA;
		job.expiryInterval = expiryInterval;
		job.checkOverrideOnExpire = checkOverrideOnExpiry;
		return job;
	}

	public static T MakeJob(JobDef def, int expiryInterval, bool checkOverrideOnExpiry = false)
	{
		T job = MakeJob();
		job.def = def;
		job.expiryInterval = expiryInterval;
		job.checkOverrideOnExpire = checkOverrideOnExpiry;
		return job;
	}

	public static void ReturnToPool(T job)
	{
		if (job != null && SimplePool<Job>.FreeItemsCount < 1000)
		{
			job.Clear();
			SimplePool<Job>.Return(job);
		}
	}
}
