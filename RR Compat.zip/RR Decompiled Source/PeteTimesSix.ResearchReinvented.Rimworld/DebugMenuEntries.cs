using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using LudeonTK;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Rimworld.UI.Dialogs;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld;

[StaticConstructorOnStartup]
public static class DebugMenuEntries
{
	private const string CATEGORY = "Research Reinvented";

	[DebugAction(null, null, false, false, false, false, false, 0, false, category = "Research Reinvented", actionType = DebugActionType.Action)]
	private static void ToggleDebugPrintouts()
	{
		ResearchReinvented_Debug.debugPrintouts = !ResearchReinvented_Debug.debugPrintouts;
		Log.Message("Toggled debug printouts " + (ResearchReinvented_Debug.debugPrintouts ? "on" : "off"));
	}

	[DebugAction(null, null, false, false, false, false, false, 0, false, category = "Research Reinvented", actionType = DebugActionType.Action)]
	private static void TogglePrototypeGridDrawing()
	{
		ResearchReinvented_Debug.drawPrototypeGrid = !ResearchReinvented_Debug.drawPrototypeGrid;
		Log.Message("Toggled drawing of PrototypeGrid " + (ResearchReinvented_Debug.drawPrototypeGrid ? "on" : "off"));
	}

	[DebugAction(null, null, false, false, false, false, false, 0, false, category = "Research Reinvented", actionType = DebugActionType.Action)]
	private static void ListPrototypes()
	{
		Log.Message("Prototypes: " + string.Join(", ", PrototypeKeeper.Instance.Prototypes));
	}

	[DebugAction(null, null, false, false, false, false, false, 0, false, category = "Research Reinvented", actionType = DebugActionType.Action)]
	private static void ResetResearchProgress()
	{
		Find.ResearchManager.ResetAllProgress();
	}

	[DebugAction(null, null, false, false, false, false, false, 0, false, category = "Research Reinvented", actionType = DebugActionType.Action)]
	private static void RemoveAllResearch()
	{
		ResearchManager researchManager = Find.ResearchManager;
		researchManager.ResetAllProgress();
		if (AccessTools.Field(typeof(ResearchManager), "progress").GetValue(researchManager) is Dictionary<ResearchProjectDef, float> progressDict)
		{
			progressDict.Clear();
			foreach (ResearchProjectDef allDef in DefDatabase<ResearchProjectDef>.AllDefs)
			{
				progressDict.Add(allDef, 0f);
			}
		}
		researchManager.ReapplyAllMods();
	}

	[DebugAction(null, null, false, false, false, false, false, 0, false, category = "Research Reinvented", actionType = DebugActionType.Action)]
	private static void OpenAlternatesMapper()
	{
		Find.WindowStack.Add(new Dialog_AlternateMapper());
	}

	[DebugOutput(category = "Research Reinvented", name = "List special opportunities")]
	public static void SpecialOpportunitiesListing()
	{
		IEnumerable<SpecialResearchOpportunityDef> allDefs = DefDatabase<SpecialResearchOpportunityDef>.AllDefs;
		List<TableDataGetter<SpecialResearchOpportunityDef>> entries = new List<TableDataGetter<SpecialResearchOpportunityDef>>
		{
			new TableDataGetter<SpecialResearchOpportunityDef>("defName", (SpecialResearchOpportunityDef d) => d.defName),
			new TableDataGetter<SpecialResearchOpportunityDef>("label", (SpecialResearchOpportunityDef d) => d.label),
			new TableDataGetter<SpecialResearchOpportunityDef>("type", (SpecialResearchOpportunityDef d) => d.opportunityType?.defName ?? "NULL"),
			new TableDataGetter<SpecialResearchOpportunityDef>("project", (SpecialResearchOpportunityDef d) => d.project?.defName ?? "NULL"),
			new TableDataGetter<SpecialResearchOpportunityDef>("rare", (SpecialResearchOpportunityDef d) => d.rare),
			new TableDataGetter<SpecialResearchOpportunityDef>("freebie", (SpecialResearchOpportunityDef d) => d.freebie),
			new TableDataGetter<SpecialResearchOpportunityDef>("thiCount", (SpecialResearchOpportunityDef d) => (d.things != null) ? ((object)d.things.Count) : "0"),
			new TableDataGetter<SpecialResearchOpportunityDef>("terCount", (SpecialResearchOpportunityDef d) => (d.terrains != null) ? ((object)d.terrains.Count) : "0"),
			new TableDataGetter<SpecialResearchOpportunityDef>("recCount", (SpecialResearchOpportunityDef d) => (d.recipes != null) ? ((object)d.recipes.Count) : "0"),
			new TableDataGetter<SpecialResearchOpportunityDef>("things", (SpecialResearchOpportunityDef d) => (d.things != null) ? string.Join(", ", d.things.Select((ThingDef a) => a.defName)) : "NULL"),
			new TableDataGetter<SpecialResearchOpportunityDef>("terrains", (SpecialResearchOpportunityDef d) => (d.terrains != null) ? string.Join(", ", d.terrains.Select((TerrainDef a) => a.defName)) : "NULL"),
			new TableDataGetter<SpecialResearchOpportunityDef>("recipes", (SpecialResearchOpportunityDef d) => (d.recipes != null) ? string.Join(", ", d.recipes.Select((RecipeDef a) => a.defName)) : "NULL")
		};
		DebugTables.MakeTablesDialog(allDefs, entries.ToArray());
	}

	[DebugOutput(category = "Research Reinvented", name = "List alternates")]
	public static void AlternatesListing()
	{
		IEnumerable<AlternateResearchSubjectsDef> allDefs = DefDatabase<AlternateResearchSubjectsDef>.AllDefs;
		List<TableDataGetter<AlternateResearchSubjectsDef>> entries = new List<TableDataGetter<AlternateResearchSubjectsDef>>
		{
			new TableDataGetter<AlternateResearchSubjectsDef>("defName", (AlternateResearchSubjectsDef d) => d.defName),
			new TableDataGetter<AlternateResearchSubjectsDef>("label", (AlternateResearchSubjectsDef d) => d.label),
			new TableDataGetter<AlternateResearchSubjectsDef>("originals", (AlternateResearchSubjectsDef d) => (d.originals != null) ? string.Join(", ", d.originals.Select((ThingDef a) => a.defName)) : "NULL"),
			new TableDataGetter<AlternateResearchSubjectsDef>("originalTerrains", (AlternateResearchSubjectsDef d) => (d.originalTerrains != null) ? string.Join(", ", d.originalTerrains.Select((TerrainDef a) => a.defName)) : "NULL"),
			new TableDataGetter<AlternateResearchSubjectsDef>("altEqCount", (AlternateResearchSubjectsDef d) => (d.alternatesEquivalent != null) ? ((object)d.alternatesEquivalent.Count) : "0"),
			new TableDataGetter<AlternateResearchSubjectsDef>("altSiCount", (AlternateResearchSubjectsDef d) => (d.alternatesSimilar != null) ? ((object)d.alternatesSimilar.Count) : "0"),
			new TableDataGetter<AlternateResearchSubjectsDef>("altEqCountTer", (AlternateResearchSubjectsDef d) => (d.alternateEquivalentTerrains != null) ? ((object)d.alternateEquivalentTerrains.Count) : "0"),
			new TableDataGetter<AlternateResearchSubjectsDef>("altSCountTer", (AlternateResearchSubjectsDef d) => (d.alternateSimilarTerrains != null) ? ((object)d.alternateSimilarTerrains.Count) : "0"),
			new TableDataGetter<AlternateResearchSubjectsDef>("altEqCountRec", (AlternateResearchSubjectsDef d) => (d.alternateEquivalentRecipes != null) ? ((object)d.alternateEquivalentRecipes.Count) : "0"),
			new TableDataGetter<AlternateResearchSubjectsDef>("altSiCountRec", (AlternateResearchSubjectsDef d) => (d.alternateSimilarRecipes != null) ? ((object)d.alternateSimilarRecipes.Count) : "0"),
			new TableDataGetter<AlternateResearchSubjectsDef>("alternatesEquivalent", (AlternateResearchSubjectsDef d) => (d.alternatesEquivalent != null) ? string.Join(", ", d.alternatesEquivalent.Select((ThingDef a) => a.defName)) : "NULL"),
			new TableDataGetter<AlternateResearchSubjectsDef>("alternatesSimilar", (AlternateResearchSubjectsDef d) => (d.alternatesSimilar != null) ? string.Join(", ", d.alternatesSimilar.Select((ThingDef a) => a.defName)) : "NULL"),
			new TableDataGetter<AlternateResearchSubjectsDef>("alternateEquivalentTerrains", (AlternateResearchSubjectsDef d) => (d.alternateEquivalentTerrains != null) ? string.Join(", ", d.alternateEquivalentTerrains.Select((TerrainDef a) => a.defName)) : "NULL"),
			new TableDataGetter<AlternateResearchSubjectsDef>("alternateSimilarTerrains", (AlternateResearchSubjectsDef d) => (d.alternateSimilarTerrains != null) ? string.Join(", ", d.alternateSimilarTerrains.Select((TerrainDef a) => a.defName)) : "NULL"),
			new TableDataGetter<AlternateResearchSubjectsDef>("alternateEquivalentRecipes", (AlternateResearchSubjectsDef d) => (d.alternateEquivalentRecipes != null) ? string.Join(", ", d.alternateEquivalentRecipes.Select((RecipeDef a) => a.defName)) : "NULL"),
			new TableDataGetter<AlternateResearchSubjectsDef>("alternateSimilarRecipes", (AlternateResearchSubjectsDef d) => (d.alternateSimilarRecipes != null) ? string.Join(", ", d.alternateSimilarRecipes.Select((RecipeDef a) => a.defName)) : "NULL")
		};
		DebugTables.MakeTablesDialog(allDefs, entries.ToArray());
	}
}
