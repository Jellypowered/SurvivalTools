using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld;

public class RR_UniqueIDsManager : GameComponent, IExposable
{
	private int nextOpportunityID;

	private bool wasLoaded;

	public static RR_UniqueIDsManager instance => Current.Game.GetComponent<RR_UniqueIDsManager>();

	public int GetNextResearchOpportunityID()
	{
		return GetNextID(ref nextOpportunityID);
	}

	public RR_UniqueIDsManager(Game game)
	{
	}

	private static int GetNextID(ref int nextID)
	{
		if (Scribe.mode == LoadSaveMode.LoadingVars && !instance.wasLoaded)
		{
			Log.Warning("Getting next unique ID during LoadingVars before UniqueIDsManager was loaded. Assigning a random value.");
			return Rand.Int;
		}
		if (Scribe.mode == LoadSaveMode.Saving)
		{
			Log.Warning("Getting next unique ID during saving This may cause bugs.");
		}
		int result = nextID;
		nextID++;
		if (nextID == int.MaxValue)
		{
			Log.Warning("Next ID is at max value. Resetting to 0. This may cause bugs.");
			nextID = 0;
		}
		return result;
	}

	public override void ExposeData()
	{
		Scribe_Values.Look(ref nextOpportunityID, "nextOpportunityID", 0, forceSave: true);
		if (Scribe.mode == LoadSaveMode.LoadingVars)
		{
			wasLoaded = true;
		}
	}
}
