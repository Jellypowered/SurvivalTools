using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld;

[StaticConstructorOnStartup]
public static class Textures
{
	public static readonly Texture2D translucentWhite = SolidColorMaterials.NewSolidColorTexture(new Color(1f, 1f, 1f, 0.5f));

	public static readonly Texture2D mostlyTransparentWhite = SolidColorMaterials.NewSolidColorTexture(new Color(1f, 1f, 1f, 0.05f));

	public static readonly Texture2D scienceIcon = ContentFinder<Texture2D>.Get("scienceIcon");

	public static readonly Texture2D scienceIconDark = ContentFinder<Texture2D>.Get("scienceIconDark");

	public static readonly Texture2D medicalInvasiveIcon = ContentFinder<Texture2D>.Get("UI/icons/medical");

	public static readonly Texture2D medicalNoninvasiveIcon = ContentFinder<Texture2D>.Get("UI/icons/pills");

	public static readonly Texture2D genericIcon = ContentFinder<Texture2D>.Get("UI/icons/question");

	public static readonly Texture2D genericPawnIcon = ContentFinder<Texture2D>.Get("UI/icons/questionPawn");

	public static readonly Texture2D corpseIconOverlay = ContentFinder<Texture2D>.Get("UI/icons/corpseOverlay");

	public static readonly Texture2D forbiddenOverlayTex = ContentFinder<Texture2D>.Get("Things/Special/ForbiddenOverlay");
}
