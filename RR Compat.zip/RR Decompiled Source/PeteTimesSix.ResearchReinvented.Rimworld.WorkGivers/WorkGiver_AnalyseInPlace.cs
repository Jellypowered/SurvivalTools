using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;
using PeteTimesSix.ResearchReinvented.Rimworld.MiscData;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;

public class WorkGiver_AnalyseInPlace : WorkGiver_Scanner
{
	public static Type DriverClass = typeof(JobDriver_AnalyseInPlace);

	private static ResearchProjectDef _matchingOpportunitiesCachedFor;

	private static ResearchOpportunity[] _matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();

	private static int cacheBuiltOnTick = -1;

	private static Dictionary<ThingDef, HashSet<ResearchOpportunity>> _opportunityCache = new Dictionary<ThingDef, HashSet<ResearchOpportunity>>();

	public static Dictionary<Map, List<Thing>> _things = new Dictionary<Map, List<Thing>>();

	public override bool Prioritized => true;

	private static IEnumerable<ResearchOpportunity> MatchingOpportunities
	{
		get
		{
			if (_matchingOpportunitiesCachedFor != Find.ResearchManager.GetProject())
			{
				_matchingOpportunitesCache = ResearchOpportunityManager.Instance.GetFilteredOpportunities(null, HandlingMode.Job_Analysis, DriverClass).ToArray();
				_matchingOpportunitiesCachedFor = Find.ResearchManager.GetProject();
			}
			return _matchingOpportunitesCache;
		}
	}

	public static Dictionary<ThingDef, HashSet<ResearchOpportunity>> OpportunityCache
	{
		get
		{
			if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
			{
				BuildCache();
			}
			return _opportunityCache;
		}
	}

	public static void ClearMatchingOpportunityCache()
	{
		_matchingOpportunitiesCachedFor = null;
		_matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();
	}

	public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
	{
		if (Find.ResearchManager.GetProject() == null)
		{
			return Enumerable.Empty<Thing>();
		}
		return ThingsForMap(pawn.MapHeld);
	}

	public override bool ShouldSkip(Pawn pawn, bool forced = false)
	{
		ResearchProjectDef currentProj = Find.ResearchManager.GetProject();
		if (currentProj == null)
		{
			return true;
		}
		return !MatchingOpportunities.Any((ResearchOpportunity o) => !o.IsFinished);
	}

	public override bool HasJobOnThing(Pawn pawn, Thing thing, bool forced = false)
	{
		if (thing.IsForbidden(pawn))
		{
			return false;
		}
		if (!pawn.CanReserve(thing, 1, -1, null, forced))
		{
			return false;
		}
		ResearchOpportunity opportunity = FilterCacheFor(thing, pawn).FirstOrDefault();
		if (PrototypeKeeper.Instance.IsPrototype(thing) && opportunity.relation != ResearchRelation.Ancestor)
		{
			JobFailReason.Is(StringsCache.JobFail_IsPrototype);
			return false;
		}
		if (Find.ResearchManager.GetProject().HasAnyPrerequisites() && !FieldResearchHelper.GetValidResearchKits(pawn, Find.ResearchManager.GetProject()).Any())
		{
			JobFailReason.Is(StringsCache.JobFail_NeedResearchKit);
			return false;
		}
		if (thing.def.hasInteractionCell)
		{
			if (!pawn.CanReserveSittableOrSpot(thing.InteractionCell, forced))
			{
				return false;
			}
		}
		else
		{
			IEnumerable<IntVec3> reachable = AdjacencyHelper.GenReachableAdjacentCells(thing, pawn, cardinalOnly: true);
			if (!reachable.Any())
			{
				return false;
			}
		}
		return new HistoryEvent(HistoryEventDefOf.Researching, pawn.Named(HistoryEventArgsNames.Doer)).Notify_PawnAboutToDo_Job();
	}

	public override Job JobOnThing(Pawn pawn, Thing thing, bool forced = false)
	{
		ResearchOpportunity opportunity = FilterCacheFor(thing, pawn).First();
		JobDef jobDef = opportunity.JobDefs.First((JobDef j) => j.driverClass == DriverClass);
		return JobMaker.MakeJob(jobDef, thing, 1500, checkOverrideOnExpiry: true);
	}

	public static List<Thing> ThingsForMap(Map map)
	{
		if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
		{
			BuildCache();
		}
		return _things[map];
	}

	public static void BuildCache()
	{
		_opportunityCache.Clear();
		_things.Clear();
		if (Find.ResearchManager.GetProject() == null)
		{
			return;
		}
		foreach (ResearchOpportunity opportunity in MatchingOpportunities.Where((ResearchOpportunity o) => o.CurrentAvailability == OpportunityAvailability.Available && o.requirement is ROComp_RequiresThing))
		{
			ThingDef[] thingDefs = (opportunity.requirement as ROComp_RequiresThing)?.AllThings;
			if (thingDefs == null || thingDefs.Length == 0)
			{
				Log.ErrorOnce($"RR: current research project {Find.ResearchManager.GetProject()} generated a WorkGiver_AnalyzeInPlace opportunity with null or empty requirement!", Find.ResearchManager.GetProject().debugRandomId);
				continue;
			}
			ThingDef[] array = thingDefs;
			foreach (ThingDef thingDef in array)
			{
				if (!_opportunityCache.ContainsKey(thingDef))
				{
					_opportunityCache[thingDef] = new HashSet<ResearchOpportunity>();
				}
				_opportunityCache[thingDef].Add(opportunity);
			}
		}
		List<ThingDef> defsToFind = _opportunityCache.Keys.ToList();
		foreach (Map map in Find.Maps)
		{
			List<Thing> list = new List<Thing>();
			_things[map] = list;
			foreach (ThingDef thingDef2 in defsToFind)
			{
				List<Thing> things = map.listerThings.ThingsOfDef(thingDef2);
				foreach (Thing thing in things)
				{
					if (thing.FactionAllowsAnalysis())
					{
						list.Add(thing);
					}
				}
			}
		}
		cacheBuiltOnTick = Find.TickManager.TicksAbs;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static HashSet<ResearchOpportunity> FilterCacheFor(Thing thing, Pawn pawn)
	{
		return OpportunityCache[thing.def];
	}
}
