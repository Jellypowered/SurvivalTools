using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;
using PeteTimesSix.ResearchReinvented.Rimworld.MiscData;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;

public class WorkGiver_AnalyseTerrain : WorkGiver_Scanner
{
	public static Type DriverClass = typeof(JobDriver_AnalyseTerrain);

	private static ResearchProjectDef _matchingOpportunitiesCachedFor;

	private static ResearchOpportunity[] _matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();

	private static int cacheBuiltOnTick = -1;

	private static Dictionary<TerrainDef, HashSet<ResearchOpportunity>> _opportunityCache = new Dictionary<TerrainDef, HashSet<ResearchOpportunity>>();

	public override bool AllowUnreachable => false;

	public override PathEndMode PathEndMode => PathEndMode.Touch;

	public override bool Prioritized => true;

	private static IEnumerable<ResearchOpportunity> MatchingOpportunities
	{
		get
		{
			if (_matchingOpportunitiesCachedFor != Find.ResearchManager.GetProject())
			{
				_matchingOpportunitesCache = ResearchOpportunityManager.Instance.GetFilteredOpportunities(null, HandlingMode.Job_Analysis, DriverClass).ToArray();
				_matchingOpportunitiesCachedFor = Find.ResearchManager.GetProject();
			}
			return _matchingOpportunitesCache;
		}
	}

	public static Dictionary<TerrainDef, HashSet<ResearchOpportunity>> OpportunityCache
	{
		get
		{
			if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
			{
				BuildCache();
			}
			return _opportunityCache;
		}
	}

	public static void ClearMatchingOpportunityCache()
	{
		_matchingOpportunitiesCachedFor = null;
		_matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();
	}

	public override IEnumerable<IntVec3> PotentialWorkCellsGlobal(Pawn pawn)
	{
		if (Find.ResearchManager.GetProject() == null)
		{
			return Enumerable.Empty<IntVec3>();
		}
		return pawn.Map.areaManager.Home.ActiveCells;
	}

	public override bool ShouldSkip(Pawn pawn, bool forced = false)
	{
		ResearchProjectDef currentProj = Find.ResearchManager.GetProject();
		if (currentProj == null)
		{
			return true;
		}
		return !MatchingOpportunities.Any();
	}

	public override bool HasJobOnCell(Pawn pawn, IntVec3 cell, bool forced = false)
	{
		ResearchProjectDef currentProj = Find.ResearchManager.GetProject();
		if (currentProj == null)
		{
			return false;
		}
		if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
		{
			BuildCache();
		}
		(TerrainLayer, ResearchOpportunity)? opportunity = FindOpportunityAt(pawn, cell);
		if (!opportunity.HasValue)
		{
			return false;
		}
		if (currentProj.HasAnyPrerequisites() && !FieldResearchHelper.GetValidResearchKits(pawn, currentProj).Any())
		{
			JobFailReason.Is(StringsCache.JobFail_NeedResearchKit);
			return false;
		}
		if (opportunity.Value.Item2.relation != ResearchRelation.Ancestor)
		{
			bool isPrototype = false;
			switch (opportunity.Value.Item1)
			{
			case TerrainLayer.TOP:
				isPrototype = PrototypeKeeper.Instance.IsTerrainPrototype(cell, pawn.Map);
				break;
			case TerrainLayer.FOUNDATION:
				isPrototype = PrototypeKeeper.Instance.IsFoundationTerrainPrototype(cell, pawn.Map);
				break;
			}
			if (isPrototype)
			{
				JobFailReason.Is(StringsCache.JobFail_IsPrototype);
				return false;
			}
		}
		if (!cell.IsForbidden(pawn) && pawn.CanReserve(cell, 1, -1, null, forced))
		{
			return new HistoryEvent(HistoryEventDefOf.Researching, pawn.Named(HistoryEventArgsNames.Doer)).Notify_PawnAboutToDo_Job();
		}
		return false;
	}

	public override Job JobOnCell(Pawn pawn, IntVec3 cell, bool forced = false)
	{
		(TerrainLayer, ResearchOpportunity)? opportunityAt = FindOpportunityAt(pawn, cell);
		if (!opportunityAt.HasValue)
		{
			Log.Warning("JobOnCell could not find opportunity at " + cell.ToString() + " but HasJobOnCell approved it!");
			return null;
		}
		JobDef jobDef = opportunityAt.Value.Item2.JobDefs.First((JobDef j) => j.driverClass == DriverClass);
		return JobMaker.MakeJob(jobDef, cell, 1500, checkOverrideOnExpiry: true);
	}

	public override float GetPriority(Pawn pawn, TargetInfo target)
	{
		IntVec3 cell = target.Cell;
		(TerrainLayer, ResearchOpportunity)? opportunityAt = FindOpportunityAt(pawn, cell);
		if (!opportunityAt.HasValue)
		{
			Log.Warning("GetPriority could not find opportunity at " + cell.ToString() + " but HasJobOnCell approved it!");
			return 0f;
		}
		ResearchOpportunity opportunity = opportunityAt.Value.Item2;
		float dist = cell.DistanceTo(pawn.Position);
		if (dist < 4f)
		{
			dist = 4f - dist + 4f;
		}
		float prio = 1f / dist - 3f;
		prio += Rand.Range(0f, 0.25f);
		return prio * pawn.GetStatValue(StatDefOf_Custom.FieldResearchSpeedMultiplier) * opportunity.def.GetCategory(opportunity.relation).Settings.researchSpeedMultiplier;
	}

	public static (TerrainLayer type, ResearchOpportunity opportunity)? FindOpportunityAt(Pawn pawn, IntVec3 cell)
	{
		TerrainDef tempTerrainAt = pawn.Map.terrainGrid.TempTerrainAt(pawn.Map.cellIndices.CellToIndex(cell));
		if (tempTerrainAt != null)
		{
			ResearchOpportunity opportunity = FilterCacheFor(tempTerrainAt, pawn)?.FirstOrDefault();
			if (opportunity != null)
			{
				return (TerrainLayer.TEMP, opportunity);
			}
		}
		TerrainDef topTerrainAt = pawn.Map.terrainGrid.TopTerrainAt(pawn.Map.cellIndices.CellToIndex(cell));
		if (topTerrainAt != null)
		{
			ResearchOpportunity opportunity2 = FilterCacheFor(topTerrainAt, pawn)?.FirstOrDefault();
			if (opportunity2 != null)
			{
				return (TerrainLayer.TOP, opportunity2);
			}
		}
		TerrainDef foundationAt = pawn.Map.terrainGrid.FoundationAt(pawn.Map.cellIndices.CellToIndex(cell));
		if (foundationAt != null)
		{
			ResearchOpportunity opportunity3 = FilterCacheFor(foundationAt, pawn)?.FirstOrDefault();
			if (opportunity3 != null)
			{
				return (TerrainLayer.FOUNDATION, opportunity3);
			}
		}
		return null;
	}

	public static void BuildCache()
	{
		_opportunityCache.Clear();
		if (Find.ResearchManager.GetProject() == null)
		{
			return;
		}
		foreach (ResearchOpportunity opportunity in MatchingOpportunities.Where((ResearchOpportunity o) => o.CurrentAvailability == OpportunityAvailability.Available && o.requirement is ROComp_RequiresTerrain))
		{
			TerrainDef[] terrainDefs = (opportunity.requirement as ROComp_RequiresTerrain)?.AllTerrains;
			if (terrainDefs == null || terrainDefs.Length == 0)
			{
				Log.ErrorOnce($"RR: current research project {Find.ResearchManager.GetProject()} generated a WorkGiver_Analyze opportunity with null or empty requirement!", Find.ResearchManager.GetProject().debugRandomId);
				continue;
			}
			TerrainDef[] array = terrainDefs;
			foreach (TerrainDef terrainDef in array)
			{
				if (!_opportunityCache.ContainsKey(terrainDef))
				{
					_opportunityCache[terrainDef] = new HashSet<ResearchOpportunity>();
				}
				_opportunityCache[terrainDef].Add(opportunity);
			}
		}
		cacheBuiltOnTick = Find.TickManager.TicksAbs;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static HashSet<ResearchOpportunity> FilterCacheFor(TerrainDef terrainDef, Pawn pawn)
	{
		return OpportunityCache.TryGetValue(terrainDef);
	}
}
