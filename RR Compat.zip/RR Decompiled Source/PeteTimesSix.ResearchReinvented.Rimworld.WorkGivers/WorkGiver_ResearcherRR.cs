using System;
using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;

public class WorkGiver_ResearcherRR : WorkGiver_Scanner
{
	public static Type DriverClass = typeof(JobDriver_ResearchRR);

	private static ResearchProjectDef _matchingOpportunitiesCachedFor;

	private static ResearchOpportunity[] _matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();

	private static int cacheBuiltOnTick = -1;

	private static ResearchOpportunity _opportunityCache;

	public static IEnumerable<ResearchOpportunity> MatchingOpportunities
	{
		get
		{
			if (_matchingOpportunitiesCachedFor != Find.ResearchManager.GetProject())
			{
				_matchingOpportunitesCache = ResearchOpportunityManager.Instance.GetFilteredOpportunities(null, HandlingMode.Job_Theory, DriverClass).ToArray();
				_matchingOpportunitiesCachedFor = Find.ResearchManager.GetProject();
			}
			return _matchingOpportunitesCache;
		}
	}

	public override ThingRequest PotentialWorkThingRequest
	{
		get
		{
			if (Find.ResearchManager.GetProject() == null)
			{
				return ThingRequest.ForGroup(ThingRequestGroup.Nothing);
			}
			return ThingRequest.ForGroup(ThingRequestGroup.ResearchBench);
		}
	}

	public override bool Prioritized => true;

	public static ResearchOpportunity OpportunityCache
	{
		get
		{
			if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
			{
				_opportunityCache = MatchingOpportunities.Where((ResearchOpportunity o) => o.CurrentAvailability == OpportunityAvailability.Available).FirstOrDefault();
			}
			return _opportunityCache;
		}
	}

	public static void ClearMatchingOpportunityCache()
	{
		_matchingOpportunitiesCachedFor = null;
		_matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();
	}

	public override bool ShouldSkip(Pawn pawn, bool forced = false)
	{
		if (Find.ResearchManager.GetProject() != null)
		{
			return OpportunityCache == null;
		}
		return true;
	}

	public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
	{
		ResearchProjectDef currentProj = Find.ResearchManager.GetProject();
		if (currentProj == null)
		{
			return false;
		}
		ResearchOpportunity opportunity = OpportunityCache;
		if (opportunity == null)
		{
			return false;
		}
		if (t is Building_ResearchBench building_ResearchBench && opportunity != null && currentProj.CanBeResearchedAt(building_ResearchBench, ignoreResearchBenchPowerStatus: false) && !building_ResearchBench.IsForbidden(pawn) && pawn.CanReserve(t, 1, -1, null, forced) && (!t.def.hasInteractionCell || pawn.CanReserveSittableOrSpot(t.InteractionCell, forced)))
		{
			return new HistoryEvent(HistoryEventDefOf.Researching, pawn.Named(HistoryEventArgsNames.Doer)).Notify_PawnAboutToDo_Job();
		}
		return false;
	}

	public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
	{
		ResearchOpportunity opportunity = MatchingOpportunities.FirstOrDefault();
		JobDef jobDef = opportunity.JobDefs.First((JobDef j) => j.driverClass == DriverClass);
		return JobMaker.MakeJob(jobDef, t, 3000, checkOverrideOnExpiry: true);
	}

	public override float GetPriority(Pawn pawn, TargetInfo t)
	{
		return t.Thing.GetStatValue(StatDefOf.ResearchSpeedFactor);
	}
}
