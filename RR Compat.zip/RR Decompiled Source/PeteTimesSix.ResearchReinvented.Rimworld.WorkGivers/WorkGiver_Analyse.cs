using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.ModCompat;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;

public class WorkGiver_Analyse : WorkGiver_Scanner
{
	public static Type DriverClass = typeof(JobDriver_Analyse);

	private static ResearchProjectDef _matchingOpportunitiesCachedFor;

	private static ResearchOpportunity[] _matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();

	public static int cacheBuiltOnTick = -1;

	public static Dictionary<Map, List<Building_ResearchBench>> _goodBenchCache = new Dictionary<Map, List<Building_ResearchBench>>();

	public static Dictionary<Pawn, Building_ResearchBench> _benchCache = new Dictionary<Pawn, Building_ResearchBench>();

	public static Dictionary<ThingDef, HashSet<ResearchOpportunity>> _opportunityCache = new Dictionary<ThingDef, HashSet<ResearchOpportunity>>();

	public static Dictionary<Map, List<Thing>> _things = new Dictionary<Map, List<Thing>>();

	public static IEnumerable<ResearchOpportunity> MatchingOpportunities
	{
		get
		{
			if (_matchingOpportunitiesCachedFor != Find.ResearchManager.GetProject())
			{
				_matchingOpportunitesCache = ResearchOpportunityManager.Instance.GetFilteredOpportunities(null, HandlingMode.Job_Analysis, DriverClass).ToArray();
				_matchingOpportunitiesCachedFor = Find.ResearchManager.GetProject();
			}
			return _matchingOpportunitesCache;
		}
	}

	public static Dictionary<ThingDef, HashSet<ResearchOpportunity>> OpportunityCache
	{
		get
		{
			if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
			{
				BuildCache();
			}
			return _opportunityCache;
		}
	}

	public static void ClearMatchingOpportunityCache()
	{
		_matchingOpportunitiesCachedFor = null;
		_matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();
	}

	public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
	{
		if (Find.ResearchManager.GetProject() == null)
		{
			return Enumerable.Empty<Thing>();
		}
		return ThingsForMap(pawn.MapHeld);
	}

	public override bool ShouldSkip(Pawn pawn, bool forced = false)
	{
		if (Find.ResearchManager.GetProject() == null)
		{
			return true;
		}
		return !MatchingOpportunities.Any((ResearchOpportunity o) => !o.IsFinished);
	}

	public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
	{
		if (t.IsForbidden(pawn))
		{
			return false;
		}
		if (!pawn.CanReserve(t, 1, -1, null, forced))
		{
			return false;
		}
		Thing actualThing = t.GetInnerIfMinified();
		ResearchOpportunity opportunity = FilterCacheFor(actualThing, pawn).FirstOrDefault();
		if (PrototypeKeeper.Instance.IsPrototype(t) && opportunity.relation != ResearchRelation.Ancestor)
		{
			JobFailReason.Is(StringsCache.JobFail_IsPrototype);
			return false;
		}
		Building_ResearchBench researchBench = GetBestResearchBench(pawn);
		if (researchBench == null)
		{
			JobFailReason.Is(StringsCache.JobFail_NeedResearchBench);
			return false;
		}
		if (!pawn.CanReserveSittableOrSpot(researchBench.InteractionCell, forced) || !new HistoryEvent(HistoryEventDefOf.Researching, pawn.Named(HistoryEventArgsNames.Doer)).Notify_PawnAboutToDo_Job())
		{
			return false;
		}
		return true;
	}

	public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
	{
		Building_ResearchBench researchBench = GetBestResearchBench(pawn);
		Thing actualThing = t.GetInnerIfMinified();
		if (!OpportunityCache.ContainsKey(actualThing.def))
		{
			Log.Warning($"opportunity cache did not contain {actualThing.def} for thing {t}");
			return null;
		}
		ResearchOpportunity opportunity = FilterCacheFor(actualThing, pawn).First();
		JobDef jobDef = opportunity.JobDefs.First((JobDef j) => j.driverClass == DriverClass);
		Job job = JobMaker.MakeJob(jobDef, t, 20000, checkOverrideOnExpiry: true);
		job.targetB = researchBench;
		job.count = 1;
		return job;
	}

	public static List<Thing> ThingsForMap(Map map)
	{
		if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
		{
			BuildCache();
		}
		return _things[map];
	}

	public Building_ResearchBench GetBestResearchBench(Pawn pawn)
	{
		if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
		{
			BuildCache();
		}
		if (!_benchCache.ContainsKey(pawn))
		{
			List<Building_ResearchBench> benches = _goodBenchCache[pawn.MapHeld];
			bool found = false;
			foreach (Building_ResearchBench researchBench in benches)
			{
				if (researchBench.IsForbidden(pawn) || !pawn.CanReserveAndReach(new LocalTargetInfo(researchBench), PathEndMode.InteractionCell, Danger.Unspecified))
				{
					continue;
				}
				if (ResearchData.active && ResearchReinventedMod.Settings.researchDataCompatMode == ResearchData.ResearchDataCompatMode.AllBenchResearch)
				{
					CompRefuelable comp = researchBench.TryGetComp<CompRefuelable>();
					if (comp != null && !comp.HasFuel)
					{
						continue;
					}
				}
				found = true;
				_benchCache[pawn] = researchBench;
				break;
			}
			if (!found)
			{
				_benchCache[pawn] = null;
			}
		}
		return _benchCache[pawn];
	}

	public static void BuildCache()
	{
		_goodBenchCache.Clear();
		_benchCache.Clear();
		_opportunityCache.Clear();
		_things.Clear();
		if (Find.ResearchManager.GetProject() == null)
		{
			return;
		}
		foreach (ResearchOpportunity opportunity in MatchingOpportunities.Where((ResearchOpportunity o) => o.CurrentAvailability == OpportunityAvailability.Available && o.requirement is ROComp_RequiresThing))
		{
			ThingDef[] thingDefs = ((opportunity.requirement is ROComp_RequiresThing requiresThingComp) ? requiresThingComp.AllThings : null);
			if (thingDefs == null || thingDefs.Length == 0)
			{
				Log.ErrorOnce($"RR: current research project {Find.ResearchManager.GetProject()} generated a WorkGiver_Analyze opportunity with null or empty requirement!", Find.ResearchManager.GetProject().debugRandomId);
				continue;
			}
			ThingDef[] array = thingDefs;
			foreach (ThingDef thingDef in array)
			{
				if (!_opportunityCache.ContainsKey(thingDef))
				{
					_opportunityCache[thingDef] = new HashSet<ResearchOpportunity>();
				}
				_opportunityCache[thingDef].Add(opportunity);
			}
		}
		foreach (Map map in Find.Maps)
		{
			List<Thing> list = new List<Thing>();
			_things[map] = list;
			foreach (Thing thing in map.listerThings.ThingsInGroup(ThingRequestGroup.HaulableEver))
			{
				if (thing.FactionAllowsAnalysis())
				{
					Thing unminifiedThing = thing.GetInnerIfMinified();
					ThingDef thingDef2 = unminifiedThing.def;
					if (_opportunityCache.ContainsKey(thingDef2))
					{
						list.Add(thing);
					}
				}
			}
			ResearchProjectDef currentProj = Find.ResearchManager.GetProject();
			List<Building_ResearchBench> list2 = new List<Building_ResearchBench>();
			foreach (Thing benchThing in map.listerThings.ThingsInGroup(ThingRequestGroup.ResearchBench))
			{
				if (benchThing is Building_ResearchBench researchBench && currentProj.CanBeResearchedAt(researchBench, ignoreResearchBenchPowerStatus: false))
				{
					list2.Add(researchBench);
				}
			}
			_goodBenchCache[map] = list2;
		}
		cacheBuiltOnTick = Find.TickManager.TicksAbs;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static HashSet<ResearchOpportunity> FilterCacheFor(Thing thing, Pawn pawn)
	{
		return OpportunityCache[thing.def];
	}
}
