namespace PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;

public enum TerrainLayer
{
	TEMP,
	TOP,
	FOUNDATION
}
