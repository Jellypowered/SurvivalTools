using System;
using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Rimworld.JobDrivers;
using RimWorld;
using Verse;
using Verse.AI;

namespace PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;

public class WorkGiver_LearnRemotely : WorkGiver_Scanner
{
	public static Type DriverClass = typeof(JobDriver_LearnRemotely);

	private static ResearchProjectDef _matchingOpportunitiesCachedFor;

	private static ResearchOpportunity[] _matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();

	private static ThingDef[] _commsConsoles;

	private static int cacheBuiltOnTick = -1;

	private static ResearchOpportunity _opportunityCache;

	public static IEnumerable<ResearchOpportunity> MatchingOpportunities
	{
		get
		{
			if (_matchingOpportunitiesCachedFor != Find.ResearchManager.GetProject())
			{
				_matchingOpportunitesCache = ResearchOpportunityManager.Instance.GetFilteredOpportunities(null, HandlingMode.Social, (ResearchOpportunity op) => op.requirement is ROComp_RequiresFaction rOComp_RequiresFaction && rOComp_RequiresFaction.faction != Faction.OfPlayer).ToArray();
				_matchingOpportunitiesCachedFor = Find.ResearchManager.GetProject();
			}
			return _matchingOpportunitesCache;
		}
	}

	public static ThingDef[] CommsConsoles
	{
		get
		{
			if (_commsConsoles == null)
			{
				List<ThingDef> consoles = new List<ThingDef>();
				foreach (ThingDef def in DefDatabase<ThingDef>.AllDefsListForReading)
				{
					if (def.IsCommsConsole)
					{
						consoles.Add(def);
					}
				}
				_commsConsoles = consoles.ToArray();
			}
			return _commsConsoles;
		}
	}

	public static ResearchOpportunity OpportunityCache
	{
		get
		{
			if (cacheBuiltOnTick != Find.TickManager.TicksAbs)
			{
				_opportunityCache = (from o in MatchingOpportunities
					where o.CurrentAvailability == OpportunityAvailability.Available && o.requirement is ROComp_RequiresFaction rOComp_RequiresFaction && !FactionLectureManager.Instance.IsOnCooldown(rOComp_RequiresFaction.faction) && rOComp_RequiresFaction != null && rOComp_RequiresFaction.faction.RelationKindWith(Faction.OfPlayer) == FactionRelationKind.Ally
					orderby o.MaximumProgress descending
					select o).FirstOrDefault();
			}
			return _opportunityCache;
		}
	}

	public static void ClearMatchingOpportunityCache()
	{
		_matchingOpportunitiesCachedFor = null;
		_matchingOpportunitesCache = Array.Empty<ResearchOpportunity>();
	}

	public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
	{
		if (pawn.Map == null || CommsConsoles.Length == 0)
		{
			return Enumerable.Empty<Thing>();
		}
		List<Thing> consoles = new List<Thing>();
		ThingDef[] commsConsoles = CommsConsoles;
		foreach (ThingDef def in commsConsoles)
		{
			consoles.AddRange(pawn.Map?.listerThings.ThingsOfDef(def));
		}
		return consoles;
	}

	public override bool ShouldSkip(Pawn pawn, bool forced = false)
	{
		if (Find.ResearchManager.GetProject() == null)
		{
			return true;
		}
		return !MatchingOpportunities.Any((ResearchOpportunity o) => !o.IsFinished);
	}

	public override bool HasJobOnThing(Pawn pawn, Thing thing, bool forced = false)
	{
		if (thing.IsForbidden(pawn))
		{
			return false;
		}
		if (!pawn.CanReserve(thing, 1, -1, null, forced))
		{
			return false;
		}
		if (!(thing is Building_CommsConsole commsConsole))
		{
			return false;
		}
		if (!commsConsole.CanUseCommsNow)
		{
			return false;
		}
		if (OpportunityCache == null)
		{
			return false;
		}
		if (!pawn.CanReserveSittableOrSpot(thing.InteractionCell, forced) || !new HistoryEvent(HistoryEventDefOf.Researching, pawn.Named(HistoryEventArgsNames.Doer)).Notify_PawnAboutToDo_Job())
		{
			return false;
		}
		return true;
	}

	public override Job JobOnThing(Pawn pawn, Thing thing, bool forced = false)
	{
		ResearchOpportunity opportunity = OpportunityCache;
		JobDef jobDef = JobDefOf_Custom.RR_LearnRemotely;
		Job job = JobMaker.MakeJob(jobDef, thing, 3000, checkOverrideOnExpiry: true);
		job.commTarget = (opportunity.requirement as ROComp_RequiresFaction).faction;
		return job;
	}

	public override float GetPriority(Pawn pawn, TargetInfo t)
	{
		return t.Thing.GetStatValue(StatDefOf.ResearchSpeedFactor);
	}
}
