using System.Collections.Generic;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.Comps.CompProperties;

public class CompProperties_ResearchKit : Verse.CompProperties
{
	public EffecterDef fieldworkEffect;

	public ThingDef substitutedResearchBench;

	public List<ThingDef> substitutedFacilities;

	public ThingDef remotesThrough;

	public CompProperties_ResearchKit()
	{
		compClass = typeof(Comp_ResearchKit);
	}

	public override IEnumerable<StatDrawEntry> SpecialDisplayStats(StatRequest req)
	{
		Dialog_InfoCard.Hyperlink benchHyperlink = new Dialog_InfoCard.Hyperlink(substitutedResearchBench);
		yield return new StatDrawEntry(StatCategoryDefOf.Basics, "RR_EquivalentResearchBench".Translate(), substitutedResearchBench.LabelCap, "RR_EquivalentResearchBench_desc".Translate(), -1, null, new List<Dialog_InfoCard.Hyperlink> { benchHyperlink });
		if (!substitutedFacilities.NullOrEmpty())
		{
			List<Dialog_InfoCard.Hyperlink> hyperlinks = new List<Dialog_InfoCard.Hyperlink>();
			List<string> labels = new List<string>();
			foreach (ThingDef facility in substitutedFacilities)
			{
				hyperlinks.Add(new Dialog_InfoCard.Hyperlink(facility));
				labels.Add(facility.LabelCap);
			}
			yield return new StatDrawEntry(StatCategoryDefOf.Basics, "RR_EquivalentResearchFacilities".Translate(), string.Join(", ", labels), "RR_EquivalentResearchFacilities_desc".Translate(), -1, null, hyperlinks);
		}
		if (remotesThrough != null)
		{
			Dialog_InfoCard.Hyperlink remoteHyperlink = new Dialog_InfoCard.Hyperlink(remotesThrough);
			yield return new StatDrawEntry(StatCategoryDefOf.Basics, "RR_RemoteConnectionFacility".Translate(), remotesThrough.LabelCap, "RR_RemoteConnectionFacility_desc".Translate(), -1, null, new List<Dialog_InfoCard.Hyperlink> { remoteHyperlink });
		}
	}
}
