using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Data;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Ingestibles;

[HarmonyPatch(typeof(Thing), "PrePostIngested")]
public static class Thing_PrePostIngested_Patches
{
	[HarmonyPostfix]
	public static void Thing_PrePostIngested_Postfix(Thing __instance, Pawn ingester)
	{
		if (!ingester.CanNowDoResearch())
		{
			return;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_OnIngest, __instance);
		if (opportunity != null)
		{
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"pawn {ingester.LabelCap} ingested {__instance.LabelCap} and there's an opportunity {opportunity.ShortDesc}");
			}
			float amount = BaseResearchAmounts.OnIngestIngester;
			float modifier = ingester.GetStatValue(StatDefOf.ResearchSpeed);
			float xp = ResearchXPAmounts.OnIngestIngester;
			opportunity.ResearchChunkPerformed(ingester, HandlingMode.Special_OnIngest, amount, modifier, xp, __instance.LabelCapNoCount);
		}
	}
}
