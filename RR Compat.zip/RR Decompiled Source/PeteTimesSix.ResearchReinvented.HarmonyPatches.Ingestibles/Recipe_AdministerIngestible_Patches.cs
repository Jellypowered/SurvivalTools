using System.Collections.Generic;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Data;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Ingestibles;

[HarmonyPatch(typeof(Recipe_AdministerIngestible), "ApplyOnPawn")]
public static class Recipe_AdministerIngestible_Patches
{
	[HarmonyPrefix]
	public static void Recipe_AdministerIngestible_ApplyOnPawn_Prefix(Recipe_AdministerIngestible __instance, Pawn pawn, Pawn billDoer, List<Thing> ingredients)
	{
		if (ingredients == null || ingredients.Count == 0)
		{
			return;
		}
		Thing ingestible = ingredients[0];
		if (!billDoer.CanNowDoResearch())
		{
			return;
		}
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_OnIngest_Observable, ingestible);
		if (opportunity != null)
		{
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"pawn {billDoer.LabelCap} observed pawn {pawn.LabelCap} ingest {ingestible.LabelCap} and there's an opportunity {opportunity.ShortDesc}");
			}
			float amount = BaseResearchAmounts.AdministerIngestibleObserver;
			float modifier = pawn.GetStatValue(StatDefOf.ResearchSpeed);
			float xp = ResearchXPAmounts.AdministerIngestibleObserver;
			opportunity.ResearchChunkPerformed(billDoer, HandlingMode.Special_OnIngest_Observable, amount, modifier, xp, ingestible.LabelCapNoCount, 0.5f);
		}
	}
}
