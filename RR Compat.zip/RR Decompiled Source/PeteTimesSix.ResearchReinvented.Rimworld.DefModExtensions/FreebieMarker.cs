using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;

public class FreebieMarker : DefModExtension
{
}
