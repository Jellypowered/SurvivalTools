using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;

public class RarityMarker : DefModExtension
{
}
