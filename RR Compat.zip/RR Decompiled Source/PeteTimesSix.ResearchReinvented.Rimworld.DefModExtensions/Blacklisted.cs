using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;

public class Blacklisted : DefModExtension
{
}
