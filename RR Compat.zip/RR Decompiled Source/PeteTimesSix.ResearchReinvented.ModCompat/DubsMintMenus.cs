using System;
using HarmonyLib;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.ModCompat;

[StaticConstructorOnStartup]
public static class DubsMintMenus
{
	public static bool active;

	public static bool success;

	static DubsMintMenus()
	{
		active = false;
		success = true;
		active = ModLister.GetActiveModWithIdentifier("dubwise.dubsmintmenus") != null;
	}

	public static void PatchDelayed(Harmony harmony)
	{
		try
		{
			Type billStack_DoListing = AccessTools.TypeByName("DubsMintMenus.Patch_BillStack_DoListing");
			DMM_Patch_BillStack_DoListing_Patches.GizmoListRect = AccessTools.StaticFieldRefAccess<Rect>(AccessTools.Field(billStack_DoListing, "GizmoListRect"));
			harmony.Patch(AccessTools.Method(billStack_DoListing, "Doink"), null, null, new HarmonyMethod(AccessTools.Method(typeof(DMM_Patch_BillStack_DoListing_Patches), "Doink_Transpiler")));
			harmony.Patch(AccessTools.Method(billStack_DoListing, "DoRow"), null, null, new HarmonyMethod(AccessTools.Method(typeof(DMM_Patch_BillStack_DoListing_Patches), "DoRow_Transpiler")));
		}
		catch (Exception ex)
		{
			Log.Warning("RR: Failed to apply Dubs Mint Menus compatibility patch (important: bill stack listing): " + ex.Message);
			success = false;
		}
		try
		{
			Type healthCardUtility = AccessTools.TypeByName("DubsMintMenus.Patch_HealthCardUtility");
			DMM_Patch_HealthCardUtility_Patches.searchString = AccessTools.StaticFieldRefAccess<string>(AccessTools.Field(healthCardUtility, "searchString"));
			harmony.Patch(AccessTools.Method(healthCardUtility, "Postfix"), null, null, new HarmonyMethod(AccessTools.Method(typeof(DMM_Patch_HealthCardUtility_Patches), "Postfix_Transpiler")));
		}
		catch (Exception ex2)
		{
			Log.Warning("RR: Failed to apply Dubs Mint Menus compatibility patch (important: health card listing): " + ex2.Message);
			success = false;
		}
	}
}
