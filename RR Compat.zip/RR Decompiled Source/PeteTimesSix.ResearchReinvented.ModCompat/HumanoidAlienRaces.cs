using System;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;
using Verse;

namespace PeteTimesSix.ResearchReinvented.ModCompat;

[StaticConstructorOnStartup]
public static class HumanoidAlienRaces
{
	public static bool active;

	public static bool success;

	static HumanoidAlienRaces()
	{
		active = false;
		success = true;
		active = ModLister.GetActiveModWithIdentifier("erdelf.HumanoidAlienRaces") != null;
	}

	public static void PatchDelayed(Harmony harmony)
	{
		try
		{
			HarmonyMethod raceCheck = new HarmonyMethod(AccessTools.TypeByName("AlienRace.HarmonyPatches").GetMethod("ShouldSkipResearchPostfix"));
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_ResearcherRR), "ShouldSkip"), null, raceCheck);
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_Analyse), "ShouldSkip"), null, raceCheck);
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_AnalyseInPlace), "ShouldSkip"), null, raceCheck);
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_AnalyseTerrain), "ShouldSkip"), null, raceCheck);
		}
		catch (Exception ex)
		{
			Log.Warning("RR: Failed to apply Humanoid Alien Races compatibility patch (noncritical: racial research restrictions): " + ex.Message);
			success = false;
		}
	}
}
