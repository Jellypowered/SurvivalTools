using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Utilities;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.ModCompat;

public static class DMM_Patch_HealthCardUtility_Patches
{
	public delegate void GenerateListingDelegate(Pawn pawn2, RecipeDef recipe, BodyPartRecord part);

	private class BillEntry
	{
		public RecipeDef def;

		public string label;

		public BodyPartRecord part;

		public BillEntry(string s, RecipeDef d, BodyPartRecord p)
		{
			label = s;
			def = d;
			part = p;
		}
	}

	public static GenerateListingDelegate method_GenerateListing;

	private static Color CyanishTransparentBG = new Color(0.5f, 0.75f, 1f, 0.5f);

	private static Color CyanishTransparent = new Color(0.5f, 1f, 1f, 0.8f);

	private static int lastCacheFrame = 0;

	private static Pawn cachedPawn = null;

	public static AccessTools.FieldRef<string> searchString { get; set; }

	private static List<BillEntry> BillsToListCache { get; set; } = new List<BillEntry>();

	public static IEnumerable<CodeInstruction> Postfix_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		IEnumerator<CodeInstruction> enumerator = instructions.GetEnumerator();
		Type type = AccessTools.TypeByName("DubsMintMenus.Patch_HealthCardUtility");
		FieldInfo listerField = type.GetField("lister", BindingFlags.Static | BindingFlags.NonPublic);
		method_GenerateListing = type.GetMethod("GenerateListing").CreateDelegate(typeof(GenerateListingDelegate)) as GenerateListingDelegate;
		CodeInstruction[] closeout_instructions = new CodeInstruction[5]
		{
			new CodeInstruction(OpCodes.Ldsfld, listerField),
			new CodeInstruction(OpCodes.Callvirt, AccessTools.PropertyGetter(typeof(Listing), "CurHeight")),
			new CodeInstruction(OpCodes.Stsfld, type.GetField("RecipesScrollHeight", BindingFlags.Static | BindingFlags.NonPublic)),
			new CodeInstruction(OpCodes.Ldsfld, listerField),
			new CodeInstruction(OpCodes.Callvirt, AccessTools.Method(typeof(Listing), "End"))
		};
		CodeInstruction[] add_prototypes_instructions = new CodeInstruction[4]
		{
			new CodeInstruction(OpCodes.Ldarg_1),
			new CodeInstruction(OpCodes.Ldarg_2),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DMM_Patch_HealthCardUtility_Patches), "AddPrototypeRows")),
			new CodeInstruction(OpCodes.Ldsfld, listerField)
		};
		CodeInstruction[] matchedInstructions;
		bool found;
		IEnumerable<CodeInstruction> iteratedOver = TranspilerUtils.IterateTo(enumerator, closeout_instructions, out matchedInstructions, out found);
		if (!found)
		{
			Log.Warning("RR: DMM_Patch_HealthCardUtility_Patches - Postfix - failed to apply patch (instructions not found)");
			foreach (CodeInstruction item in iteratedOver)
			{
				yield return item;
			}
		}
		else
		{
			foreach (CodeInstruction item2 in iteratedOver.Take(iteratedOver.Count() - matchedInstructions.Count()))
			{
				yield return item2;
			}
			IEnumerable<CodeInstruction> remainingInstructions = iteratedOver.Skip(iteratedOver.Count() - matchedInstructions.Count());
			yield return remainingInstructions.First();
			CodeInstruction[] array = add_prototypes_instructions;
			for (int i = 0; i < array.Length; i++)
			{
				yield return array[i];
			}
			foreach (CodeInstruction item3 in remainingInstructions.Skip(1))
			{
				yield return item3;
			}
		}
		while (enumerator.MoveNext())
		{
			yield return enumerator.Current;
		}
	}

	private static void AddPrototypeRows(Listing_Standard lister, Pawn pawn, Thing thingForMedBills)
	{
		Pawn pawn2 = thingForMedBills as Pawn;
		lastCacheFrame--;
		if (cachedPawn != pawn || lastCacheFrame < 0)
		{
			lastCacheFrame = 500;
			cachedPawn = pawn;
			BillsToListCache.Clear();
			foreach (RecipeDef recipe in (from p in thingForMedBills.def.AllRecipes
				where p.IsAvailableOnlyForPrototyping() && p.AvailableOnNow(pawn2)
				orderby p.label descending
				select p).ToList())
			{
				try
				{
					List<ThingDef> list = recipe.PotentiallyMissingIngredients(null, thingForMedBills.Map).ToList();
					if (list.Any((ThingDef x) => x.isTechHediff) || list.Any((ThingDef x) => x.IsDrug) || (list.Any() && recipe.dontShowIfAnyIngredientMissing))
					{
						continue;
					}
					if (recipe.targetsBodyPart)
					{
						foreach (BodyPartRecord bodyPart in recipe.Worker.GetPartsToApplyOn(pawn, recipe))
						{
							if (recipe.AvailableOnNow(pawn, bodyPart))
							{
								string text = recipe.Worker.GetLabelWhenUsedOn(pawn2, bodyPart).CapitalizeFirst();
								if (bodyPart != null && !recipe.hideBodyPartNames)
								{
									text = text + "\n(" + bodyPart.Label + ")";
								}
								BillsToListCache.Add(new BillEntry(text, recipe, bodyPart));
							}
						}
					}
					else
					{
						string s = recipe.Worker.GetLabelWhenUsedOn(pawn2, null).CapitalizeFirst();
						BillsToListCache.Add(new BillEntry(s, recipe, null));
					}
				}
				catch (Exception ex)
				{
					Log.Warning(ex.ToString());
				}
			}
		}
		foreach (BillEntry billEntry in BillsToListCache.Where((BillEntry x) => parc(x.def, x.label)))
		{
			try
			{
				float yBefore = lister.CurHeight;
				method_GenerateListing(pawn, billEntry.def, billEntry.part);
				float yAfter = lister.CurHeight;
				float height = yAfter - yBefore;
				Rect rect = lister.GetRect(0f);
				Rect actualRect = new Rect(rect.x, rect.y - height, rect.width, height);
				GameFont font = Text.Font;
				TextAnchor anchor = Text.Anchor;
				Color color = GUI.color;
				Text.Font = GameFont.Small;
				TaggedString protoLabel = "RR_ExperimentalSurgeryLabel".Translate();
				Rect labelRect = new Rect(actualRect.x + 2f, actualRect.y, actualRect.width - 4f, 20f);
				GUI.color = CyanishTransparentBG;
				GUI.DrawTexture(labelRect, TexUI.GrayTextBG);
				Text.Anchor = TextAnchor.UpperCenter;
				GUI.color = CyanishTransparent;
				Widgets.Label(labelRect, protoLabel);
				Text.Font = font;
				Text.Anchor = anchor;
				GUI.color = color;
				lister.GapLine(2f);
			}
			catch (Exception ex2)
			{
				Log.Warning(ex2.ToString());
			}
		}
	}

	private static bool DubsContains(this string source, string toCheck, StringComparison comp)
	{
		if (!string.IsNullOrEmpty(source))
		{
			return source.IndexOf(toCheck, comp) >= 0;
		}
		return false;
	}

	public static bool parc(RecipeDef p, string label)
	{
		if (!string.IsNullOrEmpty(label) && label.DubsContains(searchString(), StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		if (p.modContentPack != null && !string.IsNullOrEmpty(p.modContentPack.Name) && p.modContentPack.Name.DubsContains(searchString(), StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		return false;
	}
}
