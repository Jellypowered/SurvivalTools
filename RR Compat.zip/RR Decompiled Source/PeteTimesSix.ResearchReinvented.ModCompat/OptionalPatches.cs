using HarmonyLib;

namespace PeteTimesSix.ResearchReinvented.ModCompat;

public static class OptionalPatches
{
	public static void Patch(Harmony harmony)
	{
	}

	public static void PatchDelayed(Harmony harmony)
	{
		if (DubsMintMenus.active)
		{
			DubsMintMenus.PatchDelayed(harmony);
		}
		if (HumanoidAlienRaces.active)
		{
			HumanoidAlienRaces.PatchDelayed(harmony);
		}
		if (ResearchData.active)
		{
			ResearchData.PatchDelayed(harmony);
		}
	}
}
