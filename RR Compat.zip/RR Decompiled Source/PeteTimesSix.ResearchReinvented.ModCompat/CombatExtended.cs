using HarmonyLib;

namespace PeteTimesSix.ResearchReinvented.ModCompat;

public static class CombatExtended
{
	public static bool active;

	public static bool success;

	static CombatExtended()
	{
		active = false;
		success = true;
	}

	public static void PatchDelayed(Harmony harmony)
	{
	}
}
