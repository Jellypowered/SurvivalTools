using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace PeteTimesSix.ResearchReinvented.ModCompat;

public static class DMM_Patch_BillStack_DoListing_Patches
{
	public delegate void DoRowDelegate(RecipeDef recipe, HashSet<Building> selectedTables, Precept_Building shittyPrecept = null);

	public static DoRowDelegate method_DoRow;

	private static bool staticHack_shouldDoNormalButton = true;

	private static Color CyanishTransparentBG = new Color(0.5f, 0.75f, 1f, 0.5f);

	private static Color CyanishTransparent = new Color(0.5f, 1f, 1f, 0.8f);

	public static AccessTools.FieldRef<Rect> GizmoListRect { get; set; }

	public static IEnumerable<CodeInstruction> Doink_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		IEnumerator<CodeInstruction> enumerator = instructions.GetEnumerator();
		Type type = AccessTools.TypeByName("DubsMintMenus.Patch_BillStack_DoListing");
		FieldInfo listerField = type.GetField("lister", BindingFlags.Static | BindingFlags.NonPublic);
		method_DoRow = type.GetMethod("DoRow").CreateDelegate(typeof(DoRowDelegate)) as DoRowDelegate;
		CodeInstruction[] closeout_instructions = new CodeInstruction[6]
		{
			new CodeInstruction(OpCodes.Ldsfld, listerField),
			new CodeInstruction(OpCodes.Callvirt, AccessTools.PropertyGetter(typeof(Listing), "CurHeight")),
			new CodeInstruction(OpCodes.Stsfld, type.GetField("RecipesScrollHeight", BindingFlags.Static | BindingFlags.NonPublic)),
			new CodeInstruction(OpCodes.Ldsfld, listerField),
			new CodeInstruction(OpCodes.Callvirt, AccessTools.Method(typeof(Listing), "End")),
			new CodeInstruction(OpCodes.Ret)
		};
		CodeInstruction[] add_prototypes_instructions = new CodeInstruction[3]
		{
			new CodeInstruction(OpCodes.Ldarg_2),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DMM_Patch_BillStack_DoListing_Patches), "AddPrototypeRows")),
			new CodeInstruction(OpCodes.Ldsfld, listerField)
		};
		CodeInstruction[] matchedInstructions;
		bool found;
		IEnumerable<CodeInstruction> iteratedOver = TranspilerUtils.IterateTo(enumerator, closeout_instructions, out matchedInstructions, out found);
		if (!found)
		{
			Log.Warning("RR: DMM_Patch_BillStack_DoListing_Patches - Doink - failed to apply patch (instructions not found)");
			foreach (CodeInstruction item in iteratedOver)
			{
				yield return item;
			}
		}
		else
		{
			foreach (CodeInstruction item2 in iteratedOver.Take(iteratedOver.Count() - matchedInstructions.Count()))
			{
				yield return item2;
			}
			IEnumerable<CodeInstruction> remainingInstructions = iteratedOver.Skip(iteratedOver.Count() - matchedInstructions.Count());
			yield return remainingInstructions.First();
			CodeInstruction[] array = add_prototypes_instructions;
			for (int i = 0; i < array.Length; i++)
			{
				yield return array[i];
			}
			foreach (CodeInstruction item3 in remainingInstructions.Skip(1))
			{
				yield return item3;
			}
		}
		while (enumerator.MoveNext())
		{
			yield return enumerator.Current;
		}
	}

	public static IEnumerable<CodeInstruction> DoRow_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		IEnumerator<CodeInstruction> enumerator = instructions.GetEnumerator();
		CodeInstruction[] invisbutton_instructions = new CodeInstruction[4]
		{
			new CodeInstruction(OpCodes.Ldloc_0),
			new CodeInstruction(OpCodes.Ldc_I4_1),
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(Widgets), "ButtonInvisible")),
			new CodeInstruction(OpCodes.Brfalse)
		};
		CodeInstruction[] check_run_instructions = new CodeInstruction[2]
		{
			new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DMM_Patch_BillStack_DoListing_Patches), "ShouldDoNormalButton")),
			new CodeInstruction(OpCodes.Brfalse)
		};
		CodeInstruction[] matchedInstructions;
		bool found;
		IEnumerable<CodeInstruction> iteratedOver = TranspilerUtils.IterateTo(enumerator, invisbutton_instructions, out matchedInstructions, out found);
		if (!found)
		{
			Log.Warning("RR: DMM_Patch_BillStack_DoListing_Patches - DoRow - failed to apply patch (instructions not found)");
			foreach (CodeInstruction item in iteratedOver)
			{
				yield return item;
			}
		}
		else
		{
			foreach (CodeInstruction item2 in iteratedOver.Take(iteratedOver.Count() - matchedInstructions.Count()))
			{
				yield return item2;
			}
			IEnumerable<CodeInstruction> remainingInstructions = iteratedOver.Skip(iteratedOver.Count() - matchedInstructions.Count());
			check_run_instructions.First((CodeInstruction i) => i.opcode == OpCodes.Brfalse).operand = remainingInstructions.First((CodeInstruction i) => i.opcode == OpCodes.Brfalse).operand;
			CodeInstruction[] array = check_run_instructions;
			for (int num = 0; num < array.Length; num++)
			{
				yield return array[num];
			}
			foreach (CodeInstruction item3 in remainingInstructions)
			{
				yield return item3;
			}
		}
		while (enumerator.MoveNext())
		{
			yield return enumerator.Current;
		}
	}

	public static bool ShouldDoNormalButton()
	{
		return staticHack_shouldDoNormalButton;
	}

	private static void AddPrototypeRows(Listing_Standard lister, HashSet<Building> selectedTables)
	{
		HashSet<RecipeDef> prototypeRecipes = new HashSet<RecipeDef>();
		foreach (Building building in selectedTables)
		{
			if (!(building is IBillGiver))
			{
				continue;
			}
			foreach (RecipeDef recipe in building.def.AllRecipes)
			{
				if (recipe.IsAvailableOnlyForPrototyping() && recipe.AvailableOnNow(building))
				{
					prototypeRecipes.Add(recipe);
				}
			}
		}
		foreach (RecipeDef recipe2 in prototypeRecipes)
		{
			DoPrototypeRow(lister, selectedTables, recipe2, null);
			foreach (Ideo ideo in Faction.OfPlayer.ideos.AllIdeos)
			{
				foreach (Precept_Building precept_Building in ideo.cachedPossibleBuildings)
				{
					if (precept_Building.ThingDef == recipe2.ProducedThingDef)
					{
						DoPrototypeRow(lister, selectedTables, recipe2, precept_Building);
					}
				}
			}
		}
	}

	private static void DoPrototypeRow(Listing_Standard lister, HashSet<Building> selectedTables, RecipeDef recipe, Precept_Building precept_Building)
	{
		float yBefore = lister.CurHeight;
		staticHack_shouldDoNormalButton = false;
		method_DoRow(recipe, selectedTables);
		staticHack_shouldDoNormalButton = true;
		float yAfter = lister.CurHeight;
		float height = yAfter - yBefore;
		Rect rect = lister.GetRect(0f);
		Rect actualRect = new Rect(rect.x, rect.y - height, rect.width, height);
		if (!actualRect.Overlaps(GizmoListRect()))
		{
			return;
		}
		GameFont font = Text.Font;
		TextAnchor anchor = Text.Anchor;
		Color color = GUI.color;
		Text.Font = GameFont.Small;
		TaggedString protoLabel = "RR_PrototypeLabel".Translate();
		Rect labelRect = new Rect(actualRect.x + 2f, actualRect.y, actualRect.width - 4f, 20f);
		GUI.color = CyanishTransparentBG;
		GUI.DrawTexture(labelRect, TexUI.GrayTextBG);
		Text.Anchor = TextAnchor.UpperCenter;
		GUI.color = CyanishTransparent;
		Widgets.Label(labelRect, protoLabel);
		Text.Font = font;
		Text.Anchor = anchor;
		GUI.color = color;
		if (Widgets.ButtonInvisible(actualRect))
		{
			if (selectedTables.Any())
			{
				foreach (Building building in selectedTables)
				{
					IBillGiver billGiver = building as IBillGiver;
					if (building.def.AllRecipes.Contains(recipe))
					{
						billGiver.BillStack.AddBill(recipe.MakeNewBill(precept_Building));
					}
				}
				SoundDefOf.Tick_High.PlayOneShotOnCamera();
			}
			else
			{
				Messages.Message("Mint.SelectABenchToAddBills".Translate(), MessageTypeDefOf.NegativeEvent, historical: false);
				SoundDefOf.Tick_High.PlayOneShotOnCamera();
			}
		}
		lister.GapLine(2f);
	}
}
