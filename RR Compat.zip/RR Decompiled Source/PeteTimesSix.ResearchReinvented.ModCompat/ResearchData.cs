using System;
using System.Reflection;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Rimworld.WorkGivers;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.ModCompat;

[StaticConstructorOnStartup]
public static class ResearchData
{
	public delegate float ConsumptionRatePerTickGetter(CompRefuelable instance);

	public enum ResearchDataCompatMode
	{
		TheoryOnly,
		AllBenchResearch
	}

	public static ConsumptionRatePerTickGetter getter_ConsumptionRatePerTick;

	public static bool active;

	public static bool success;

	static ResearchData()
	{
		active = false;
		success = true;
		active = ModLister.GetActiveModWithIdentifier("kongkim.ResearchData") != null;
		getter_ConsumptionRatePerTick = AccessTools.MethodDelegate<ConsumptionRatePerTickGetter>(AccessTools.PropertyGetter(typeof(CompRefuelable), "ConsumptionRatePerTick"));
	}

	public static void PatchDelayed(Harmony harmony)
	{
		try
		{
			MethodInfo workGiverHasJobOnThingPrefix = AccessTools.Method(AccessTools.TypeByName("ResearchData.ResearchData_WorkGiver_Researcher_HasJobOnThing_Patch"), "Prefix");
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_ResearcherRR), "HasJobOnThing"), workGiverHasJobOnThingPrefix);
		}
		catch (Exception ex)
		{
			Log.Warning("RR: Failed to apply Research Data compatibility patch (critical: fuel consuption on research): " + ex.ToString());
			success = false;
		}
	}

	public static void ConsumeTickIntervalFuel(this CompRefuelable comp, int delta)
	{
		comp.ConsumeFuel(getter_ConsumptionRatePerTick(comp) * (float)delta);
	}
}
