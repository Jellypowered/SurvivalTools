using HarmonyLib;
using PeteTimesSix.ResearchReinvented.DefGenerators;
using PeteTimesSix.ResearchReinvented.Defs;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(DefGenerator), "GenerateImpliedDefs_PreResolve")]
public static class DefGenerator_PreResolve_Patches
{
	[HarmonyPrefix]
	public static void Prefix()
	{
		foreach (AlternateResearchSubjectsDef alternateDef in AlternateResearchSubjectDefGenerator.AncientAlternateDefs())
		{
			DefGenerator.AddImpliedDef(alternateDef);
		}
		foreach (AlternateResearchSubjectsDef alternateDef2 in AlternateResearchSubjectDefGenerator.AdvancedAlternateDefs())
		{
			DefGenerator.AddImpliedDef(alternateDef2);
		}
		foreach (AlternateResearchSubjectsDef alternateDef3 in AlternateResearchSubjectDefGenerator.UniqueAlternateDefs())
		{
			DefGenerator.AddImpliedDef(alternateDef3);
		}
	}
}
