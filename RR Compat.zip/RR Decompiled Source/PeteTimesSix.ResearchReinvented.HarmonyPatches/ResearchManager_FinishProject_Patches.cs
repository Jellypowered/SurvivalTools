using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(ResearchManager), "FinishProject")]
public static class ResearchManager_FinishProject_Patches
{
	[HarmonyPostfix]
	public static void Postfix(ResearchProjectDef proj)
	{
		if (proj != null)
		{
			ResearchOpportunityManager.Instance.PostFinishProject(proj);
		}
	}
}
