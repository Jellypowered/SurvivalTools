using HarmonyLib;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(WorkGiver_Researcher), "ShouldSkip")]
public static class WorkGiver_Researcher_Patches
{
	[HarmonyPrefix]
	public static bool Prefix(ref bool __result)
	{
		__result = true;
		return false;
	}
}
