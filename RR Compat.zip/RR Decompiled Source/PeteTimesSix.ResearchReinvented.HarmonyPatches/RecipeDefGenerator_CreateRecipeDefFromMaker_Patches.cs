using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.DefGenerators;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(RecipeDefGenerator), "CreateRecipeDefFromMaker")]
public static class RecipeDefGenerator_CreateRecipeDefFromMaker_Patches
{
	[HarmonyPostfix]
	public static void Postfix(RecipeDef __result, ThingDef def, int adjustedCount)
	{
		if (AlternateResearchSubjectDefGenerator.recipeMakerRecipes.TryGetValue(def, out var preexistingRecipes))
		{
			List<RecipeDef> recipes = preexistingRecipes.ToList();
			recipes.Add(__result);
			AlternateResearchSubjectDefGenerator.recipeMakerRecipes[def] = recipes.ToArray();
		}
		else
		{
			AlternateResearchSubjectDefGenerator.recipeMakerRecipes[def] = new RecipeDef[1] { __result };
		}
	}
}
