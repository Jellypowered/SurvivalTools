using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(ResearchManager), "ResetAllProgress")]
public static class ResearchManager_ResetAllProgress_Patches
{
	[HarmonyPostfix]
	public static void Postfix()
	{
		ResearchOpportunityManager.Instance.ResetAllProgress();
	}
}
