using System;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Defs;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(BackCompatibility), "BackCompatibleDefName")]
public static class BackCompatibility_BackCompatibleDefName_Patches
{
	[HarmonyPostfix]
	public static void BackCompatibility_BackCompatibleDefName_Postfix(ref string __result, Type defType, string defName)
	{
		if (defType == typeof(ResearchOpportunityCategoryDef) && defName == "Medical")
		{
			__result = "Clinical";
		}
	}
}
