using HarmonyLib;
using PeteTimesSix.ResearchReinvented.DefGenerators;
using PeteTimesSix.ResearchReinvented.Defs;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(DefGenerator), "GenerateImpliedDefs_PostResolve")]
public static class DefGenerator_PostResolve_Patches
{
	[HarmonyPostfix]
	public static void Postfix()
	{
		foreach (AlternateResearchSubjectsDef bulkRecipeDef in AlternateResearchSubjectDefGenerator.BulkRecipes())
		{
			DefGenerator.AddImpliedDef(bulkRecipeDef);
		}
		foreach (AlternateResearchSubjectsDef plantDef in AlternateResearchSubjectDefGenerator.WildPlantsAlternateDefs())
		{
			DefGenerator.AddImpliedDef(plantDef);
		}
		foreach (AlternateResearchSubjectsDef carpetDef in AlternateResearchSubjectDefGenerator.Carpets())
		{
			DefGenerator.AddImpliedDef(carpetDef);
		}
		foreach (AlternateResearchSubjectsDef recipeMakerDef in AlternateResearchSubjectDefGenerator.RecipeMakers())
		{
			DefGenerator.AddImpliedDef(recipeMakerDef);
		}
	}
}
