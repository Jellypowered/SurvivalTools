using HarmonyLib;
using PeteTimesSix.ResearchReinvented.DefOfs;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(Pawn_GuestTracker), "SetGuestStatus")]
public static class Pawn_GuestTracker_Patches
{
	[HarmonyPostfix]
	public static void Postfix(Pawn_GuestTracker __instance, GuestStatus guestStatus)
	{
		if (guestStatus == GuestStatus.Prisoner && ResearchReinventedMod.Settings.enableScienceInterrogationByDefault)
		{
			__instance.ToggleNonExclusiveInteraction(PrisonerInteractionModeDefOf_Custom.RR_ScienceInterrogation, enabled: true);
		}
	}
}
