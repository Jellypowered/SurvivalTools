using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Managers;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(DoorsDebugDrawer), "DrawDebug")]
public static class DoorsDebugDrawer_DrawDebug_Patch
{
	[HarmonyPostfix]
	public static void AdditionalDebugDrawingInjection()
	{
		PrototypeKeeper.Instance.DebugDrawOnMap();
	}
}
