using System.Collections.Generic;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.DefGenerators;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(TerrainDefGenerator_Carpet), "CarpetFromBlueprint")]
public static class TerrainDefGenerator_Carpet_Patches
{
	[HarmonyPostfix]
	public static void Postfix(TerrainDef __result, TerrainTemplateDef tp)
	{
		if (!AlternateResearchSubjectDefGenerator.carpets.ContainsKey(tp))
		{
			AlternateResearchSubjectDefGenerator.carpets[tp] = new List<TerrainDef>();
		}
		AlternateResearchSubjectDefGenerator.carpets[tp].Add(__result);
	}
}
