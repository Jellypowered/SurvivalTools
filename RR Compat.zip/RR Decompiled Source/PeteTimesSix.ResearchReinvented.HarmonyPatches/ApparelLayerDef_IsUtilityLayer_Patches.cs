using HarmonyLib;
using PeteTimesSix.ResearchReinvented.DefOfs;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches;

[HarmonyPatch(typeof(ApparelLayerDef), "IsUtilityLayer", MethodType.Getter)]
public static class ApparelLayerDef_IsUtilityLayer_Patches
{
	[HarmonyPostfix]
	public static bool ApparelLayerDef_IsUtilityLayer_Postfix(bool __result, ApparelLayerDef __instance)
	{
		if (__result)
		{
			return __result;
		}
		return __instance == ApparelLayerDefOf_Custom.Satchel;
	}
}
