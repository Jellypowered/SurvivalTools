using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public class OpportunityFactoryCollectionsSetForRelation
{
	internal HashSet<ThingDef> forProductionFacilityAnalysis = new HashSet<ThingDef>();

	internal HashSet<Def> forDirectAnalysis = new HashSet<Def>();

	internal HashSet<ThingDef> forIngredientsAnalysis = new HashSet<ThingDef>();

	internal HashSet<ThingDef> forHarvestProductAnalysis = new HashSet<ThingDef>();

	internal HashSet<ThingDef> forFuelAnalysis = new HashSet<ThingDef>();

	internal HashSet<Def> forPrototyping = new HashSet<Def>();

	internal HashSet<SpecialResearchOpportunityDef> specials = new HashSet<SpecialResearchOpportunityDef>();

	public ResearchRelation relation;

	public OpportunityFactoryCollectionsSetForRelation(ResearchRelation relation)
	{
		this.relation = relation;
	}

	public void RemoveDuplicates(OpportunityFactoryCollectionsSetForRelation other)
	{
		forProductionFacilityAnalysis.ExceptWith(other.forProductionFacilityAnalysis);
		forDirectAnalysis.ExceptWith(other.forDirectAnalysis);
		forIngredientsAnalysis.ExceptWith(other.forIngredientsAnalysis);
		forHarvestProductAnalysis.ExceptWith(other.forHarvestProductAnalysis);
		forFuelAnalysis.ExceptWith(other.forFuelAnalysis);
		forPrototyping.ExceptWith(other.forPrototyping);
		specials.ExceptWith(other.specials);
	}

	public void RemoveBlacklisted()
	{
		forProductionFacilityAnalysis.RemoveWhere((ThingDef d) => d.modExtensions != null && d.modExtensions.Any((DefModExtension e) => e is Blacklisted));
		forDirectAnalysis.RemoveWhere((Def d) => d.modExtensions != null && d.modExtensions.Any((DefModExtension e) => e is Blacklisted));
		forIngredientsAnalysis.RemoveWhere((ThingDef d) => d.modExtensions != null && d.modExtensions.Any((DefModExtension e) => e is Blacklisted));
		forHarvestProductAnalysis.RemoveWhere((ThingDef d) => d.modExtensions != null && d.modExtensions.Any((DefModExtension e) => e is Blacklisted));
		forFuelAnalysis.RemoveWhere((ThingDef d) => d.modExtensions != null && d.modExtensions.Any((DefModExtension e) => e is Blacklisted));
		forPrototyping.RemoveWhere((Def d) => d.modExtensions != null && d.modExtensions.Any((DefModExtension e) => e is Blacklisted));
		specials.RemoveWhere((SpecialResearchOpportunityDef d) => d.modExtensions != null && d.modExtensions.Any((DefModExtension e) => e is Blacklisted));
	}

	public void RemoveAlternatesWhereAppropriate()
	{
		forProductionFacilityAnalysis.RemoveWhere((ThingDef t) => AsAlternateInCollection(t, forProductionFacilityAnalysis, AlternatesMode.EQUIVALENT));
		forDirectAnalysis.RemoveWhere((Def t) => AsAlternateInCollection(t, forDirectAnalysis, (relation != ResearchRelation.Direct) ? AlternatesMode.EQUIVALENT : AlternatesMode.SIMILAR));
		forIngredientsAnalysis.RemoveWhere((ThingDef t) => AsAlternateInCollection(t, forIngredientsAnalysis, AlternatesMode.EQUIVALENT));
		forHarvestProductAnalysis.RemoveWhere((ThingDef t) => AsAlternateInCollection(t, forHarvestProductAnalysis, AlternatesMode.EQUIVALENT));
		forFuelAnalysis.RemoveWhere((ThingDef t) => AsAlternateInCollection(t, forFuelAnalysis, AlternatesMode.EQUIVALENT));
		forPrototyping.RemoveWhere((Def t) => AsAlternateInCollection(t, forPrototyping, AlternatesMode.EQUIVALENT));
	}

	public bool AsAlternateInCollection(Def testee, IEnumerable<Def> collection, AlternatesMode mode)
	{
		ThingDef[] value;
		TerrainDef[] value2;
		RecipeDef[] value3;
		return mode switch
		{
			AlternatesMode.NONE => false, 
			AlternatesMode.EQUIVALENT => collection.Any((Def o) => (o is ThingDef key && AlternatesKeeper.alternatesEquivalent.TryGetValue(key, out value) && value.Contains(testee)) || (o is TerrainDef key2 && AlternatesKeeper.alternateEquivalentTerrains.TryGetValue(key2, out value2) && value2.Contains(testee)) || (o is RecipeDef key3 && AlternatesKeeper.alternateEquivalentRecipes.TryGetValue(key3, out value3) && value3.Contains(testee))), 
			AlternatesMode.SIMILAR => collection.Any((Def o) => (o is ThingDef key && AlternatesKeeper.alternatesSimilar.TryGetValue(key, out value) && value.Contains(testee)) || (o is TerrainDef key2 && AlternatesKeeper.alternateSimilarTerrains.TryGetValue(key2, out value2) && value2.Contains(testee)) || (o is RecipeDef key3 && AlternatesKeeper.alternateSimilarRecipes.TryGetValue(key3, out value3) && value3.Contains(testee))), 
			_ => false, 
		};
	}
}
