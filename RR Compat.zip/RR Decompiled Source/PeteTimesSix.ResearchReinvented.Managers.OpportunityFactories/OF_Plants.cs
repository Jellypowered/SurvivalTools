using System.Linq;
using PeteTimesSix.ResearchReinvented.Extensions;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public static class OF_Plants
{
	public static void MakeFromPlants(ResearchProjectDef project, OpportunityFactoryCollectionsSetForRelation collections)
	{
		if (project.UnlockedDefs == null)
		{
			return;
		}
		foreach (Def unlock in project.UnlockedDefs.Where((Def u) => u is ThingDef thingDef && typeof(Plant).IsAssignableFrom(thingDef.thingClass)))
		{
			if (unlock.PassesIdeoCheck())
			{
				ThingDef plant = unlock as ThingDef;
				ThingDef product = plant.plant?.harvestedThingDef;
				if (product != null)
				{
					collections.forHarvestProductAnalysis.Add(product);
				}
			}
		}
	}
}
