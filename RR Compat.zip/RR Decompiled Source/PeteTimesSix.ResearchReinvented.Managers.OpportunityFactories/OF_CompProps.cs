using System.Linq;
using PeteTimesSix.ResearchReinvented.Extensions;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public static class OF_CompProps
{
	public static void MakeFromFuel(ResearchProjectDef project, OpportunityFactoryCollectionsSetForRelation collections)
	{
		if (project.UnlockedDefs == null)
		{
			return;
		}
		foreach (ThingDef unlock in project.UnlockedDefs.Where(delegate(Def u)
		{
			ThingDef thingDef = u as ThingDef;
			return thingDef != null;
		}).Cast<ThingDef>())
		{
			if (unlock.PassesIdeoCheck())
			{
				CompProperties_Refuelable fuelComp = unlock.GetCompProperties<CompProperties_Refuelable>();
				if (fuelComp != null)
				{
					collections.forFuelAnalysis.AddRange(fuelComp.fuelFilter.AllowedThingDefs);
				}
			}
		}
	}
}
