using System;
using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Extensions;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public static class OF_Unlocks
{
	private class RecursiveAncestorLoopException : InvalidOperationException
	{
		public List<ResearchProjectDef> list = new List<ResearchProjectDef>();

		public RecursiveAncestorLoopException()
		{
		}

		public RecursiveAncestorLoopException(ResearchProjectDef project)
		{
			list.Add(project);
		}
	}

	private static Dictionary<ResearchProjectDef, HashSet<ResearchProjectDef>> ancestorsTree;

	public static Dictionary<ResearchProjectDef, HashSet<ResearchProjectDef>> AncestorsTree
	{
		get
		{
			if (ancestorsTree == null)
			{
				PrepareAncestryTree();
			}
			return ancestorsTree;
		}
	}

	private static void PrepareAncestryTree()
	{
		ancestorsTree = new Dictionary<ResearchProjectDef, HashSet<ResearchProjectDef>>();
		foreach (ResearchProjectDef project in DefDatabase<ResearchProjectDef>.AllDefsListForReading)
		{
			try
			{
				ancestorsTree[project] = GetAllPrerequisites(project, 0);
			}
			catch (RecursiveAncestorLoopException ex)
			{
				ex.list.Reverse();
				Log.Error("RR: Reached a depth of 200 while recursively crawling the tech tree! This almost certainly means there's a loop in it. Looped projects: " + string.Join(" -> ", ex.list.Select((ResearchProjectDef def) => def.label + " (" + def.defName + ")")));
				ancestorsTree[project] = new HashSet<ResearchProjectDef>();
			}
		}
	}

	private static HashSet<ResearchProjectDef> GetAllPrerequisites(ResearchProjectDef project, int depth)
	{
		if (depth > 200)
		{
			throw new RecursiveAncestorLoopException(project);
		}
		try
		{
			if (!ancestorsTree.ContainsKey(project))
			{
				HashSet<ResearchProjectDef> newSet = new HashSet<ResearchProjectDef>();
				if (project.prerequisites != null)
				{
					foreach (ResearchProjectDef prereq in project.prerequisites)
					{
						if (prereq != project)
						{
							newSet.AddRange(GetAllPrerequisites(prereq, depth + 1));
						}
					}
				}
				if (project.hiddenPrerequisites != null)
				{
					foreach (ResearchProjectDef prereq2 in project.hiddenPrerequisites)
					{
						if (prereq2 != project)
						{
							newSet.AddRange(GetAllPrerequisites(prereq2, depth + 1));
						}
					}
				}
				ancestorsTree[project] = newSet;
			}
			HashSet<ResearchProjectDef> returnSet = new HashSet<ResearchProjectDef> { project };
			returnSet.AddRange(ancestorsTree[project]);
			return returnSet;
		}
		catch (RecursiveAncestorLoopException ex)
		{
			ex.list.Add(project);
			throw;
		}
	}

	public static void MakeFromUnlocks(ResearchProjectDef project, OpportunityFactoryCollectionsSetForRelation collections)
	{
		if (project.UnlockedDefs == null)
		{
			return;
		}
		HashSet<IngredientCount> ingredientCounts = new HashSet<IngredientCount>();
		foreach (Def unlock in project.UnlockedDefs)
		{
			if (!unlock.PassesIdeoCheck())
			{
				continue;
			}
			RecipeDef asRecipe = unlock as RecipeDef;
			if (asRecipe != null)
			{
				continue;
			}
			ThingDef asThing = unlock as ThingDef;
			if (asThing != null)
			{
				collections.forDirectAnalysis.Add(asThing);
				if (asThing.researchPrerequisites == null)
				{
					continue;
				}
				if (asThing.CostList != null && asThing.CostList.Count > 0)
				{
					ingredientCounts.AddRange(asThing.CostList.Select((ThingDefCountClass c) => c.ToIngredientCount()));
				}
				if (asThing.CostStuffCount > 0)
				{
					IEnumerable<ThingDef> stuffs = GenStuff.AllowedStuffsFor(asThing);
					ingredientCounts.AddRange(stuffs.Select((ThingDef s) => new ThingDefCountClass(s, asThing.costStuffCount).ToIngredientCount()));
				}
				if (asThing.researchPrerequisites?.Except(project)?.Any(delegate(ResearchProjectDef p)
				{
					HashSet<ResearchProjectDef> hashSet = AncestorsTree[project];
					return hashSet == null || !hashSet.Contains(p);
				}) != true)
				{
					collections.forPrototyping.Add(asThing);
				}
			}
			else if (unlock is TerrainDef asTerrain)
			{
				collections.forDirectAnalysis.Add(asTerrain);
				if (asTerrain.CostList != null && asTerrain.CostList.Count > 0)
				{
					ingredientCounts.AddRange(asTerrain.CostList.Select((ThingDefCountClass c) => c.ToIngredientCount()));
				}
				if (asTerrain.researchPrerequisites?.Except(project)?.Any(delegate(ResearchProjectDef p)
				{
					HashSet<ResearchProjectDef> hashSet = AncestorsTree[project];
					return hashSet == null || !hashSet.Contains(p);
				}) != true)
				{
					collections.forPrototyping.Add(asTerrain);
				}
			}
			else
			{
				Log.Warning(project.defName + " unlocks " + unlock.defName + " which is not a handled type of def");
			}
		}
		List<ThingDefCount> rawIngredients = new List<ThingDefCount>();
		foreach (IngredientCount ingredientCount in ingredientCounts)
		{
			if (ingredientCount.IsFixedIngredient)
			{
				rawIngredients.Add(new ThingDefCount(ingredientCount.FixedIngredient, (int)ingredientCount.GetBaseCount()));
				continue;
			}
			IEnumerable<ThingDefCount> possibleIngredients = ingredientCount.filter.AllowedThingDefs.Select((ThingDef a) => new ThingDefCount(a, (int)ingredientCount.GetBaseCount()));
			rawIngredients.AddRange(possibleIngredients);
		}
		HashSet<ThingDef> ingredientThings = rawIngredients.Select((ThingDefCount c) => c.ThingDef).ToHashSet();
		collections.forIngredientsAnalysis.AddRange(ingredientThings);
	}
}
