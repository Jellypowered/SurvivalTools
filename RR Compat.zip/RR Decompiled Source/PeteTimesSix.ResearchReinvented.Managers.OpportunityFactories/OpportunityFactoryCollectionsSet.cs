using PeteTimesSix.ResearchReinvented.Opportunities;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public class OpportunityFactoryCollectionsSet
{
	private OpportunityFactoryCollectionsSetForRelation collections_direct = new OpportunityFactoryCollectionsSetForRelation(ResearchRelation.Direct);

	private OpportunityFactoryCollectionsSetForRelation collections_ancestor = new OpportunityFactoryCollectionsSetForRelation(ResearchRelation.Ancestor);

	private OpportunityFactoryCollectionsSetForRelation collections_descendant = new OpportunityFactoryCollectionsSetForRelation(ResearchRelation.Descendant);

	public OpportunityFactoryCollectionsSetForRelation GetSet(ResearchRelation relation)
	{
		return relation switch
		{
			ResearchRelation.Direct => collections_direct, 
			ResearchRelation.Ancestor => collections_ancestor, 
			ResearchRelation.Descendant => collections_descendant, 
			_ => null, 
		};
	}

	public OpportunityFactoryCollectionsSetForRelation[] GetSets()
	{
		return new OpportunityFactoryCollectionsSetForRelation[3] { collections_direct, collections_ancestor, collections_descendant };
	}

	public void RemoveBlacklisted()
	{
		collections_direct.RemoveBlacklisted();
		collections_ancestor.RemoveBlacklisted();
		collections_descendant.RemoveBlacklisted();
	}

	public void RemoveDuplicates()
	{
		collections_ancestor.RemoveDuplicates(collections_direct);
		collections_descendant.RemoveDuplicates(collections_direct);
	}

	public void RemoveAlternatesWhereAppropriate()
	{
		collections_direct.RemoveAlternatesWhereAppropriate();
		collections_ancestor.RemoveAlternatesWhereAppropriate();
		collections_descendant.RemoveAlternatesWhereAppropriate();
	}
}
