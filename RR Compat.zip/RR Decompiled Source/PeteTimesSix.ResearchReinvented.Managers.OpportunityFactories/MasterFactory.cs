using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public class MasterFactory
{
	public IEnumerable<ResearchOpportunity> GenerateOpportunities(ResearchProjectDef project)
	{
		if (project == null)
		{
			return new List<ResearchOpportunity>();
		}
		OpportunityFactoryCollectionsSet collections = FillCollections(project);
		IEnumerable<ResearchOpportunity> opportunities = MakeOpportunities(project, collections);
		return ValidOpportunities(opportunities);
	}

	public IEnumerable<ResearchOpportunity> ValidOpportunities(IEnumerable<ResearchOpportunity> opportunities)
	{
		foreach (ResearchOpportunity opportunity in opportunities)
		{
			if (opportunity.IsValid())
			{
				yield return opportunity;
			}
		}
	}

	private IEnumerable<ResearchOpportunity> MakeOpportunities(ResearchProjectDef project, OpportunityFactoryCollectionsSet collections)
	{
		yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.BasicResearch, ResearchRelation.Direct, new ROComp_RequiresNothing(), "Project");
		yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.SchematicStudy, ResearchRelation.Direct, new ROComp_RequiresSchematicWithProject(project), "Schematic");
		if (ModsConfig.RoyaltyActive && project.Techprint != null)
		{
			yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseTechprint, ResearchRelation.Direct, new ROComp_RequiresThing(project.Techprint, AlternatesMode.NONE), "Techprint");
		}
		Faction playerFaction = Faction.OfPlayer;
		float playerTechLevelModifier = OF_Factions.Modifiers.TryGetValue((playerFaction.def.techLevel, project.techLevel), 0f);
		if (playerTechLevelModifier > 0f)
		{
			yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.Brainstorming, ResearchRelation.Direct, new ROComp_RequiresFaction(playerFaction), "player faction", playerTechLevelModifier);
		}
		IEnumerable<Faction> factions = Find.FactionManager.GetFactions(allowHidden: true, allowDefeated: true, allowNonHumanlike: false, TechLevel.Neolithic);
		foreach (Faction faction in factions)
		{
			float techLevelModifier = OF_Factions.Modifiers.TryGetValue((faction.def.techLevel, project.techLevel), 0f);
			if (techLevelModifier > 0f)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.GainFactionKnowledge, ResearchRelation.Direct, new ROComp_RequiresFaction(faction), "faction", techLevelModifier);
			}
		}
		float techLevelModifier2 = 0.5f;
		yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.GainFactionlessKnowledge, ResearchRelation.Direct, new ROComp_RequiresFactionlessPawn(), "no faction", techLevelModifier2);
		OpportunityFactoryCollectionsSetForRelation[] sets = collections.GetSets();
		foreach (OpportunityFactoryCollectionsSetForRelation set in sets)
		{
			foreach (ThingDef productionFacility in set.forProductionFacilityAnalysis.Where((ThingDef facility) => !project.UnlockedDefs.Contains(facility)))
			{
				if (typeof(Pawn).IsAssignableFrom(productionFacility.thingClass))
				{
					if (productionFacility.race.IsFleshModAware())
					{
						yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalysePawn, set.relation, new ROComp_RequiresThing(productionFacility, AlternatesMode.EQUIVALENT), "set.production facility pawn");
						if (productionFacility.race.corpseDef != null)
						{
							yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDissect, set.relation, new ROComp_RequiresThing(productionFacility.race.corpseDef, AlternatesMode.EQUIVALENT), "set.production facility pawn (corpse)");
						}
					}
					else
					{
						yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalysePawnNonFlesh, set.relation, new ROComp_RequiresThing(productionFacility, AlternatesMode.EQUIVALENT), "set.production facility pawn nonflesh");
						if (productionFacility.race.corpseDef != null)
						{
							yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDissectNonFlesh, set.relation, new ROComp_RequiresThing(productionFacility.race.corpseDef, AlternatesMode.EQUIVALENT), "set.production facility pawn (corpse non-flesh)");
						}
					}
				}
				else
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseProductionFacility, set.relation, new ROComp_RequiresThing(productionFacility, AlternatesMode.EQUIVALENT), "set.production facility");
				}
			}
			foreach (Def analysable in set.forDirectAnalysis)
			{
				foreach (ResearchOpportunity item in OpportunitiesFromDirectAnalysis(project, analysable, set.relation))
				{
					yield return item;
				}
			}
			foreach (ThingDef material in set.forIngredientsAnalysis)
			{
				foreach (ResearchOpportunity item2 in OpportunitiesFromIngredientAnalysis(project, material, set.relation))
				{
					yield return item2;
				}
			}
			foreach (ThingDef product in set.forHarvestProductAnalysis)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseHarvestProduct, set.relation, new ROComp_RequiresThing(product, AlternatesMode.EQUIVALENT), "set.harvest product");
			}
			foreach (ThingDef fuel in set.forFuelAnalysis)
			{
				foreach (ResearchOpportunity item3 in OpportunitiesFromFuelAnalysis(project, fuel, set.relation))
				{
					yield return item3;
				}
			}
			foreach (Def prototypeable in set.forPrototyping)
			{
				foreach (ResearchOpportunity item4 in OpportunitiesFromPrototyping(project, prototypeable, set.relation))
				{
					yield return item4;
				}
			}
			foreach (SpecialResearchOpportunityDef special in set.specials)
			{
				foreach (ResearchOpportunity item5 in OpportunitiesFromSpecialOpportunityDef(project, special, set.relation))
				{
					yield return item5;
				}
			}
		}
	}

	public IEnumerable<ResearchOpportunity> OpportunitiesFromSpecialOpportunityDef(ResearchProjectDef project, SpecialResearchOpportunityDef special, ResearchRelation relation)
	{
		ResearchRelation relationOverride = (special.relationOverride.HasValue ? special.relationOverride.Value : relation);
		bool requiredSomething = false;
		if (special.things != null)
		{
			requiredSomething = true;
			foreach (ThingDef thing in special.things)
			{
				if (special.opportunityType != null)
				{
					yield return new ResearchOpportunity(project, special.opportunityType, relationOverride, new ROComp_RequiresThing(thing, special.altsMode), "special (thing)", special.importanceMultiplier, special.rare, special.freebie);
					continue;
				}
				foreach (ResearchOpportunity standardOpportunity in OpportunitiesFromDirectAnalysis(project, thing, relationOverride))
				{
					standardOpportunity.importance = special.importanceMultiplier;
					yield return standardOpportunity;
				}
			}
		}
		if (special.terrains != null)
		{
			requiredSomething = true;
			foreach (TerrainDef terrain in special.terrains)
			{
				if (special.opportunityType != null)
				{
					yield return new ResearchOpportunity(project, special.opportunityType, relationOverride, new ROComp_RequiresTerrain(terrain, special.altsMode), "special (terrain)", special.importanceMultiplier, special.rare, special.freebie);
					continue;
				}
				foreach (ResearchOpportunity standardOpportunity2 in OpportunitiesFromDirectAnalysis(project, terrain, relationOverride))
				{
					standardOpportunity2.importance = special.importanceMultiplier;
					yield return standardOpportunity2;
				}
			}
		}
		if (special.recipes != null)
		{
			requiredSomething = true;
			foreach (RecipeDef recipe in special.recipes)
			{
				if (special.opportunityType != null)
				{
					yield return new ResearchOpportunity(project, special.opportunityType, relationOverride, new ROComp_RequiresRecipe(recipe, special.altsMode), "special (recipe)", special.importanceMultiplier, special.rare, special.freebie);
					continue;
				}
				foreach (ResearchOpportunity standardOpportunity3 in OpportunitiesFromPrototyping(project, recipe, relationOverride))
				{
					standardOpportunity3.importance = special.importanceMultiplier;
					yield return standardOpportunity3;
				}
			}
		}
		if (!requiredSomething)
		{
			yield return new ResearchOpportunity(project, special.opportunityType, relation, new ROComp_RequiresNothing(), "special (nothing)", special.importanceMultiplier);
		}
	}

	public IEnumerable<ResearchOpportunity> OpportunitiesFromFuelAnalysis(ResearchProjectDef project, ThingDef fuel, ResearchRelation relation)
	{
		if (fuel.ingestible != null)
		{
			if (fuel.IsDrug)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseFuelDrug, relation, new ROComp_RequiresThing(fuel, AlternatesMode.EQUIVALENT), "fuel analysis (drug)");
			}
			else
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseFuelFood, relation, new ROComp_RequiresThing(fuel, AlternatesMode.EQUIVALENT), "fuel analysis (ingestible)");
			}
		}
		else if (fuel.GetStatValueAbstract(StatDefOf.Flammability) >= 0.5f)
		{
			yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseFuelFlammable, relation, new ROComp_RequiresThing(fuel, AlternatesMode.EQUIVALENT), "fuel analysis (flammable)");
		}
		else
		{
			yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseFuel, relation, new ROComp_RequiresThing(fuel, AlternatesMode.EQUIVALENT), "fuel analysis");
		}
	}

	public IEnumerable<ResearchOpportunity> OpportunitiesFromIngredientAnalysis(ResearchProjectDef project, ThingDef material, ResearchRelation relation)
	{
		if (material.IsMedicine)
		{
			yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseMedicine, relation, new ROComp_RequiresThing(material, AlternatesMode.EQUIVALENT), "ingre. analysis (medicine)");
		}
		else if (material.ingestible != null)
		{
			if (material.IsCorpse)
			{
				ThingDef deadThing = material.ingestible?.sourceDef;
				if (deadThing == null)
				{
					yield break;
				}
				RaceProperties deadThingRace = deadThing.race;
				if (deadThingRace != null)
				{
					if (deadThingRace.IsFleshModAware())
					{
						yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDissect, relation, new ROComp_RequiresThing(material, AlternatesMode.EQUIVALENT), "direct analysis (corpse)");
					}
					else
					{
						yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDissectNonFlesh, relation, new ROComp_RequiresThing(material, AlternatesMode.EQUIVALENT), "direct analysis (corpse non-flesh)");
					}
				}
			}
			else if (material.IsDrug)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDrug, relation, new ROComp_RequiresThing(material, AlternatesMode.EQUIVALENT), "ingre. analysis (drug)");
			}
			else if (material.IsTrulyRawFood())
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseFuelFood, relation, new ROComp_RequiresThing(material, AlternatesMode.EQUIVALENT), "ingre. analysis (raw food)");
			}
			else
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseIngredientsFood, relation, new ROComp_RequiresThing(material, AlternatesMode.EQUIVALENT), "ingre. analysis (ingestible)");
			}
		}
		else
		{
			yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseIngredients, relation, new ROComp_RequiresThing(material, AlternatesMode.EQUIVALENT), "ingre. analysis");
		}
	}

	public IEnumerable<ResearchOpportunity> OpportunitiesFromDirectAnalysis(ResearchProjectDef project, Def reverseEngineerable, ResearchRelation relation)
	{
		AlternatesMode altsMode = AlternatesMode.NONE;
		switch (relation)
		{
		case ResearchRelation.Ancestor:
			altsMode = AlternatesMode.EQUIVALENT;
			break;
		case ResearchRelation.Direct:
			altsMode = AlternatesMode.SIMILAR;
			break;
		}
		if (reverseEngineerable is ThingDef asThing)
		{
			if (typeof(Pawn).IsAssignableFrom(asThing.thingClass) && asThing.race != null)
			{
				if (asThing.race.IsFleshModAware())
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalysePawn, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis pawn");
					if (asThing.race.corpseDef != null)
					{
						yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDissect, relation, new ROComp_RequiresThing(asThing.race.corpseDef, altsMode), "direct analysis pawn (corpse)");
					}
				}
				else
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalysePawnNonFlesh, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis pawn nonflesh");
					if (asThing.race.corpseDef != null)
					{
						yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDissectNonFlesh, relation, new ROComp_RequiresThing(asThing.race.corpseDef, altsMode), "direct analysis pawn (corpse non-flesh)");
					}
				}
			}
			else if (typeof(Plant).IsAssignableFrom(asThing.thingClass))
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalysePlant, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis (plant)");
			}
			else if (!asThing.EverHaulable)
			{
				if (!asThing.IsInstantBuild())
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.Analyse, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis (unhaulable)");
				}
			}
			else if (asThing.IsMedicine)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseMedicine, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis (medicine)");
			}
			else if (asThing.ingestible != null)
			{
				if (asThing.IsDrug)
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseDrug, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis (drug)");
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.TrialDrug, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis (drug)");
				}
				else if (asThing.IsTrulyRawFood())
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseRawFood, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis (raw food)");
				}
				else
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseFood, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis (ingestible)");
				}
			}
			else
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.Analyse, relation, new ROComp_RequiresThing(asThing, altsMode), "direct analysis");
			}
		}
		else if (reverseEngineerable is TerrainDef asTerrain)
		{
			if (asTerrain.IsSoil)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseSoil, relation, new ROComp_RequiresTerrain(asTerrain, altsMode), "direct analysis tr. (soil)");
			}
			else if (asTerrain.BuildableByPlayer)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseFloor, relation, new ROComp_RequiresTerrain(asTerrain, altsMode), "direct analysis tr. (builable)");
			}
			else
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.AnalyseTerrain, relation, new ROComp_RequiresTerrain(asTerrain, altsMode), "direct analysis tr.");
			}
		}
	}

	public IEnumerable<ResearchOpportunity> OpportunitiesFromPrototyping(ResearchProjectDef project, Def prototypeable, ResearchRelation relation)
	{
		if (prototypeable is RecipeDef asRecipe)
		{
			if (asRecipe.IsSurgery)
			{
				if (relation == ResearchRelation.Direct)
				{
					yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.PrototypeSurgery, relation, new ROComp_RequiresRecipe(asRecipe, AlternatesMode.EQUIVALENT), "prototype surgery");
				}
			}
			else if (asRecipe.ProducedThingDef != null && relation == ResearchRelation.Direct)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.PrototypeProduction, relation, new ROComp_RequiresRecipe(asRecipe, AlternatesMode.EQUIVALENT), "prototype");
			}
		}
		else if (prototypeable is ThingDef asThing)
		{
			if (!typeof(Plant).IsAssignableFrom(asThing.thingClass) && !asThing.EverHaulable && !asThing.IsInstantBuild() && relation == ResearchRelation.Direct && asThing.BuildableByPlayer)
			{
				yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.PrototypeConstruction, relation, new ROComp_RequiresThing(asThing, AlternatesMode.EQUIVALENT), "prototype (unhaulable)");
			}
		}
		else if (prototypeable is TerrainDef { BuildableByPlayer: not false } asTerrain && relation == ResearchRelation.Direct && asTerrain.BuildableByPlayer)
		{
			yield return new ResearchOpportunity(project, ResearchOpportunityTypeDefOf.PrototypeTerrainConstruction, relation, new ROComp_RequiresTerrain(asTerrain, AlternatesMode.EQUIVALENT), "prototype tr. (builable)");
		}
	}

	public OpportunityFactoryCollectionsSet FillCollections(ResearchProjectDef project)
	{
		OpportunityFactoryCollectionsSet collections = new OpportunityFactoryCollectionsSet();
		OF_Recipes.MakeFromRecipes(project, collections.GetSet(ResearchRelation.Direct));
		OF_AnalysisRequirements.MakeFromAnalysisRequirements(project, collections.GetSet(ResearchRelation.Direct));
		OF_Unlocks.MakeFromUnlocks(project, collections.GetSet(ResearchRelation.Direct));
		OF_Plants.MakeFromPlants(project, collections.GetSet(ResearchRelation.Direct));
		OF_CompProps.MakeFromFuel(project, collections.GetSet(ResearchRelation.Direct));
		List<ResearchProjectDef> prerequisites = new List<ResearchProjectDef>();
		if (project.prerequisites != null)
		{
			prerequisites.AddRange(project.prerequisites);
		}
		if (project.hiddenPrerequisites != null)
		{
			prerequisites.AddRange(project.hiddenPrerequisites);
		}
		foreach (ResearchProjectDef prerequisite in prerequisites)
		{
			if (prerequisite != project)
			{
				OF_Unlocks.MakeFromUnlocks(prerequisite, collections.GetSet(ResearchRelation.Ancestor));
			}
		}
		collections.RemoveBlacklisted();
		collections.GetSet(ResearchRelation.Ancestor).forIngredientsAnalysis.Clear();
		collections.GetSet(ResearchRelation.Descendant).forIngredientsAnalysis.Clear();
		collections.GetSet(ResearchRelation.Ancestor).forFuelAnalysis.Clear();
		collections.GetSet(ResearchRelation.Descendant).forFuelAnalysis.Clear();
		collections.GetSet(ResearchRelation.Ancestor).forPrototyping.Clear();
		collections.GetSet(ResearchRelation.Descendant).forPrototyping.Clear();
		OF_Specials.MakeFromSpecials(project, collections);
		collections.RemoveDuplicates();
		collections.RemoveAlternatesWhereAppropriate();
		return collections;
	}
}
