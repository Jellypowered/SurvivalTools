using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Opportunities;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public static class OF_Specials
{
	public static void MakeFromSpecials(ResearchProjectDef project, OpportunityFactoryCollectionsSet allCollections)
	{
		HashSet<SpecialResearchOpportunityDef> setAncestor = new HashSet<SpecialResearchOpportunityDef>();
		HashSet<SpecialResearchOpportunityDef> setDirect = new HashSet<SpecialResearchOpportunityDef>();
		HashSet<SpecialResearchOpportunityDef> setDescendant = new HashSet<SpecialResearchOpportunityDef>();
		IEnumerable<SpecialResearchOpportunityDef> projectMatches = DefDatabase<SpecialResearchOpportunityDef>.AllDefsListForReading.Where((SpecialResearchOpportunityDef s) => s.project == project);
		setAncestor.AddRange(projectMatches.Where((SpecialResearchOpportunityDef m) => m.IsForRelation(ResearchRelation.Ancestor)));
		setDirect.AddRange(projectMatches.Where((SpecialResearchOpportunityDef m) => m.IsForRelation(ResearchRelation.Direct)));
		setDescendant.AddRange(projectMatches.Where((SpecialResearchOpportunityDef m) => m.IsForRelation(ResearchRelation.Descendant)));
		allCollections.GetSet(ResearchRelation.Ancestor).specials.AddRange(setAncestor);
		allCollections.GetSet(ResearchRelation.Direct).specials.AddRange(setDirect);
		allCollections.GetSet(ResearchRelation.Descendant).specials.AddRange(setDescendant);
	}
}
