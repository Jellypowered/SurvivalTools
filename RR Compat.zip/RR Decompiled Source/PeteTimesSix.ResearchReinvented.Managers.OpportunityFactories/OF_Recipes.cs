using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Extensions;
using PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;

public class OF_Recipes
{
	public static void MakeFromRecipes(ResearchProjectDef project, OpportunityFactoryCollectionsSetForRelation collections)
	{
		HashSet<ThingDef> users = new HashSet<ThingDef>();
		HashSet<ThingDef> ingredients = new HashSet<ThingDef>();
		HashSet<ThingDef> products = new HashSet<ThingDef>();
		HashSet<Def> prototypeables = new HashSet<Def>();
		foreach (RecipeDef recipe in GatherDirectRecipes(project).Where(delegate(RecipeDef r)
		{
			List<DefModExtension> modExtensions = r.modExtensions;
			return (modExtensions == null || !modExtensions.Any((DefModExtension me) => me is Blacklisted)) && r.PassesIdeoCheck();
		}))
		{
			users.AddRange(recipe.AllRecipeUsers);
			if (recipe.products != null)
			{
				products.AddRange(recipe.products.Select((ThingDefCountClass p) => p.thingDef));
			}
			if (recipe.ingredients != null)
			{
				FilterRecipeIngredients(ingredients, recipe);
			}
			if (!recipe.AllResearchPrerequisites().Except(project).Any())
			{
				prototypeables.Add(recipe);
			}
		}
		foreach (RecipeDef recipe2 in from r in GatherCreationRecipes(project)
			where r.PassesIdeoCheck()
			select r)
		{
			users.AddRange(recipe2.AllRecipeUsers);
		}
		users = FilterProducersToPlausiblyUnlocked(project, users);
		collections.forProductionFacilityAnalysis.AddRange(users);
		collections.forDirectAnalysis.AddRange(products);
		collections.forIngredientsAnalysis.AddRange(ingredients);
		collections.forPrototyping.AddRange(prototypeables);
	}

	private static HashSet<ThingDef> FilterProducersToPlausiblyUnlocked(ResearchProjectDef project, HashSet<ThingDef> users)
	{
		HashSet<ThingDef> resultSet = new HashSet<ThingDef>();
		foreach (ThingDef thingDef in users)
		{
			if (thingDef.researchPrerequisites == null || !project.RequiredToUnlock(thingDef.researchPrerequisites))
			{
				resultSet.Add(thingDef);
			}
		}
		return resultSet;
	}

	private static HashSet<RecipeDef> GatherDirectRecipes(ResearchProjectDef project)
	{
		HashSet<RecipeDef> recipes = new HashSet<RecipeDef>();
		recipes.AddRange(DefDatabase<RecipeDef>.AllDefsListForReading.Where((RecipeDef r) => r.researchPrerequisite == project || (r.researchPrerequisites != null && r.researchPrerequisites.Contains(project))));
		if (project.UnlockedDefs != null)
		{
			recipes.AddRange(project.UnlockedDefs.Where((Def u) => u is RecipeDef).Cast<RecipeDef>());
		}
		return recipes;
	}

	private static HashSet<RecipeDef> GatherCreationRecipes(ResearchProjectDef project)
	{
		HashSet<RecipeDef> recipes = new HashSet<RecipeDef>();
		if (project.UnlockedDefs != null)
		{
			foreach (Def unlock in project.UnlockedDefs)
			{
				ThingDef asThing = unlock as ThingDef;
				if (asThing == null)
				{
					continue;
				}
				recipes.AddRange(DefDatabase<RecipeDef>.AllDefsListForReading.Where((RecipeDef r) => r.products.Any((ThingDefCountClass tdc) => tdc.thingDef == asThing)));
			}
		}
		return recipes;
	}

	private static void FilterRecipeIngredients(HashSet<ThingDef> ingredientsStore, RecipeDef recipe)
	{
		for (int i = 0; i < recipe.ingredients.Count; i++)
		{
			IngredientCount ingredientCount = recipe.ingredients[i];
			if (ingredientCount.IsFixedIngredient)
			{
				ingredientsStore.Add(ingredientCount.FixedIngredient);
			}
			else if (recipe.fixedIngredientFilter != null)
			{
				IEnumerable<ThingDef> allowedThings = ingredientCount.filter.AllowedThingDefs.Where((ThingDef t) => recipe.fixedIngredientFilter.Allows(t));
				ingredientsStore.AddRange(allowedThings);
			}
			else
			{
				ingredientsStore.AddRange(ingredientCount.filter.AllowedThingDefs);
			}
		}
	}
}
