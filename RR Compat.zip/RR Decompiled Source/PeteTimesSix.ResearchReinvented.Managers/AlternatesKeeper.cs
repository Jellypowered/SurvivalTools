using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers;

public static class AlternatesKeeper
{
	public static Dictionary<ThingDef, ThingDef[]> alternatesEquivalent = new Dictionary<ThingDef, ThingDef[]>();

	public static Dictionary<TerrainDef, TerrainDef[]> alternateEquivalentTerrains = new Dictionary<TerrainDef, TerrainDef[]>();

	public static Dictionary<ThingDef, ThingDef[]> alternatesSimilar = new Dictionary<ThingDef, ThingDef[]>();

	public static Dictionary<TerrainDef, TerrainDef[]> alternateSimilarTerrains = new Dictionary<TerrainDef, TerrainDef[]>();

	public static Dictionary<RecipeDef, RecipeDef[]> alternateEquivalentRecipes = new Dictionary<RecipeDef, RecipeDef[]>();

	public static Dictionary<RecipeDef, RecipeDef[]> alternateSimilarRecipes = new Dictionary<RecipeDef, RecipeDef[]>();

	public static void PrepareAlternates()
	{
		Dictionary<ThingDef, HashSet<ThingDef>> altsEquivalentDict = new Dictionary<ThingDef, HashSet<ThingDef>>();
		Dictionary<TerrainDef, HashSet<TerrainDef>> altTerrainsEquivalentDict = new Dictionary<TerrainDef, HashSet<TerrainDef>>();
		Dictionary<RecipeDef, HashSet<RecipeDef>> altRecipesEquivalentDict = new Dictionary<RecipeDef, HashSet<RecipeDef>>();
		Dictionary<ThingDef, HashSet<ThingDef>> altsSimilarDict = new Dictionary<ThingDef, HashSet<ThingDef>>();
		Dictionary<TerrainDef, HashSet<TerrainDef>> altTerrainsSimilarDict = new Dictionary<TerrainDef, HashSet<TerrainDef>>();
		Dictionary<RecipeDef, HashSet<RecipeDef>> altRecipesSimilarDict = new Dictionary<RecipeDef, HashSet<RecipeDef>>();
		foreach (AlternateResearchSubjectsDef altsDef in DefDatabase<AlternateResearchSubjectsDef>.AllDefsListForReading)
		{
			if (altsDef.originals != null)
			{
				foreach (ThingDef original in altsDef.originals)
				{
					if (altsDef.alternatesEquivalent != null)
					{
						if (!altsEquivalentDict.ContainsKey(original))
						{
							altsEquivalentDict[original] = new HashSet<ThingDef>();
						}
						altsEquivalentDict[original].AddRange(altsDef.alternatesEquivalent);
					}
					if (altsDef.alternatesSimilar != null)
					{
						if (!altsSimilarDict.ContainsKey(original))
						{
							altsSimilarDict[original] = new HashSet<ThingDef>();
						}
						altsSimilarDict[original].AddRange(altsDef.alternatesSimilar);
					}
				}
			}
			if (altsDef.originalTerrains != null)
			{
				foreach (TerrainDef originalTerrain in altsDef.originalTerrains)
				{
					if (altsDef.alternateEquivalentTerrains != null)
					{
						if (!altTerrainsEquivalentDict.ContainsKey(originalTerrain))
						{
							altTerrainsEquivalentDict[originalTerrain] = new HashSet<TerrainDef>();
						}
						altTerrainsEquivalentDict[originalTerrain].AddRange(altsDef.alternateEquivalentTerrains);
					}
					if (altsDef.alternateSimilarTerrains != null)
					{
						if (!altTerrainsSimilarDict.ContainsKey(originalTerrain))
						{
							altTerrainsSimilarDict[originalTerrain] = new HashSet<TerrainDef>();
						}
						altTerrainsSimilarDict[originalTerrain].AddRange(altsDef.alternateSimilarTerrains);
					}
				}
			}
			if (altsDef.originalRecipes == null)
			{
				continue;
			}
			foreach (RecipeDef originalRecipe in altsDef.originalRecipes)
			{
				if (altsDef.alternateEquivalentRecipes != null)
				{
					if (!altRecipesEquivalentDict.ContainsKey(originalRecipe))
					{
						altRecipesEquivalentDict[originalRecipe] = new HashSet<RecipeDef>();
					}
					altRecipesEquivalentDict[originalRecipe].AddRange(altsDef.alternateEquivalentRecipes);
				}
				if (altsDef.alternateSimilarRecipes != null)
				{
					if (!altRecipesSimilarDict.ContainsKey(originalRecipe))
					{
						altRecipesSimilarDict[originalRecipe] = new HashSet<RecipeDef>();
					}
					altRecipesSimilarDict[originalRecipe].AddRange(altsDef.alternateSimilarRecipes);
				}
			}
		}
		ThingDef thingDef = default(ThingDef);
		HashSet<ThingDef> hashSet = default(HashSet<ThingDef>);
		foreach (KeyValuePair<ThingDef, HashSet<ThingDef>> item in altsEquivalentDict)
		{
			item.Deconstruct(ref thingDef, ref hashSet);
			ThingDef original2 = thingDef;
			HashSet<ThingDef> alternatesSet = hashSet;
			alternatesEquivalent[original2] = alternatesSet.ToArray();
		}
		foreach (KeyValuePair<ThingDef, HashSet<ThingDef>> item2 in altsSimilarDict)
		{
			item2.Deconstruct(ref thingDef, ref hashSet);
			ThingDef original3 = thingDef;
			HashSet<ThingDef> alternatesSet2 = hashSet;
			alternatesSimilar[original3] = alternatesSet2.ToArray();
		}
		TerrainDef terrainDef = default(TerrainDef);
		HashSet<TerrainDef> hashSet2 = default(HashSet<TerrainDef>);
		foreach (KeyValuePair<TerrainDef, HashSet<TerrainDef>> item3 in altTerrainsEquivalentDict)
		{
			item3.Deconstruct(ref terrainDef, ref hashSet2);
			TerrainDef originalTerrain2 = terrainDef;
			HashSet<TerrainDef> alternatesSet3 = hashSet2;
			alternateEquivalentTerrains[originalTerrain2] = alternatesSet3.ToArray();
		}
		foreach (KeyValuePair<TerrainDef, HashSet<TerrainDef>> item4 in altTerrainsSimilarDict)
		{
			item4.Deconstruct(ref terrainDef, ref hashSet2);
			TerrainDef originalTerrain3 = terrainDef;
			HashSet<TerrainDef> alternatesSet4 = hashSet2;
			alternateSimilarTerrains[originalTerrain3] = alternatesSet4.ToArray();
		}
		RecipeDef recipeDef = default(RecipeDef);
		HashSet<RecipeDef> hashSet3 = default(HashSet<RecipeDef>);
		foreach (KeyValuePair<RecipeDef, HashSet<RecipeDef>> item5 in altRecipesEquivalentDict)
		{
			item5.Deconstruct(ref recipeDef, ref hashSet3);
			RecipeDef originalRecipe2 = recipeDef;
			HashSet<RecipeDef> alternatesSet5 = hashSet3;
			alternateEquivalentRecipes[originalRecipe2] = alternatesSet5.ToArray();
		}
		foreach (KeyValuePair<RecipeDef, HashSet<RecipeDef>> item6 in altRecipesSimilarDict)
		{
			item6.Deconstruct(ref recipeDef, ref hashSet3);
			RecipeDef originalRecipe3 = recipeDef;
			HashSet<RecipeDef> alternatesSet6 = hashSet3;
			alternateSimilarRecipes[originalRecipe3] = alternatesSet6.ToArray();
		}
	}
}
