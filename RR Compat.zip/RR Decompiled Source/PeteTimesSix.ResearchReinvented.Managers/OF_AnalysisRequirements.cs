using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers;

public static class OF_AnalysisRequirements
{
	public static void MakeFromAnalysisRequirements(ResearchProjectDef project, OpportunityFactoryCollectionsSetForRelation collections)
	{
		if (project.requiredAnalyzed == null)
		{
			return;
		}
		HashSet<IngredientCount> ingredientCounts = new HashSet<IngredientCount>();
		foreach (ThingDef analysisThing in project.requiredAnalyzed)
		{
			collections.forDirectAnalysis.Add(analysisThing);
			if (analysisThing.CostList != null && analysisThing.CostList.Count > 0)
			{
				ingredientCounts.AddRange(analysisThing.CostList.Select((ThingDefCountClass c) => c.ToIngredientCount()));
			}
			if (analysisThing.CostStuffCount > 0)
			{
				IEnumerable<ThingDef> stuffs = GenStuff.AllowedStuffsFor(analysisThing);
				ingredientCounts.AddRange(stuffs.Select((ThingDef s) => new ThingDefCountClass(s, analysisThing.costStuffCount).ToIngredientCount()));
			}
			if (analysisThing.researchPrerequisites?.Except(project)?.Any() != true)
			{
				collections.forPrototyping.Add(analysisThing);
			}
		}
		List<ThingDefCount> rawIngredients = new List<ThingDefCount>();
		foreach (IngredientCount ingredientCount in ingredientCounts)
		{
			if (ingredientCount.IsFixedIngredient)
			{
				rawIngredients.Add(new ThingDefCount(ingredientCount.FixedIngredient, (int)ingredientCount.GetBaseCount()));
				continue;
			}
			IEnumerable<ThingDefCount> possibleIngredients = ingredientCount.filter.AllowedThingDefs.Select((ThingDef a) => new ThingDefCount(a, (int)ingredientCount.GetBaseCount()));
			rawIngredients.AddRange(possibleIngredients);
		}
		HashSet<ThingDef> ingredientThings = rawIngredients.Select((ThingDefCount c) => c.ThingDef).ToHashSet();
		collections.forIngredientsAnalysis.AddRange(ingredientThings);
	}
}
