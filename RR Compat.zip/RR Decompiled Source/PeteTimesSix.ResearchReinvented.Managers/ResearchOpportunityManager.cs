using System;
using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers;

public class ResearchOpportunityManager : GameComponent
{
	public int changeTicker = -1;

	public bool clearedThisTick;

	private List<ResearchOpportunity> _allGeneratedOpportunities = new List<ResearchOpportunity>();

	private ResearchProjectDef _currentProject;

	private List<ResearchOpportunity> _currentProjectOpportunitiesCache;

	private HashSet<ResearchOpportunityCategoryDef> _currentOpportunityCategoriesCache;

	public HashSet<ResearchProjectDef> _projectsGenerated = new HashSet<ResearchProjectDef>();

	private List<ResearchOpportunityCategoryTotalsStore> _categoryStores = new List<ResearchOpportunityCategoryTotalsStore>();

	private bool regenerateWhenPossible;

	private Dictionary<ResearchProjectDef, Dictionary<ResearchOpportunityCategoryDef, OpportunityAvailability>> _categoryAvailability = new Dictionary<ResearchProjectDef, Dictionary<ResearchOpportunityCategoryDef, OpportunityAvailability>>();

	private long popupCheckTick = -1L;

	public static ResearchOpportunityManager Instance => Current.Game.GetComponent<ResearchOpportunityManager>();

	public IReadOnlyCollection<ResearchOpportunity> AllGeneratedOpportunities => _allGeneratedOpportunities.AsReadOnly();

	public ResearchProjectDef CurrentProject => _currentProject;

	public IReadOnlyCollection<ResearchOpportunity> CurrentProjectOpportunities
	{
		get
		{
			if (CheckForRegeneration() || _currentProjectOpportunitiesCache == null)
			{
				_currentProjectOpportunitiesCache = AllGeneratedOpportunities.Where((ResearchOpportunity o) => o.IsValid() && o.project == _currentProject).ToList();
			}
			return _currentProjectOpportunitiesCache.AsReadOnly();
		}
	}

	public IReadOnlyCollection<ResearchOpportunityCategoryDef> CurrentProjectOpportunityCategories
	{
		get
		{
			if (CheckForRegeneration() || _currentOpportunityCategoriesCache == null)
			{
				_currentOpportunityCategoriesCache = CurrentProjectOpportunities.Select((ResearchOpportunity o) => o.def.GetCategory(o.relation)).ToHashSet();
			}
			return _currentOpportunityCategoriesCache.ToList().AsReadOnly();
		}
	}

	public ResearchOpportunityManager(Game game)
	{
	}

	public override void GameComponentTick()
	{
		base.GameComponentTick();
		clearedThisTick = false;
		if (regenerateWhenPossible)
		{
			regenerateWhenPossible = false;
			GenerateOpportunities(Find.ResearchManager.GetProject(), forceRegen: true);
		}
		CheckForRegeneration();
	}

	public override void GameComponentUpdate()
	{
		base.GameComponentUpdate();
		if (!Find.TickManager.Paused)
		{
			CheckForPopups();
		}
	}

	public override void FinalizeInit()
	{
		base.FinalizeInit();
		StartupChecks();
	}

	public void StartupChecks()
	{
		bool forceRegen = false;
		if (_projectsGenerated == null)
		{
			Log.Warning("RR: _projectsGenerated was missing!");
			_projectsGenerated = new HashSet<ResearchProjectDef>();
			forceRegen = true;
		}
		if (_allGeneratedOpportunities == null)
		{
			Log.Warning("RR: _allGeneratedOpportunities was missing!");
			_allGeneratedOpportunities = new List<ResearchOpportunity>();
			forceRegen = true;
		}
		if (_categoryAvailability == null)
		{
			Log.Warning("RR: _categoryAvailability was missing!");
			_categoryAvailability = new Dictionary<ResearchProjectDef, Dictionary<ResearchOpportunityCategoryDef, OpportunityAvailability>>();
			forceRegen = true;
		}
		if (_categoryStores == null)
		{
			Log.Warning("RR: _categoryStores was missing!");
			_categoryStores = new List<ResearchOpportunityCategoryTotalsStore>();
			forceRegen = true;
		}
		if (forceRegen)
		{
			GenerateOpportunities(Find.ResearchManager.GetProject(), forceRegen: true);
		}
		else
		{
			_allGeneratedOpportunities = _allGeneratedOpportunities.Where(delegate(ResearchOpportunity o)
			{
				if (!o.IsValid())
				{
					Log.Warning($"[RR]: Research opportunity invalid, loadID: {o?.loadID}, project: {o?.project?.label}");
					return false;
				}
				return true;
			}).ToList();
			CheckForRegeneration();
		}
		CacheClearer.ClearCaches();
	}

	public bool CheckForRegeneration()
	{
		if (Find.ResearchManager.GetProject() != _currentProject)
		{
			PrototypeKeeper.Instance.CancelPrototypes(_currentProject, Find.ResearchManager.GetProject());
			GenerateOpportunities(Find.ResearchManager.GetProject(), forceRegen: false);
			return true;
		}
		return false;
	}

	public void CheckForPopups()
	{
		if (popupCheckTick == Find.TickManager.TicksGame)
		{
			return;
		}
		popupCheckTick = Find.TickManager.TicksGame;
		ResearchProjectDef currentProject = Find.ResearchManager.GetProject();
		if (currentProject == null)
		{
			return;
		}
		if (!_categoryAvailability.ContainsKey(currentProject))
		{
			_categoryAvailability[currentProject] = new Dictionary<ResearchOpportunityCategoryDef, OpportunityAvailability>();
		}
		Dictionary<ResearchOpportunityCategoryDef, OpportunityAvailability> projectCategoryAvailability = _categoryAvailability[currentProject];
		foreach (ResearchOpportunityCategoryDef category in CurrentProjectOpportunityCategories)
		{
			OpportunityAvailability current = category.GetCurrentAvailability(Find.ResearchManager.GetProject());
			if (!projectCategoryAvailability.ContainsKey(category))
			{
				projectCategoryAvailability[category] = current;
			}
			else
			{
				if (projectCategoryAvailability[category] == current)
				{
					continue;
				}
				projectCategoryAvailability[category] = current;
				if (current != OpportunityAvailability.Available)
				{
					continue;
				}
				List<ResearchOpportunity> toPopup = CurrentProjectOpportunities.Where((ResearchOpportunity o) => o.def.generatesPopups && o.def.GetCategory(o.relation) == category).ToList();
				if (!toPopup.Any())
				{
					continue;
				}
				var groups = from o in toPopup
					group o by new { o.def, o.relation };
				foreach (var group in groups)
				{
					bool tooLong = group.Count() > 5;
					string label = group.Key.def.GetHeaderCap(group.Key.relation);
					string msg = ((!tooLong) ? ((string)"RR_opportunityTypeReady".Translate(label, string.Join(", ", group.Select((ResearchOpportunity o) => o.requirement.Subject)))) : ((string)"RR_opportunityTypeReady_Many".Translate(label, string.Join(", ", from o in @group.Take(5)
						select o.requirement.Subject), group.Count() - 6)));
					Messages.Message(msg, MessageTypeDefOf.TaskCompletion, historical: false);
				}
			}
		}
	}

	public ResearchOpportunity GetFirstFilteredOpportunity(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy)
	{
		return GetOpportunityFilter(desiredAvailability, handledBy, null);
	}

	public ResearchOpportunity GetFirstFilteredOpportunity(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, ResearchOpportunityCategoryDef category)
	{
		return GetOpportunityFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.def.GetCategory(op.relation) == category);
	}

	public ResearchOpportunity GetFirstFilteredOpportunity(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Def def)
	{
		return GetOpportunityFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.requirement.MetBy(def));
	}

	public ResearchOpportunity GetFirstFilteredOpportunity(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Thing thing)
	{
		return GetOpportunityFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.requirement.MetBy(thing));
	}

	public ResearchOpportunity GetFirstFilteredOpportunity(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Faction faction)
	{
		return GetOpportunityFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.requirement is ROComp_RequiresFaction rOComp_RequiresFaction && rOComp_RequiresFaction.MetByFaction(faction));
	}

	public ResearchOpportunity GetFirstFilteredOpportunity(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Func<ResearchOpportunity, bool> validator)
	{
		return GetOpportunityFilter(desiredAvailability, handledBy, validator);
	}

	private ResearchOpportunity GetOpportunityFilter(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Func<ResearchOpportunity, bool> validator)
	{
		List<ResearchOpportunity> opportunities = new List<ResearchOpportunity>();
		foreach (ResearchOpportunity op in CurrentProjectOpportunities)
		{
			if ((!desiredAvailability.HasValue || (desiredAvailability.Value & op.CurrentAvailability) != 0) && (!handledBy.HasValue || op.def.handledBy.HasFlag(handledBy.Value)) && (validator == null || validator(op)))
			{
				return op;
			}
		}
		return null;
	}

	public List<ResearchOpportunity> GetFilteredOpportunities(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy)
	{
		return GetOpportunitiesFilter(desiredAvailability, handledBy, null);
	}

	public List<ResearchOpportunity> GetFilteredOpportunities(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Type driverClass)
	{
		return GetOpportunitiesFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.JobDefs != null && op.JobDefs.Any((JobDef jd) => jd.driverClass == driverClass));
	}

	public List<ResearchOpportunity> GetFilteredOpportunities(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, ResearchOpportunityCategoryDef category)
	{
		return GetOpportunitiesFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.def.GetCategory(op.relation) == category);
	}

	public List<ResearchOpportunity> GetFilteredOpportunities(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Def def)
	{
		return GetOpportunitiesFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.requirement.MetBy(def));
	}

	public List<ResearchOpportunity> GetFilteredOpportunities(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Thing thing)
	{
		return GetOpportunitiesFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.requirement.MetBy(thing));
	}

	public List<ResearchOpportunity> GetFilteredOpportunities(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Faction faction)
	{
		return GetOpportunitiesFilter(desiredAvailability, handledBy, (ResearchOpportunity op) => op.requirement is ROComp_RequiresFaction rOComp_RequiresFaction && rOComp_RequiresFaction.MetByFaction(faction));
	}

	public List<ResearchOpportunity> GetFilteredOpportunities(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Func<ResearchOpportunity, bool> validator)
	{
		return GetOpportunitiesFilter(desiredAvailability, handledBy, validator);
	}

	private List<ResearchOpportunity> GetOpportunitiesFilter(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, Func<ResearchOpportunity, bool> validator)
	{
		List<ResearchOpportunity> opportunities = new List<ResearchOpportunity>();
		foreach (ResearchOpportunity op in CurrentProjectOpportunities)
		{
			if ((!desiredAvailability.HasValue || (desiredAvailability.Value & op.CurrentAvailability) != 0) && (!handledBy.HasValue || op.def.handledBy.HasFlag(handledBy.Value)) && (validator == null || validator(op)))
			{
				opportunities.Add(op);
			}
		}
		return opportunities;
	}

	public List<ResearchOpportunity> GetOpportunitiesFilterForProject(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, ResearchProjectDef project, Func<ResearchOpportunity, bool> validator)
	{
		List<ResearchOpportunity> opportunities = new List<ResearchOpportunity>();
		if (!_projectsGenerated.Contains(project))
		{
			GenerateOpportunities(project, forceRegen: false);
		}
		foreach (ResearchOpportunity op in AllGeneratedOpportunities)
		{
			if (project == op.project && (!desiredAvailability.HasValue || (desiredAvailability.Value & op.CurrentAvailability) != 0) && (!handledBy.HasValue || op.def.handledBy.HasFlag(handledBy.Value)) && (validator == null || validator(op)))
			{
				opportunities.Add(op);
			}
		}
		return opportunities;
	}

	public List<ResearchOpportunity> GetOpportunitiesFilterForProjects(OpportunityAvailability? desiredAvailability, HandlingMode? handledBy, IEnumerable<ResearchProjectDef> projects, Func<ResearchOpportunity, bool> validator)
	{
		List<ResearchOpportunity> opportunities = new List<ResearchOpportunity>();
		foreach (ResearchProjectDef project in projects)
		{
			if (!_projectsGenerated.Contains(project))
			{
				GenerateOpportunities(project, forceRegen: false);
			}
		}
		foreach (ResearchOpportunity op in AllGeneratedOpportunities)
		{
			if (projects.Contains(op.project) && (!desiredAvailability.HasValue || (desiredAvailability.Value & op.CurrentAvailability) != 0) && (!handledBy.HasValue || op.def.handledBy.HasFlag(handledBy.Value)) && (validator == null || validator(op)))
			{
				opportunities.Add(op);
			}
		}
		return opportunities;
	}

	public ResearchOpportunityCategoryTotalsStore GetTotalsStore(ResearchProjectDef project, ResearchOpportunityCategoryDef category)
	{
		return _categoryStores.FirstOrDefault((ResearchOpportunityCategoryTotalsStore cs) => cs.project == project && cs.category == category);
	}

	public void PostFinishProject(ResearchProjectDef project)
	{
		_allGeneratedOpportunities.RemoveAll((ResearchOpportunity o) => o.project == project);
		_projectsGenerated.Remove(project);
		_categoryStores.RemoveAll((ResearchOpportunityCategoryTotalsStore cs) => cs.project == project);
		if (_currentProject == project)
		{
			_currentProject = null;
			_currentProjectOpportunitiesCache?.Clear();
			_currentOpportunityCategoriesCache?.Clear();
		}
	}

	public void ResetAllProgress()
	{
		_allGeneratedOpportunities?.Clear();
		_currentProjectOpportunitiesCache?.Clear();
		_currentOpportunityCategoriesCache?.Clear();
		_categoryStores?.Clear();
		_projectsGenerated?.Clear();
		clearedThisTick = true;
	}

	public void FinishProject(ResearchProjectDef project, bool doCompletionDialog = false, Pawn researcher = null)
	{
		Find.ResearchManager.FinishProject(project, doCompletionDialog, researcher);
	}

	public void DelayedRegeneration()
	{
		regenerateWhenPossible = true;
	}

	public void GenerateOpportunities(ResearchProjectDef project, bool forceRegen)
	{
		if (_currentProject == project && !forceRegen)
		{
			return;
		}
		_currentProjectOpportunitiesCache = null;
		_currentOpportunityCategoriesCache = null;
		_currentProject = project;
		if (project == null)
		{
			return;
		}
		if (_projectsGenerated.Contains(project))
		{
			if (!forceRegen)
			{
				return;
			}
			List<ResearchOpportunity> preexistingOpportunities = _allGeneratedOpportunities.Where((ResearchOpportunity o) => o.project == project).ToList();
			foreach (ResearchOpportunity preexisting in preexistingOpportunities)
			{
				_allGeneratedOpportunities.Remove(preexisting);
			}
		}
		var (newOpportunities, categoryStores) = ResearchOpportunityPrefabs.MakeOpportunitiesForProject(project);
		_categoryStores.RemoveAll((ResearchOpportunityCategoryTotalsStore cs) => cs.project == project);
		_categoryStores.AddRange(categoryStores);
		IEnumerable<ResearchOpportunity> invalidOpportunities = newOpportunities.Where((ResearchOpportunity o) => !o.IsValid());
		if (invalidOpportunities.Any())
		{
			Log.Warning($"Generated {invalidOpportunities.Count()} invalid opportunities for project {project}!");
		}
		_allGeneratedOpportunities.AddRange(newOpportunities.Where((ResearchOpportunity o) => o.IsValid()));
		_projectsGenerated.Add(project);
		if (ResearchReinvented_Debug.debugPrintouts)
		{
			Log.Message("Listing generated opportunities for current project " + _currentProject.label + "...");
			foreach (ResearchOpportunity opportunity in newOpportunities)
			{
				Log.Message($" |-- {opportunity.ShortDesc} -- {opportunity.debug_source} (imp.: {opportunity.importance})");
			}
		}
		_categoryAvailability.Clear();
		if (!_categoryAvailability.ContainsKey(project))
		{
			_categoryAvailability[project] = new Dictionary<ResearchOpportunityCategoryDef, OpportunityAvailability>();
		}
		Dictionary<ResearchOpportunityCategoryDef, OpportunityAvailability> projectCategoryAvailability = _categoryAvailability[project];
		foreach (ResearchOpportunityCategoryDef category in CurrentProjectOpportunityCategories)
		{
			projectCategoryAvailability[category] = category.GetCurrentAvailability(project);
		}
	}

	public override void ExposeData()
	{
		base.ExposeData();
		if (Scribe.mode == LoadSaveMode.Saving)
		{
			_allGeneratedOpportunities = _allGeneratedOpportunities.Where((ResearchOpportunity o) => o.IsValid()).ToList();
		}
		Scribe_Values.Look(ref changeTicker, "changeTicker", -1);
		Scribe_Collections.Look(ref _allGeneratedOpportunities, "_allGeneratedOpportunities", LookMode.Deep);
		Scribe_Collections.Look(ref _projectsGenerated, "_allProjectsWithGeneratedOpportunities", LookMode.Def);
		Scribe_Defs.Look(ref _currentProject, "currentProject");
		Scribe_Collections.Look(ref _categoryStores, "_categoryStores", LookMode.Deep);
		if (Scribe.mode == LoadSaveMode.PostLoadInit)
		{
			_allGeneratedOpportunities = _allGeneratedOpportunities.Where((ResearchOpportunity o) => o.IsValid()).ToList();
		}
	}
}
