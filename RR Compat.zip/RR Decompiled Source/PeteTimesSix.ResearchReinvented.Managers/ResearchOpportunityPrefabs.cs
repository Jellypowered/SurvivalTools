using System;
using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers.OpportunityFactories;
using PeteTimesSix.ResearchReinvented.Opportunities;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers;

public static class ResearchOpportunityPrefabs
{
	public static readonly float MIN_RESEARCH_POINTS = 1f;

	public static (List<ResearchOpportunity> opportunities, List<ResearchOpportunityCategoryTotalsStore> categoryStores) MakeOpportunitiesForProject(ResearchProjectDef project)
	{
		if (ResearchReinvented_Debug.debugPrintouts)
		{
			Log.Message("Generating opportunities for project " + project.label + "...");
		}
		List<ResearchOpportunity> projectOpportunities = new List<ResearchOpportunity>();
		MasterFactory factory = new MasterFactory();
		projectOpportunities.AddRange(factory.GenerateOpportunities(project));
		HashSet<ResearchOpportunityCategoryDef> categories = new HashSet<ResearchOpportunityCategoryDef>();
		foreach (ResearchOpportunity opportunity in projectOpportunities)
		{
			foreach (ResearchOpportunityCategoryDef category in opportunity.def.GetAllCategories())
			{
				if (!categories.Contains(category))
				{
					categories.Add(category);
				}
			}
		}
		float projectResearchPoints = project.baseCost;
		float totalMultiplier = 0f;
		foreach (ResearchOpportunityCategoryDef category2 in categories)
		{
			if (projectOpportunities.Any((ResearchOpportunity o) => o.def.GetCategory(o.relation) == category2))
			{
				totalMultiplier += category2.Settings.importanceMultiplierCounted;
			}
		}
		if (totalMultiplier < 1f)
		{
			totalMultiplier = 1f;
		}
		List<ResearchOpportunityCategoryTotalsStore> totalStores = new List<ResearchOpportunityCategoryTotalsStore>();
		foreach (ResearchOpportunityCategoryDef category3 in categories)
		{
			IEnumerable<ResearchOpportunity> allMatchingOpportunities = projectOpportunities.Where((ResearchOpportunity o) => o.def.GetCategory(o.relation) == category3);
			IEnumerable<ResearchOpportunity> countedMatchingOpportunities = allMatchingOpportunities.Where((ResearchOpportunity o) => !o.IsRare && !o.IsFreebie);
			ResearchOpportunityCategoryTotalsStore totalsStore = new ResearchOpportunityCategoryTotalsStore
			{
				project = project,
				category = category3
			};
			totalsStore.researchPoints = projectResearchPoints / totalMultiplier * category3.Settings.importanceMultiplier + projectResearchPoints * category3.Settings.importanceStatic;
			if (totalsStore.researchPoints < MIN_RESEARCH_POINTS)
			{
				totalsStore.researchPoints = MIN_RESEARCH_POINTS;
			}
			totalStores.Add(totalsStore);
			if (!allMatchingOpportunities.Any())
			{
				continue;
			}
			float categoryImportanceTotal = countedMatchingOpportunities.Sum((ResearchOpportunity o) => o.importance);
			HashSet<(ResearchOpportunityTypeDef, ResearchRelation)> matchingOpportunityTypes = allMatchingOpportunities.Select((ResearchOpportunity o) => (def: o.def, rel: o.relation)).ToHashSet();
			float minimumOpportunityResearchPoints = totalsStore.researchPoints / category3.Settings.targetIterations;
			foreach (var type in matchingOpportunityTypes)
			{
				float typeResearchPoints = totalsStore.researchPoints / (float)matchingOpportunityTypes.Count();
				IEnumerable<ResearchOpportunity> allMatchingOpportunitiesOfType = allMatchingOpportunities.Where((ResearchOpportunity o) => o.def == type.Item1 && o.relation == type.Item2);
				IEnumerable<ResearchOpportunity> countedMatchingOpportunitiesOfType = countedMatchingOpportunities.Where((ResearchOpportunity o) => o.def == type.Item1 && o.relation == type.Item2);
				int matchCount = countedMatchingOpportunitiesOfType.Count();
				float typeImportanceTotal = countedMatchingOpportunitiesOfType.Sum((ResearchOpportunity o) => (!o.requirement.IsRare) ? o.importance : ((float)matchCount));
				if (typeImportanceTotal < 1f)
				{
					typeImportanceTotal = 1f;
				}
				if (typeImportanceTotal > category3.Settings.targetIterations)
				{
					typeImportanceTotal = category3.Settings.targetIterations;
				}
				float baseImportance = 1f / typeImportanceTotal;
				if (ResearchReinvented_Debug.debugPrintouts)
				{
					Log.Message($"project {project} ({projectResearchPoints}) category {category3.label} ({categoryImportanceTotal}) min: {minimumOpportunityResearchPoints} type.def {type.Item1.defName} type.rel {type.Item2} (points: {typeResearchPoints} base imp.: {baseImportance} count:{matchCount}) points per: {typeResearchPoints * baseImportance}");
				}
				foreach (ResearchOpportunity opportunity2 in allMatchingOpportunitiesOfType)
				{
					opportunity2.SetMaxProgress(Math.Max(val2: (!opportunity2.IsRare) ? Math.Max(typeResearchPoints * baseImportance * opportunity2.importance, minimumOpportunityResearchPoints * opportunity2.importance) : Math.Max(typeResearchPoints, minimumOpportunityResearchPoints), val1: MIN_RESEARCH_POINTS));
				}
			}
		}
		return (opportunities: projectOpportunities, categoryStores: totalStores);
	}
}
