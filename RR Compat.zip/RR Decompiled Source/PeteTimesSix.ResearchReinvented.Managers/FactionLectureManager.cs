using System.Collections.Generic;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers;

public class FactionLectureManager : GameComponent
{
	private Dictionary<Faction, int> _factionLectureCooldowns = new Dictionary<Faction, int>();

	public static int LectureCooldownTicks = 15000;

	public static FactionLectureManager Instance => Current.Game.GetComponent<FactionLectureManager>();

	public FactionLectureManager(Game game)
	{
	}

	public bool IsOnCooldown(Faction faction)
	{
		if (!_factionLectureCooldowns.ContainsKey(faction))
		{
			return false;
		}
		return Find.TickManager.TicksAbs - _factionLectureCooldowns[faction] < LectureCooldownTicks;
	}

	public void PutOnCooldown(Faction faction)
	{
		_factionLectureCooldowns[faction] = Find.TickManager.TicksAbs;
	}
}
