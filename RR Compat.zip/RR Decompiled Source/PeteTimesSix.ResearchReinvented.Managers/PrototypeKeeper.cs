using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Managers;

public class PrototypeKeeper : GameComponent
{
	private HashSet<Thing> _prototypes = new HashSet<Thing>();

	private Dictionary<Map, PrototypeTerrainGrid> _prototypeTerrainGrids = new Dictionary<Map, PrototypeTerrainGrid>();

	public static PrototypeKeeper Instance => Current.Game.GetComponent<PrototypeKeeper>();

	public HashSet<Thing> Prototypes => _prototypes;

	public PrototypeKeeper(Game game)
	{
	}

	public PrototypeTerrainGrid GetMapPrototypeTerrainGrid(Map map)
	{
		if (_prototypeTerrainGrids == null)
		{
			_prototypeTerrainGrids = new Dictionary<Map, PrototypeTerrainGrid>();
		}
		if (_prototypeTerrainGrids.TryGetValue(map, out var grid))
		{
			return grid;
		}
		grid = map.GetComponent<PrototypeTerrainGrid>();
		_prototypeTerrainGrids[map] = grid;
		return grid;
	}

	public bool IsPrototype(Thing thing)
	{
		Thing unwrapped = thing.UnwrapIfWrapped();
		if (unwrapped != thing && Prototypes.Contains(unwrapped))
		{
			return true;
		}
		return Prototypes.Contains(thing);
	}

	public void MarkAsPrototype(Thing thing)
	{
		Prototypes.Add(thing);
	}

	public void UnmarkAsPrototype(Thing thing)
	{
		Thing unwrapped = thing.UnwrapIfWrapped();
		if (unwrapped != thing)
		{
			Prototypes.Remove(unwrapped);
		}
		Prototypes.Remove(thing);
	}

	public bool IsTerrainPrototype(IntVec3 position, Map map)
	{
		return GetMapPrototypeTerrainGrid(map)?.IsTerrainPrototype(position) ?? false;
	}

	public bool IsFoundationTerrainPrototype(IntVec3 position, Map map)
	{
		return GetMapPrototypeTerrainGrid(map)?.IsFoundationTerrainPrototype(position) ?? false;
	}

	public void MarkTerrainAsPrototype(IntVec3 position, Map map, TerrainDef terrain)
	{
		GetMapPrototypeTerrainGrid(map)?.MarkTerrainAsPrototype(position, terrain);
	}

	public void UnmarkTerrainAsPrototype(IntVec3 position, Map map)
	{
		GetMapPrototypeTerrainGrid(map)?.UnmarkTerrainAsPrototype(position);
	}

	public void MarkFoundationTerrainAsPrototype(IntVec3 position, Map map, TerrainDef terrain)
	{
		GetMapPrototypeTerrainGrid(map)?.MarkFoundationTerrainAsPrototype(position, terrain);
	}

	public void UnmarkFoundationTerrainAsPrototype(IntVec3 position, Map map)
	{
		GetMapPrototypeTerrainGrid(map)?.UnmarkFoundationTerrainAsPrototype(position);
	}

	public void DebugDrawOnMap()
	{
		if (ResearchReinvented_Debug.drawPrototypeGrid)
		{
			GetMapPrototypeTerrainGrid(Find.CurrentMap)?.DebugDrawOnMap();
		}
	}

	public override void ExposeData()
	{
		if (Scribe.mode == LoadSaveMode.Saving)
		{
			List<Thing> tempList = _prototypes.ToList();
			foreach (Thing thing in tempList)
			{
				if (thing.Destroyed)
				{
					_prototypes.Remove(thing);
				}
			}
		}
		Scribe_Collections.Look(ref _prototypes, "_prototypes", LookMode.Reference);
	}

	public void CancelPrototypes(ResearchProjectDef previousProject, ResearchProjectDef currentProject)
	{
		if (ResearchReinventedMod.Settings.disablePrototypeBillCancellation)
		{
			return;
		}
		IEnumerable<ResearchOpportunity> protoOps = ResearchOpportunityManager.Instance.AllGeneratedOpportunities.Where((ResearchOpportunity o) => o.project != currentProject && o.def.handledBy.HasFlag(HandlingMode.Special_Prototype));
		HashSet<Def> defsToCancel = new HashSet<Def>();
		foreach (ResearchOpportunity protoOp in protoOps)
		{
			if (protoOp.requirement is ROComp_RequiresThing { AllThings: var allThings })
			{
				foreach (ThingDef altThing in allThings)
				{
					defsToCancel.Add(altThing);
				}
			}
			else if (protoOp.requirement is ROComp_RequiresTerrain { AllTerrains: var allTerrains })
			{
				foreach (TerrainDef altTerrain in allTerrains)
				{
					defsToCancel.Add(altTerrain);
				}
			}
			else if (protoOp.requirement is ROComp_RequiresRecipe { AllRecipes: var allRecipes })
			{
				foreach (RecipeDef altRecipe in allRecipes)
				{
					defsToCancel.Add(altRecipe);
				}
			}
		}
		if (defsToCancel.Contains(null))
		{
			defsToCancel.Remove(null);
		}
		foreach (Map map in Find.Maps)
		{
			foreach (Thing blueprint in (from t in map.listerThings.ThingsInGroup(ThingRequestGroup.Blueprint)
				where t.Faction == Faction.OfPlayer
				select t).ToList())
			{
				if (defsToCancel.Contains(blueprint.def.entityDefToBuild) && !blueprint.Destroyed)
				{
					Prototypes.Remove(blueprint);
					blueprint.Destroy(DestroyMode.Cancel);
				}
			}
			foreach (Thing frame in (from t in map.listerThings.ThingsInGroup(ThingRequestGroup.BuildingFrame)
				where t.Faction == Faction.OfPlayer
				select t).ToList())
			{
				if (defsToCancel.Contains(frame.def.entityDefToBuild) && !frame.Destroyed)
				{
					Prototypes.Remove(frame);
					frame.Destroy(DestroyMode.Cancel);
				}
			}
			foreach (UnfinishedThing uft in map.listerThings.AllThings.Where((Thing t) => t.def.isUnfinishedThing && t is UnfinishedThing).Cast<UnfinishedThing>().ToList())
			{
				if (defsToCancel.Contains(uft.Recipe) && !uft.Destroyed)
				{
					Prototypes.Remove(uft);
					uft.Destroy(DestroyMode.Cancel);
				}
			}
			foreach (IBillGiver billHolder in (from t in map.listerThings.ThingsInGroup(ThingRequestGroup.PotentialBillGiver)
				where t is IBillGiver
				select t).Cast<IBillGiver>().ToList())
			{
				List<Bill> billsToCancel = billHolder.BillStack.Bills.Where((Bill b) => defsToCancel.Contains(b.recipe)).ToList();
				foreach (Bill bill in billsToCancel)
				{
					billHolder.BillStack.Delete(bill);
				}
			}
		}
	}
}
