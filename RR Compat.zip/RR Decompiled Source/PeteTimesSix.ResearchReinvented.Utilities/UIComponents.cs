using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Utilities;

public static class UIComponents
{
	private static readonly Color BadValueOutlineColor = new Color(0.9f, 0.1f, 0.1f, 1f);

	public static void DrawBadTextValueOutline(Rect rect)
	{
		Color prevColor = GUI.color;
		GUI.color = BadValueOutlineColor;
		Widgets.DrawBox(rect);
		GUI.color = prevColor;
	}
}
