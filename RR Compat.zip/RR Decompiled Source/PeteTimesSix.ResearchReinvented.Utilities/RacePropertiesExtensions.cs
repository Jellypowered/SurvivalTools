using Verse;

namespace PeteTimesSix.ResearchReinvented.Utilities;

public static class RacePropertiesExtensions
{
	public static bool IsFleshModAware(this RaceProperties raceProperties)
	{
		return raceProperties.IsFlesh;
	}
}
