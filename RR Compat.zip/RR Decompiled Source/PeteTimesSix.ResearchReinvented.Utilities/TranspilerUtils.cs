using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using HarmonyLib;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Utilities;

public static class TranspilerUtils
{
	public static IEnumerable<CodeInstruction> IterateTo(IEnumerator<CodeInstruction> enumerator, CodeInstruction[] targetInstructions, out CodeInstruction[] matchedInstructions, out bool found, bool ignoreMissingLabelOperands = true)
	{
		found = false;
		CircularBuffer<CodeInstruction> matchBuffer = new CircularBuffer<CodeInstruction>(targetInstructions.Length);
		List<CodeInstruction> instructionBuffer = new List<CodeInstruction>();
		while (enumerator.MoveNext())
		{
			CodeInstruction instruction = enumerator.Current;
			instructionBuffer.Add(instruction);
			matchBuffer.PushBack(instruction);
			if (InstructionsMatch(targetInstructions, matchBuffer, ignoreMissingLabelOperands))
			{
				matchedInstructions = matchBuffer.ToArray();
				found = true;
				return instructionBuffer;
			}
		}
		matchedInstructions = null;
		return instructionBuffer;
	}

	private static bool InstructionsMatch(CodeInstruction[] targetInstructions, CircularBuffer<CodeInstruction> instructions, bool ignoreMissingLabelOperands)
	{
		if (instructions.Count() < targetInstructions.Length)
		{
			return false;
		}
		for (int i = 0; i < targetInstructions.Length; i++)
		{
			if (targetInstructions[i].opcode != instructions[i].opcode)
			{
				return false;
			}
			if (targetInstructions[i].operand == instructions[i].operand)
			{
				continue;
			}
			if (instructions[i].operand is LocalBuilder localBuilder && targetInstructions[i].operand != null)
			{
				try
				{
					int inty = Convert.ToInt32(targetInstructions[i].operand);
					if (localBuilder.LocalIndex == inty)
					{
						continue;
					}
				}
				catch (Exception ex)
				{
					Log.Error("Failed to convert operand to Int32 while checking localIndex (" + ex.Message + ")");
					return false;
				}
				return false;
			}
			if (!ignoreMissingLabelOperands)
			{
				return false;
			}
			if (targetInstructions[i].operand != null)
			{
				return false;
			}
			return instructions[i].operand is Label;
		}
		return true;
	}
}
