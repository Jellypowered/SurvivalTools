using Verse;

namespace PeteTimesSix.ResearchReinvented.Utilities;

public class ExposableListItem<T> : IExposable where T : IExposable
{
	public T exposable;

	public bool resolvable;

	public ExposableListItem()
	{
	}

	public ExposableListItem(T exposable)
	{
		this.exposable = exposable;
		resolvable = exposable != null;
	}

	public void ExposeData()
	{
		try
		{
			Scribe_Deep.Look(ref exposable, "exposable");
			resolvable = exposable != null;
		}
		catch
		{
			resolvable = false;
		}
		if (!resolvable)
		{
			Log.Message("Found unresolvable " + typeof(T).FullName + " in exported List");
		}
	}

	public static implicit operator T(ExposableListItem<T> exp)
	{
		return exp.exposable;
	}
}
