using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Utilities;

public static class PawnExtensions
{
	public static bool CanEverDoResearch(this Pawn pawn)
	{
		if (pawn != null && pawn.skills != null)
		{
			return !pawn.WorkTypeIsDisabled(WorkTypeDefOf.Research);
		}
		return false;
	}

	public static bool CanNowDoResearch(this Pawn pawn, bool checkFaction = true)
	{
		if (pawn.CanEverDoResearch() && pawn.Awake())
		{
			if (checkFaction)
			{
				return pawn.Faction == Faction.OfPlayer;
			}
			return true;
		}
		return false;
	}
}
