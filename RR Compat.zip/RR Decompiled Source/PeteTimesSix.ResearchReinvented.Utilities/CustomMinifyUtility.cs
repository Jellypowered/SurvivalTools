namespace PeteTimesSix.ResearchReinvented.Utilities;

internal class CustomMinifyUtility
{
}
