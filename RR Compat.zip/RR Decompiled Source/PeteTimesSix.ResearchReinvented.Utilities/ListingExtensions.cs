using System;
using PeteTimesSix.ResearchReinvented.Utilities.CustomWidgets;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace PeteTimesSix.ResearchReinvented.Utilities;

public static class ListingExtensions
{
	private static readonly Color SelectedButtonColor = new Color(0.65f, 1f, 0.65f);

	private static float ButtonTextPadding = 5f;

	private static float AfterLabelMinGap = 10f;

	public static float ColumnGap = 17f;

	public static void FloatRangeLabeled(this Listing_Standard instance, string label, ref FloatRange range, float min, float max, float roundTo = -1f, float displayMult = 1f, float decimalPlaces = 0f, string valueSuffix = "", string tooltip = null, Action onChange = null)
	{
		if (!string.IsNullOrEmpty(label))
		{
			instance.Label((TaggedString)(label + ": " + (range.min * displayMult).ToString($"F{decimalPlaces}") + valueSuffix + " - " + (range.max * displayMult).ToString($"F{decimalPlaces}") + valueSuffix), -1f, tooltip);
		}
		Rect rect = instance.GetRect(28f);
		if (!instance.BoundingRectCached.HasValue || rect.Overlaps(instance.BoundingRectCached.Value))
		{
			FloatRange valuesBefore = range;
			CustomFloatRange.FloatRange(rect, (int)instance.CurHeight, ref range, min, max, roundTo);
			if (valuesBefore.min != range.min || valuesBefore.max != range.max)
			{
				onChange?.Invoke();
			}
		}
	}

	public static void CheckboxLabeled(this Listing_Standard instance, string label, ref bool checkOn, string tooltip = null, Action onChange = null)
	{
		bool valueBefore = checkOn;
		instance.CheckboxLabeled(label, ref checkOn, tooltip);
		if (checkOn != valueBefore)
		{
			onChange?.Invoke();
		}
	}

	public static void SliderLabeled(this Listing_Standard instance, string label, ref float value, float min, float max, float roundTo = -1f, float displayMult = 1f, int decimalPlaces = 0, string valueSuffix = "", string tooltip = null, Action onChange = null)
	{
		if (!string.IsNullOrEmpty(label))
		{
			instance.Label((TaggedString)(label + ": " + (value * displayMult).ToString($"F{decimalPlaces}") + valueSuffix), -1f, tooltip);
		}
		float valueBefore = value;
		value = instance.FullSlider(value, min, max, roundTo);
		if (value != valueBefore)
		{
			onChange?.Invoke();
		}
	}

	public static float FullSlider(this Listing_Standard instance, float val, float min, float max, float roundTo = -1f, bool middleAlignment = false, string label = null, string leftAlignedLabel = null, string rightAlignedLabel = null)
	{
		float newVal = Widgets.HorizontalSlider(instance.GetRect(22f), val, min, max, middleAlignment, label, leftAlignedLabel, rightAlignedLabel, roundTo);
		if (newVal != val)
		{
			SoundDefOf.DragSlider.PlayOneShotOnCamera();
		}
		instance.Gap(instance.verticalSpacing);
		return newVal;
	}

	public static void Spinner(this Listing_Standard instance, string label, ref int value, int increment = 1, int? min = null, int? max = null, string tooltip = null, Action onChange = null)
	{
		if (!string.IsNullOrEmpty(label))
		{
			instance.Label(label ?? "");
		}
		float lineHeight = Text.LineHeight;
		Rect rect = instance.GetRect(lineHeight);
		float buttonSize = lineHeight;
		Rect textRect = new Rect(rect.x + buttonSize + 1f, rect.y, rect.width - buttonSize * 2f - 2f, rect.height);
		NumberField(ref value, textRect, onChange);
		Rect leftButtonRect = new Rect(rect.x, rect.y, buttonSize, buttonSize);
		Rect rightButtonRect = new Rect(rect.x + rect.width - buttonSize, rect.y, buttonSize, buttonSize);
		if (Widgets.ButtonText(leftButtonRect, "-") && (!min.HasValue || min <= value - increment))
		{
			value -= increment;
			onChange?.Invoke();
		}
		if (Widgets.ButtonText(rightButtonRect, "+") && (!max.HasValue || max >= value + increment))
		{
			value += increment;
			onChange?.Invoke();
		}
	}

	public static void NumberField(ref int value, Rect rect, Action onChange = null)
	{
		string valText = Widgets.TextField(rect, value.ToString());
		if (int.TryParse(valText, out var result))
		{
			if (value != result)
			{
				value = result;
				onChange?.Invoke();
			}
		}
		else
		{
			UIComponents.DrawBadTextValueOutline(rect);
		}
	}

	public static void EnumSelector<T>(this Listing_Standard listing, string label, ref T value, string valueLabelPrefix, string valueTooltipPostfix = "_tooltip", string tooltip = null, Action onChange = null, float? lineHeightOverride = null) where T : Enum
	{
		string[] names = Enum.GetNames(value.GetType());
		float lineHeight = lineHeightOverride ?? Text.LineHeight;
		float labelWidth = 0f;
		if (!string.IsNullOrEmpty(label))
		{
			labelWidth = Text.CalcSize(label).x + AfterLabelMinGap;
		}
		float buttonsWidth = 0f;
		string[] array = names;
		foreach (string name in array)
		{
			string text = (valueLabelPrefix + name).Translate();
			float width = Text.CalcSize(text).x + ButtonTextPadding * 2f;
			if (buttonsWidth < width)
			{
				buttonsWidth = width;
			}
		}
		bool fitsOnLabelRow = buttonsWidth * (float)names.Length + labelWidth < listing.ColumnWidth;
		float buttonsRectWidth = (fitsOnLabelRow ? (listing.ColumnWidth - (labelWidth + 1f)) : listing.ColumnWidth);
		int rowNum = 0;
		int columnNum = 0;
		int maxColumnNum = 0;
		string[] array2 = names;
		foreach (string name2 in array2)
		{
			if ((float)(columnNum + 1) * buttonsWidth > buttonsRectWidth)
			{
				columnNum = 0;
				rowNum++;
			}
			float x = (float)columnNum * buttonsWidth;
			float y = (float)rowNum * lineHeight;
			columnNum++;
			if (rowNum == 0 && maxColumnNum < columnNum)
			{
				maxColumnNum = columnNum;
			}
		}
		rowNum++;
		if (!fitsOnLabelRow)
		{
			rowNum++;
		}
		Rect wholeRect = listing.GetRect((float)rowNum * lineHeight);
		if (!tooltip.NullOrEmpty())
		{
			if (Mouse.IsOver(wholeRect))
			{
				Widgets.DrawHighlight(wholeRect);
			}
			TooltipHandler.TipRegion(wholeRect, tooltip);
		}
		if (!string.IsNullOrEmpty(label))
		{
			Rect labelRect = wholeRect.TopPartPixels(lineHeight).LeftPartPixels(labelWidth);
			GUI.color = Color.white;
			Widgets.Label(labelRect, label);
		}
		Rect buttonsRect = (fitsOnLabelRow ? wholeRect.RightPartPixels(buttonsRectWidth) : wholeRect.BottomPartPixels(wholeRect.height - lineHeight));
		buttonsWidth = buttonsRectWidth / (float)maxColumnNum;
		rowNum = 0;
		columnNum = 0;
		string[] array3 = names;
		foreach (string name3 in array3)
		{
			if ((float)(columnNum + 1) * buttonsWidth > buttonsRectWidth + 2f)
			{
				columnNum = 0;
				rowNum++;
			}
			float x2 = (float)columnNum * buttonsWidth;
			float y2 = (float)rowNum * lineHeight;
			columnNum++;
			string buttonText = (valueLabelPrefix + name3).Translate();
			T enumValue = (T)Enum.Parse(value.GetType(), name3);
			object obj = enumValue;
			GUI.color = (value.Equals(obj) ? SelectedButtonColor : Color.white);
			Rect buttonRect = new Rect(buttonsRect.x + x2, buttonsRect.y + y2, buttonsWidth, lineHeight);
			if (valueTooltipPostfix != null)
			{
				TooltipHandler.TipRegion(buttonRect, (valueLabelPrefix + name3 + valueTooltipPostfix).Translate());
			}
			if (Widgets.ButtonText(buttonRect, buttonText))
			{
				object obj2 = enumValue;
				if (!value.Equals(obj2))
				{
					value = enumValue;
					onChange?.Invoke();
				}
			}
		}
		listing.Gap(listing.verticalSpacing);
		GUI.color = Color.white;
	}

	public static void CurveEditor(this Listing_Standard instance, ref SimpleCurve curve)
	{
		Rect rect = instance.GetRect(100f);
		Widgets.DrawBoxSolid(rect, Color.black);
		Rect innerRect = rect.ContractedBy(2f);
		Widgets.ButtonInvisibleDraggable(innerRect);
	}

	public static Listing_Standard BeginHiddenSection(this Listing_Standard instance, out float maxHeightAccumulator)
	{
		Rect rect = instance.GetRect(0f);
		rect.height = 10000f;
		Listing_Standard listing_Standard = new Listing_Standard();
		listing_Standard.Begin(rect);
		maxHeightAccumulator = 0f;
		return listing_Standard;
	}

	public static void NewHiddenColumn(this Listing_Standard instance, ref float maxHeightAccumulator)
	{
		if (maxHeightAccumulator < instance.CurHeight)
		{
			maxHeightAccumulator = instance.CurHeight;
		}
		instance.NewColumn();
	}

	public static void EndHiddenSection(this Listing_Standard instance, Listing_Standard section, float maxHeightAccumulator)
	{
		instance.GetRect(Mathf.Max(section.CurHeight, maxHeightAccumulator));
		section.End();
	}
}
