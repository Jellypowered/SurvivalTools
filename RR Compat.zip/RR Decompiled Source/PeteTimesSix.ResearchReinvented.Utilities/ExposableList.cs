using System.Collections.Generic;
using System.Linq;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Utilities;

public class ExposableList<T> : List<ExposableListItem<T>>, IExposable where T : IExposable
{
	public string Name { get; set; }

	public ExposableList()
		: base(1)
	{
	}

	public ExposableList(IEnumerable<T> exposables)
		: base(exposables.Select((T exp) => new ExposableListItem<T>(exp)))
	{
	}

	public void ExposeData()
	{
		string name = Name;
		Scribe_Values.Look(ref name, "name");
		Name = name;
		List<ExposableListItem<T>> list = this.ListFullCopy();
		Scribe_Collections.Look(ref list, "internalList", LookMode.Undefined);
		Clear();
		AddRange(list.Where((ExposableListItem<T> exp) => exp.resolvable));
	}

	internal void Add(T item)
	{
		base.Add(new ExposableListItem<T>(item));
	}
}
