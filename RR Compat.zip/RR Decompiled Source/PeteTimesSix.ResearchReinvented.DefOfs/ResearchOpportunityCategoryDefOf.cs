using PeteTimesSix.ResearchReinvented.Defs;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.DefOfs;

[DefOf]
public static class ResearchOpportunityCategoryDefOf
{
	public static ResearchOpportunityCategoryDef Prototyping;

	static ResearchOpportunityCategoryDefOf()
	{
		DefOfHelper.EnsureInitializedInCtor(typeof(ResearchOpportunityCategoryDefOf));
	}
}
