using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.DefOfs;

[DefOf]
public static class ApparelLayerDefOf_Custom
{
	public static ApparelLayerDef Satchel;

	static ApparelLayerDefOf_Custom()
	{
		DefOfHelper.EnsureInitializedInCtor(typeof(ApparelLayerDefOf_Custom));
	}
}
