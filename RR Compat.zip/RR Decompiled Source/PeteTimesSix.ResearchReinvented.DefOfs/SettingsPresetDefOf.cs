using PeteTimesSix.ResearchReinvented.Defs;
using RimWorld;

namespace PeteTimesSix.ResearchReinvented.DefOfs;

[DefOf]
public static class SettingsPresetDefOf
{
	public static SettingsPresetDef SettingsPreset_RR_Default;

	static SettingsPresetDefOf()
	{
		DefOfHelper.EnsureInitializedInCtor(typeof(SettingsPresetDefOf));
	}
}
