using RimWorld;

namespace PeteTimesSix.ResearchReinvented.DefOfs;

[DefOf]
public static class PrisonerInteractionModeDefOf_Custom
{
	public static PrisonerInteractionModeDef RR_ScienceInterrogation;

	static PrisonerInteractionModeDefOf_Custom()
	{
		DefOfHelper.EnsureInitializedInCtor(typeof(PrisonerInteractionModeDefOf_Custom));
	}
}
