using RimWorld;

namespace PeteTimesSix.ResearchReinvented.DefOfs;

[DefOf]
public static class ThingDefOf_Custom
{
	static ThingDefOf_Custom()
	{
		DefOfHelper.EnsureInitializedInCtor(typeof(ThingDefOf_Custom));
	}
}
