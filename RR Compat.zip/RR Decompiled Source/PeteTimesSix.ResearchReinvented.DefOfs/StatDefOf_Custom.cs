using RimWorld;

namespace PeteTimesSix.ResearchReinvented.DefOfs;

[DefOf]
public static class StatDefOf_Custom
{
	public static StatDef FieldResearchSpeedMultiplier;

	static StatDefOf_Custom()
	{
		DefOfHelper.EnsureInitializedInCtor(typeof(StatDefOf_Custom));
	}
}
