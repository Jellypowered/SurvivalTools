using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.DefOfs;

[DefOf]
public static class EffecterDefOf_Custom
{
	public static EffecterDef RR_NoResearchKitEffect;

	public static EffecterDef RR_LessonOverRadio;

	static EffecterDefOf_Custom()
	{
		DefOfHelper.EnsureInitializedInCtor(typeof(EffecterDefOf_Custom));
	}
}
