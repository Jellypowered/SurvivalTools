using System;
using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Data;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.InteractionWorkers;

public class InteractionWorker_LearnScienceFromPrisoner : InteractionWorker
{
	public SimpleCurve moodCurve = new SimpleCurve
	{
		Points = 
		{
			new CurvePoint(0f, 0f),
			new CurvePoint(0.1f, 0f),
			new CurvePoint(0.75f, 1f),
			new CurvePoint(1f, 1f)
		}
	};

	public float BaseResearchAmount => 10f;

	public override void Interacted(Pawn initiator, Pawn recipient, List<RulePackDef> extraSentencePacks, out string letterText, out string letterLabel, out LetterDef letterDef, out LookTargets lookTargets)
	{
		letterText = null;
		letterLabel = null;
		letterDef = null;
		lookTargets = null;
		ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Social, recipient);
		if (opportunity != null)
		{
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"pawn {initiator.LabelCap} learned science from prisoner {recipient.LabelCap} and there's an opportunity {opportunity.ShortDesc}");
			}
			float amount = BaseResearchAmounts.InteractionLearnFromPrisoner;
			float modifier = initiator.GetStatValue(StatDefOf.NegotiationAbility) * Math.Max(initiator.GetStatValue(StatDefOf.ResearchSpeed), StatDefOf.ResearchSpeed.Worker.IsDisabledFor(recipient) ? 0f : recipient.GetStatValue(StatDefOf.ResearchSpeed));
			if (recipient.needs?.mood != null)
			{
				float moodPercent = recipient.needs.mood.CurLevelPercentage;
				float moodModifier = moodCurve.Evaluate(moodPercent);
				modifier *= moodModifier;
			}
			int xp = 0;
			opportunity.ResearchChunkPerformed(initiator, HandlingMode.Social, amount, modifier, xp, recipient.Faction?.Name);
		}
	}
}
