using System;
using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Data;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.InteractionWorkers;

public class InteractionWorker_Brainstorm : InteractionWorker
{
	public override float RandomSelectionWeight(Pawn initiator, Pawn recipient)
	{
		if (!recipient.CanNowDoResearch(checkFaction: false) || !initiator.CanNowDoResearch(checkFaction: false) || (recipient.Faction != Faction.OfPlayer && initiator.Faction != Faction.OfPlayer))
		{
			return 0f;
		}
		return 0.25f;
	}

	public override void Interacted(Pawn initiator, Pawn recipient, List<RulePackDef> extraSentencePacks, out string letterText, out string letterLabel, out LetterDef letterDef, out LookTargets lookTargets)
	{
		letterText = null;
		letterLabel = null;
		letterDef = null;
		lookTargets = null;
		ResearchOpportunity opportunity = null;
		if (opportunity == null && recipient.HasExtraHomeFaction())
		{
			opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Social, recipient);
		}
		if (opportunity == null && initiator.HasExtraHomeFaction())
		{
			opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Social, initiator);
		}
		if (opportunity == null)
		{
			opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Social, recipient);
		}
		if (opportunity != null)
		{
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"pawn {initiator.LabelCap} brainstormed with {recipient.LabelCap} and there's an opportunity {opportunity.ShortDesc}");
			}
			float amount = BaseResearchAmounts.InteractionBrainstorm;
			float modifier = Math.Max(initiator.GetStatValue(StatDefOf.ResearchSpeed), recipient.GetStatValue(StatDefOf.ResearchSpeed));
			int xp = 0;
			opportunity.ResearchChunkPerformed(initiator, HandlingMode.Social, amount, modifier, xp);
		}
	}
}
