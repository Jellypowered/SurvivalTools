using System;
using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Defs;

public class SpecialResearchOpportunityDef : Def
{
	public ResearchProjectDef project;

	public ResearchOpportunityTypeDef opportunityType;

	public ResearchRelation? relationOverride;

	public AlternatesMode altsMode;

	public bool forDirect = true;

	public bool forAncestor;

	public bool forDescendant;

	public List<ThingDef> things;

	public List<TerrainDef> terrains;

	public List<RecipeDef> recipes;

	public float importanceMultiplier = 1f;

	public bool rare;

	public bool freebie = true;

	public bool IsForRelation(ResearchRelation relation)
	{
		return relation switch
		{
			ResearchRelation.Ancestor => forAncestor, 
			ResearchRelation.Direct => forDirect, 
			ResearchRelation.Descendant => forDescendant, 
			_ => throw new ArgumentException("Invalid relation"), 
		};
	}
}
