using System.Collections.Generic;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Defs;

public class RaresListDef : Def
{
	public List<ThingDef> things;

	public List<TerrainDef> terrains;
}
