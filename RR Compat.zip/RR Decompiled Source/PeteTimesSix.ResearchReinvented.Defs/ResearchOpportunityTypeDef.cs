using System;
using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Opportunities;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Defs;

public class ResearchOpportunityTypeDef : Def
{
	public HandlingMode handledBy;

	public Type jobPickerClass;

	public JobDef jobDef;

	public string header_Direct;

	public string header_Ancestor;

	public string header_Descendant;

	[Unsaved(false)]
	protected TaggedString cachedHeader_DirectCap = null;

	[Unsaved(false)]
	protected TaggedString cachedHeader_AncestorCap = null;

	[Unsaved(false)]
	protected TaggedString cachedHeader_DescendantCap = null;

	public string shortDesc_Direct;

	public string shortDesc_Ancestor;

	public string shortDesc_Descendant;

	[Unsaved(false)]
	protected TaggedString cachedShortDesc_DirectCap = null;

	[Unsaved(false)]
	protected TaggedString cachedShortDesc_AncestorCap = null;

	[Unsaved(false)]
	protected TaggedString cachedShortDesc_DescendantCap = null;

	public ResearchOpportunityCategoryDef category_Direct;

	public ResearchOpportunityCategoryDef category_Ancestor;

	public ResearchOpportunityCategoryDef category_Descendant;

	public List<string> hintIcons;

	private List<Texture2D> _icons;

	public bool generatesPopups;

	public List<Texture2D> Icons
	{
		get
		{
			if (_icons == null)
			{
				_icons = new List<Texture2D>();
				if (hintIcons != null)
				{
					foreach (string path in hintIcons)
					{
						_icons.Add(ContentFinder<Texture2D>.Get(path));
					}
				}
			}
			return _icons;
		}
	}

	public TaggedString Header_DirectCap
	{
		get
		{
			if (header_Direct.NullOrEmpty())
			{
				return null;
			}
			if (cachedHeader_DirectCap.NullOrEmpty())
			{
				cachedHeader_DirectCap = header_Direct.CapitalizeFirst();
			}
			return cachedHeader_DirectCap;
		}
	}

	public TaggedString Header_AncestorCap
	{
		get
		{
			if (header_Ancestor.NullOrEmpty())
			{
				return null;
			}
			if (cachedHeader_AncestorCap.NullOrEmpty())
			{
				cachedHeader_AncestorCap = header_Ancestor.CapitalizeFirst();
			}
			return cachedHeader_AncestorCap;
		}
	}

	public TaggedString Header_DescendantCap
	{
		get
		{
			if (header_Descendant.NullOrEmpty())
			{
				return null;
			}
			if (cachedHeader_DescendantCap.NullOrEmpty())
			{
				cachedHeader_DescendantCap = header_Descendant.CapitalizeFirst();
			}
			return cachedHeader_DescendantCap;
		}
	}

	public TaggedString ShortDesc_DirectCap
	{
		get
		{
			if (shortDesc_Direct.NullOrEmpty())
			{
				return null;
			}
			if (cachedShortDesc_DirectCap.NullOrEmpty())
			{
				cachedShortDesc_DirectCap = shortDesc_Direct.CapitalizeFirst();
			}
			return cachedShortDesc_DirectCap;
		}
	}

	public TaggedString ShortDesc_AncestorCap
	{
		get
		{
			if (shortDesc_Ancestor.NullOrEmpty())
			{
				return null;
			}
			if (cachedShortDesc_AncestorCap.NullOrEmpty())
			{
				cachedShortDesc_AncestorCap = shortDesc_Ancestor.CapitalizeFirst();
			}
			return cachedShortDesc_AncestorCap;
		}
	}

	public TaggedString ShortDesc_DescendantCap
	{
		get
		{
			if (shortDesc_Descendant.NullOrEmpty())
			{
				return null;
			}
			if (cachedShortDesc_DescendantCap.NullOrEmpty())
			{
				cachedShortDesc_DescendantCap = shortDesc_Descendant.CapitalizeFirst();
			}
			return cachedShortDesc_DescendantCap;
		}
	}

	public bool UsesChunkedResearch
	{
		get
		{
			if (!handledBy.HasFlag(HandlingMode.Special_OnIngest))
			{
				return handledBy.HasFlag(HandlingMode.Special_Prototype);
			}
			return true;
		}
	}

	public ResearchOpportunityCategoryDef GetCategory(ResearchRelation relation)
	{
		switch (relation)
		{
		case ResearchRelation.Ancestor:
			if (category_Ancestor == null)
			{
				return category_Direct;
			}
			return category_Ancestor;
		case ResearchRelation.Descendant:
			if (category_Descendant == null)
			{
				return category_Direct;
			}
			return category_Descendant;
		default:
			return category_Direct;
		}
	}

	public IEnumerable<ResearchOpportunityCategoryDef> GetAllCategories()
	{
		HashSet<ResearchOpportunityCategoryDef> categories = new HashSet<ResearchOpportunityCategoryDef>();
		if (category_Direct != null)
		{
			categories.Add(category_Direct);
		}
		if (category_Ancestor != null)
		{
			categories.Add(category_Ancestor);
		}
		if (category_Descendant != null)
		{
			categories.Add(category_Descendant);
		}
		return categories;
	}

	public TaggedString GetHeaderCap(ResearchRelation relation)
	{
		switch (relation)
		{
		case ResearchRelation.Ancestor:
			if ((string)Header_AncestorCap == null)
			{
				return Header_DirectCap;
			}
			return Header_AncestorCap;
		case ResearchRelation.Descendant:
			if ((string)Header_DescendantCap == null)
			{
				return Header_DirectCap;
			}
			return Header_DescendantCap;
		default:
			return Header_DirectCap;
		}
	}

	public TaggedString GetShortDescCap(ResearchRelation relation)
	{
		switch (relation)
		{
		case ResearchRelation.Ancestor:
			if ((string)ShortDesc_AncestorCap == null)
			{
				return ShortDesc_DirectCap;
			}
			return ShortDesc_AncestorCap;
		case ResearchRelation.Descendant:
			if ((string)ShortDesc_DescendantCap == null)
			{
				return ShortDesc_DirectCap;
			}
			return ShortDesc_DescendantCap;
		default:
			return ShortDesc_DirectCap;
		}
	}
}
