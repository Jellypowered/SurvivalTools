using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Data;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Defs;

public class SettingsPresetDef : Def
{
	public int priority;

	public List<CategorySettingsPreset> categorySettingPresets = new List<CategorySettingsPreset>();

	public CategorySettingsPreset GetCategoryPreset(ResearchOpportunityCategoryDef category)
	{
		CategorySettingsPreset preset = categorySettingPresets.FirstOrDefault((CategorySettingsPreset cs) => cs.category == category);
		if (preset == null)
		{
			Log.Warning("Did not find preset category values for category " + category.defName + " in preset " + defName);
			preset = new CategorySettingsPreset
			{
				category = category
			};
			categorySettingPresets.Add(preset);
		}
		return preset;
	}
}
