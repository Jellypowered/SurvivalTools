using System;

namespace PeteTimesSix.ResearchReinvented.Defs;

[Flags]
public enum HandlingMode
{
	Job_Theory = 1,
	Job_Analysis = 2,
	Social = 4,
	Special_OnIngest = 8,
	Special_OnIngest_Observable = 0x10,
	Special_Medicine = 0x20,
	Special_Prototype = 0x40,
	Special_Tooling = 0x80,
	Special_Books = 0x100
}
