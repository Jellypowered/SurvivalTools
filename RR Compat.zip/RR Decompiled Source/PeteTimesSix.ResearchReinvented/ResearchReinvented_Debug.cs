namespace PeteTimesSix.ResearchReinvented;

public static class ResearchReinvented_Debug
{
	public static bool debugPrintouts;

	public static bool drawPrototypeGrid;
}
