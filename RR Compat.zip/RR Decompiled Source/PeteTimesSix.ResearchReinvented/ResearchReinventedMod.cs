using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.ModCompat;
using PeteTimesSix.ResearchReinvented.Rimworld.UI.Dialogs;
using PeteTimesSix.ResearchReinvented.Utilities;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented;

public class ResearchReinventedMod : Mod
{
	public static ResearchReinventedMod ModSingleton { get; private set; }

	public static ResearchReinvented_Settings Settings { get; internal set; }

	public static Harmony Harmony { get; internal set; }

	public ResearchReinventedMod(ModContentPack content)
		: base(content)
	{
		ModSingleton = this;
		Harmony = new Harmony("PeteTimesSix.ResearchReinvented");
		Harmony.PatchAll();
		OptionalPatches.Patch(Harmony);
	}

	public override string SettingsCategory()
	{
		return "ResearchReinvented_ModTitle".Translate();
	}

	public override void DoSettingsWindowContents(Rect inRect)
	{
		Settings.DoSettingsWindowContents(inRect);
	}

	public override void WriteSettings()
	{
		base.WriteSettings();
		Settings.changeTicker++;
		if (Current.ProgramState == ProgramState.Playing)
		{
			FixupDialog();
		}
	}

	public void FixupDialog()
	{
		Dialog_FixupSettingsChange fixupDialog = new Dialog_FixupSettingsChange("RR_setting_fixupConfirm".Translate(), delegate
		{
			ResearchOpportunityManager.Instance.ResetAllProgress();
			CacheClearer.ClearCaches();
			ResearchOpportunityManager.Instance.DelayedRegeneration();
			ResearchOpportunityManager.Instance.changeTicker = Settings.changeTicker;
		});
		Find.WindowStack.Add(fixupDialog);
	}
}
