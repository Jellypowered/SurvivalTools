using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.ModCompat;
using PeteTimesSix.ResearchReinvented.Rimworld.Comps;
using PeteTimesSix.ResearchReinvented.Rimworld.Comps.CompProperties;
using PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;
using Verse;

namespace PeteTimesSix.ResearchReinvented;

[StaticConstructorOnStartup]
public static class ResearchReinvented_PostInit
{
	static ResearchReinvented_PostInit()
	{
		ResearchReinventedMod.Settings = ResearchReinventedMod.ModSingleton.GetSettings<ResearchReinvented_Settings>();
		OptionalPatches.PatchDelayed(ResearchReinventedMod.Harmony);
		AddRarityModExtensions();
		AssociateKitsWithResearchProjects();
		AlternatesKeeper.PrepareAlternates();
	}

	private static void AssociateKitsWithResearchProjects()
	{
		IEnumerable<ThingDef> researchKits = DefDatabase<ThingDef>.AllDefsListForReading.Where((ThingDef d) => d.HasComp(typeof(Comp_ResearchKit)));
		foreach (ThingDef kit in researchKits)
		{
			CompProperties_ResearchKit kitComp = kit.GetCompProperties<CompProperties_ResearchKit>();
			HashSet<ResearchProjectDef> prerequisites = new HashSet<ResearchProjectDef>();
			if (kitComp.substitutedResearchBench.researchPrerequisites != null)
			{
				prerequisites.AddRange(kitComp.substitutedResearchBench.researchPrerequisites);
			}
			if (kitComp.remotesThrough != null && kitComp.remotesThrough.researchPrerequisites != null)
			{
				prerequisites.AddRange(kitComp.remotesThrough.researchPrerequisites);
			}
			if (kitComp.substitutedFacilities != null)
			{
				foreach (ThingDef facility in kitComp.substitutedFacilities)
				{
					if (facility.researchPrerequisites != null)
					{
						prerequisites.AddRange(facility.researchPrerequisites);
					}
				}
			}
			if (!prerequisites.Any())
			{
				continue;
			}
			if (kit.researchPrerequisites == null)
			{
				kit.researchPrerequisites = new List<ResearchProjectDef>();
			}
			kit.researchPrerequisites.AddRange(prerequisites);
			if (kit.recipeMaker != null)
			{
				if (kit.recipeMaker.researchPrerequisites == null)
				{
					kit.recipeMaker.researchPrerequisites = new List<ResearchProjectDef>();
				}
				kit.recipeMaker.researchPrerequisites.AddRange(prerequisites);
			}
			foreach (RecipeDef recipe in DefDatabase<RecipeDef>.AllDefsListForReading.Where((RecipeDef r) => r.ProducedThingDef == kit))
			{
				if (recipe.researchPrerequisites == null)
				{
					recipe.researchPrerequisites = new List<ResearchProjectDef>();
				}
				recipe.researchPrerequisites.AddRange(prerequisites);
			}
		}
	}

	private static void AddRarityModExtensions()
	{
		foreach (RaresListDef raresList in DefDatabase<RaresListDef>.AllDefsListForReading)
		{
			if (raresList.things == null)
			{
				continue;
			}
			foreach (ThingDef thing in raresList.things)
			{
				MarkAsRare(thing);
			}
		}
	}

	private static void MarkAsRare(Def def)
	{
		if (def.modExtensions == null)
		{
			def.modExtensions = new List<DefModExtension>();
		}
		if (!def.HasModExtension<RarityMarker>())
		{
			def.modExtensions.Add(new RarityMarker());
		}
	}
}
