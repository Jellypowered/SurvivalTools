namespace PeteTimesSix.ResearchReinvented;

public enum SettingTab
{
	GLOBAL_CONFIG,
	CATEGORY_PRESETS,
	CATEGORY_CONFIG,
	MOD_INTEGRATIONS
}
