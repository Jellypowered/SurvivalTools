using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Data;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.ModCompat;
using PeteTimesSix.ResearchReinvented.Utilities;
using PeteTimesSix.ResearchReinvented.Utilities.CustomWidgets;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented;

public class ResearchReinvented_Settings : ModSettings
{
	public const float HEADER_HEIGHT = 35f;

	public const float HEADER_GAP_HEIGHT = 10f;

	public int changeTicker;

	public SettingsPresetDef activePreset;

	public bool defaultCompactMode;

	public bool showProgressMotes = true;

	public bool kitlessResearch;

	public bool kitlessNeolithicResearch = true;

	public bool disablePrototypeBillCancellation = true;

	public bool enableScienceInterrogationByDefault = true;

	public List<CategorySettingsChanges> categorySettingChanges = new List<CategorySettingsChanges>();

	public List<CategorySettingsFinal> categorySettings = new List<CategorySettingsFinal>();

	public SettingTab temp_activeTab = SettingTab.CATEGORY_PRESETS;

	public ResearchOpportunityCategoryDef temp_selectedCategory;

	public ResearchData.ResearchDataCompatMode researchDataCompatMode = ResearchData.ResearchDataCompatMode.AllBenchResearch;

	private static Color LightGreen = new Color(0.7f, 1f, 0.7f);

	private static Color LightYellow = new Color(1f, 0.85f, 0.7f);

	public override void ExposeData()
	{
		base.ExposeData();
		Scribe_Values.Look(ref changeTicker, "changeTicker", 0);
		Scribe_Defs.Look(ref activePreset, "activePreset");
		Scribe_Values.Look(ref defaultCompactMode, "defaultCompactMode", defaultValue: false);
		Scribe_Values.Look(ref showProgressMotes, "showProgressMotes", defaultValue: true);
		Scribe_Values.Look(ref kitlessResearch, "kitlessResearch", defaultValue: false);
		Scribe_Values.Look(ref kitlessNeolithicResearch, "kitlessNeolithicResearch", defaultValue: true);
		Scribe_Values.Look(ref disablePrototypeBillCancellation, "disablePrototypeBillCancellation", defaultValue: true);
		Scribe_Values.Look(ref enableScienceInterrogationByDefault, "enableScienceInterrogationByDefault", defaultValue: true);
		Scribe_Collections.Look(ref categorySettingChanges, "categorySettingChanges", LookMode.Deep);
		Scribe_Values.Look(ref researchDataCompatMode, "researchDataCompatMode", ResearchData.ResearchDataCompatMode.AllBenchResearch);
	}

	public void DoSettingsWindowContents(Rect inRect)
	{
		Color preColor = GUI.color;
		TextAnchor anchor = Text.Anchor;
		Rect headerRect = inRect.TopPartPixels(35f);
		Rect restOfRect = inRect.BottomPartPixels(inRect.height - 45f);
		Listing_Standard listingStandard = new Listing_Standard();
		listingStandard.Begin(headerRect);
		listingStandard.EnumSelector(null, ref temp_activeTab, "RR_setting_tab_", "_tooltip", null, null, 35f);
		listingStandard.End();
		switch (temp_activeTab)
		{
		case SettingTab.GLOBAL_CONFIG:
			DoGlobalConfigTab(restOfRect);
			break;
		case SettingTab.CATEGORY_PRESETS:
			DoPresetTab(restOfRect);
			break;
		case SettingTab.CATEGORY_CONFIG:
			DoCategoriesConfigTab(restOfRect);
			break;
		case SettingTab.MOD_INTEGRATIONS:
			DoModIntegrationTab(restOfRect);
			break;
		}
		Text.Anchor = anchor;
		GUI.color = preColor;
	}

	private void DoGlobalConfigTab(Rect inRect)
	{
		Listing_Standard listingStandard = new Listing_Standard();
		listingStandard.Begin(inRect);
		float maxWidth = listingStandard.ColumnWidth;
		listingStandard.Indent(maxWidth / 4f);
		listingStandard.ColumnWidth = maxWidth / 2f;
		listingStandard.CheckboxLabeled("RR_setting_defaultCompactMode".Translate(), ref defaultCompactMode, "RR_setting_defaultCompactMode_tooltip".Translate());
		listingStandard.CheckboxLabeled("RR_setting_showProgressMotes".Translate(), ref showProgressMotes, "RR_setting_defaultCompactMode_showProgressMotes_tooltip".Translate());
		listingStandard.CheckboxLabeled("RR_setting_kitlessResearch".Translate(), ref kitlessResearch, "RR_setting_kitlessResearch_tooltip".Translate());
		listingStandard.CheckboxLabeled("RR_setting_kitlessNeolithicResearch".Translate(), ref kitlessNeolithicResearch, "RR_setting_kitlessNeolithicResearch_tooltip".Translate());
		listingStandard.CheckboxLabeled("RR_setting_disablePrototypeBillCancellation".Translate(), ref disablePrototypeBillCancellation, "RR_setting_disablePrototypeBillCancellation_tooltip".Translate());
		listingStandard.CheckboxLabeled("RR_setting_enableScienceInterrogationByDefault".Translate(), ref enableScienceInterrogationByDefault, "RR_setting_enableScienceInterrogationByDefault_tooltip".Translate());
		float remainingHeight = inRect.height - listingStandard.CurHeight;
		listingStandard.Gap(remainingHeight - Text.LineHeight * 1.5f);
		listingStandard.End();
	}

	private void DoPresetTab(Rect inRect)
	{
		Listing_Standard listingStandard = new Listing_Standard();
		listingStandard.Begin(inRect);
		Text.Anchor = TextAnchor.MiddleCenter;
		GUI.color = Color.yellow;
		listingStandard.Label("RR_setting_changeWarning".Translate());
		Text.Anchor = TextAnchor.UpperLeft;
		GUI.color = Color.white;
		float remainingHeight = inRect.height - listingStandard.CurHeight;
		float maxHeightAccumulator;
		Listing_Standard sectionListing = listingStandard.BeginHiddenSection(out maxHeightAccumulator);
		float sectionMaxWidth = listingStandard.ColumnWidth;
		sectionListing.ColumnWidth = (sectionMaxWidth - ListingExtensions.ColumnGap) / 2f;
		Rect visualizerRect = sectionListing.GetRect(remainingHeight);
		CategoriesVisualizer.DrawCategories(visualizerRect);
		sectionListing.NewHiddenColumn(ref maxHeightAccumulator);
		sectionListing.Gap();
		Text.Anchor = TextAnchor.MiddleCenter;
		sectionListing.Label(activePreset.LabelCap);
		sectionListing.Gap();
		Text.Anchor = TextAnchor.MiddleLeft;
		sectionListing.Label(activePreset.description);
		sectionListing.GapLine();
		sectionListing.Gap();
		SettingsPresetDef hoveredPreset = null;
		foreach (SettingsPresetDef preset in DefDatabase<SettingsPresetDef>.AllDefsListForReading.OrderByDescending((SettingsPresetDef p) => p.priority))
		{
			float heightPre = sectionListing.CurHeight;
			if (sectionListing.RadioButton(preset.LabelCap, activePreset == preset))
			{
				activePreset = preset;
				foreach (ResearchOpportunityCategoryDef categoryDef in DefDatabase<ResearchOpportunityCategoryDef>.AllDefsListForReading)
				{
					categoryDef.ClearCachedData();
				}
				categorySettingChanges.Clear();
				categorySettings.Clear();
			}
			float heightPost = sectionListing.CurHeight;
			float height = heightPost - heightPre;
			Rect hoverRect = sectionListing.GetRect(0f);
			hoverRect.height = height;
			hoverRect.y -= height;
			if (Mouse.IsOver(hoverRect))
			{
				hoveredPreset = preset;
			}
		}
		if (hoveredPreset != null && hoveredPreset != activePreset)
		{
			sectionListing.Gap();
			sectionListing.GapLine();
			GUI.color = Color.gray;
			Text.Anchor = TextAnchor.MiddleCenter;
			sectionListing.Label(hoveredPreset.LabelCap);
			sectionListing.Gap();
			Text.Anchor = TextAnchor.MiddleLeft;
			sectionListing.Label(hoveredPreset.description);
			GUI.color = Color.white;
		}
		listingStandard.EndHiddenSection(sectionListing, visualizerRect.height);
		listingStandard.End();
	}

	private void DoCategoriesConfigTab(Rect inRect)
	{
		Listing_Standard listingStandard = new Listing_Standard();
		listingStandard.Begin(inRect);
		Text.Anchor = TextAnchor.MiddleCenter;
		GUI.color = Color.yellow;
		listingStandard.Label("RR_setting_changeWarning".Translate());
		Text.Anchor = TextAnchor.UpperLeft;
		GUI.color = Color.white;
		float remainingHeight = inRect.height - listingStandard.CurHeight;
		float maxHeightAccumulator;
		Listing_Standard sectionListing = listingStandard.BeginHiddenSection(out maxHeightAccumulator);
		float sectionMaxWidth = listingStandard.ColumnWidth;
		sectionListing.ColumnWidth = (sectionMaxWidth - ListingExtensions.ColumnGap) / 2f;
		Rect visualizerRect = sectionListing.GetRect(remainingHeight);
		CategoriesVisualizer.DrawCategories(visualizerRect);
		sectionListing.NewHiddenColumn(ref maxHeightAccumulator);
		if (sectionListing.ButtonText("RR_setting_category_selector".Translate()))
		{
			List<FloatMenuOption> options = new List<FloatMenuOption>();
			foreach (ResearchOpportunityCategoryDef category in DefDatabase<ResearchOpportunityCategoryDef>.AllDefsListForReading.OrderByDescending((ResearchOpportunityCategoryDef d) => d.priority))
			{
				options.Add(new FloatMenuOption(category.LabelCap, delegate
				{
					temp_selectedCategory = category;
				}));
			}
			Find.WindowStack.Add(new FloatMenu(options));
		}
		if (temp_selectedCategory != null)
		{
			sectionListing.Gap();
			Text.Anchor = TextAnchor.MiddleCenter;
			GUI.color = temp_selectedCategory.color;
			sectionListing.Label(temp_selectedCategory.LabelCap);
			Text.Anchor = TextAnchor.UpperLeft;
			GUI.color = Color.white;
			sectionListing.Gap();
			CategorySettingsFinal temp_categorySettings = temp_selectedCategory.Settings;
			CategorySettingsChanges temp_categoryChanges = GetCategorySettingsChanges(temp_selectedCategory);
			GUI.color = (temp_categoryChanges.enabled.HasValue ? Color.yellow : Color.white);
			sectionListing.CheckboxLabeled("RR_setting_category_enabled".Translate(), ref temp_categorySettings.enabled, "RR_setting_category_enabled_tooltip".Translate());
			if (temp_categorySettings.enabled)
			{
				GUI.color = (temp_categoryChanges.availableAtOverallProgress.HasValue ? Color.yellow : Color.white);
				sectionListing.FloatRangeLabeled("RR_setting_category_availableAtOverallProgress".Translate(), ref temp_categorySettings.availableAtOverallProgress, 0f, 1f, 0.01f, 100f, 0f, "%", "RR_setting_category_availableAtOverallProgress_tooltip".Translate());
				GUI.color = (temp_categoryChanges.importanceStatic.HasValue ? Color.yellow : Color.white);
				sectionListing.SliderLabeled("RR_setting_category_importanceStatic".Translate(), ref temp_categorySettings.importanceStatic, 0f, 1f, 0.01f, 100f, 0, "%", "RR_setting_category_importanceStatic_tooltip".Translate());
				float importanceMultiplierPreChange = temp_categorySettings.importanceMultiplier;
				GUI.color = (temp_categoryChanges.importanceMultiplier.HasValue ? Color.yellow : Color.white);
				sectionListing.SliderLabeled("RR_setting_category_importanceMultiplier".Translate(), ref temp_categorySettings.importanceMultiplier, 0f, 5f, 0.05f, 100f, 0, "%", "RR_setting_category_importanceMultiplier_tooltip".Translate());
				if (temp_categorySettings.importanceMultiplier != importanceMultiplierPreChange)
				{
					if ((double)temp_categorySettings.importanceMultiplier == 0.0)
					{
						temp_categorySettings.importanceMultiplierCounted = 0f;
					}
					else if ((double)importanceMultiplierPreChange == 0.0 || importanceMultiplierPreChange == temp_categorySettings.importanceMultiplierCounted)
					{
						temp_categorySettings.importanceMultiplierCounted = temp_categorySettings.importanceMultiplier;
					}
					else
					{
						float fraction = temp_categorySettings.importanceMultiplier / importanceMultiplierPreChange;
						Log.Message("fraction: " + fraction);
						temp_categorySettings.importanceMultiplierCounted *= fraction;
					}
				}
				GUI.color = (temp_categoryChanges.importanceMultiplierCounted.HasValue ? Color.yellow : Color.white);
				sectionListing.SliderLabeled("RR_setting_category_importanceMultiplierCounted".Translate(), ref temp_categorySettings.importanceMultiplierCounted, 0f, temp_categorySettings.importanceMultiplier, 0.01f, 100f, 0, "%", "RR_setting_category_importanceMultiplierCounted_tooltip".Translate());
				GUI.color = (temp_categoryChanges.targetIterations.HasValue ? Color.yellow : Color.white);
				sectionListing.SliderLabeled("RR_setting_category_targetIterations".Translate(), ref temp_categorySettings.targetIterations, 1f, 30f, 0.25f, 1f, 2, "", "RR_setting_category_targetIterations_tooltip".Translate());
				GUI.color = (temp_categoryChanges.infiniteOverflow.HasValue ? Color.yellow : Color.white);
				sectionListing.CheckboxLabeled("RR_setting_category_infiniteOverflow".Translate(), ref temp_categorySettings.infiniteOverflow, "RR_setting_category_infiniteOverflow_tooltip".Translate());
				GUI.color = (temp_categoryChanges.researchSpeedMultiplier.HasValue ? Color.yellow : Color.white);
				sectionListing.SliderLabeled("RR_setting_category_researchSpeedMultiplier".Translate(), ref temp_categorySettings.researchSpeedMultiplier, 0.05f, 5f, 0.05f, 100f, 0, "%", "RR_setting_category_researchSpeedMultiplier_tooltip".Translate());
			}
			temp_categoryChanges.UpdateChanges(GetActivePreset().GetCategoryPreset(temp_selectedCategory), temp_categorySettings);
			GUI.color = Color.white;
			if (sectionListing.ButtonText("RR_setting_category_resetToDefault".Translate()))
			{
				temp_selectedCategory.ClearCachedData();
				categorySettingChanges.Remove(temp_categoryChanges);
				categorySettings.Remove(temp_categorySettings);
			}
			sectionListing.Gap();
			sectionListing.Label(temp_categorySettings.category.description);
		}
		listingStandard.EndHiddenSection(sectionListing, visualizerRect.height);
		listingStandard.End();
	}

	public SettingsPresetDef GetActivePreset()
	{
		if (activePreset == null)
		{
			activePreset = SettingsPresetDefOf.SettingsPreset_RR_Default;
		}
		return activePreset;
	}

	public CategorySettingsChanges GetCategorySettingsChanges(ResearchOpportunityCategoryDef category)
	{
		if (categorySettingChanges == null)
		{
			categorySettingChanges = new List<CategorySettingsChanges>();
		}
		CategorySettingsChanges changes = categorySettingChanges.FirstOrDefault((CategorySettingsChanges cs) => cs.category == category);
		if (changes == null)
		{
			changes = new CategorySettingsChanges
			{
				category = category
			};
			categorySettingChanges.Add(changes);
		}
		return changes;
	}

	public CategorySettingsFinal GetCategorySettings(ResearchOpportunityCategoryDef category)
	{
		if (categorySettings == null)
		{
			categorySettings = new List<CategorySettingsFinal>();
		}
		CategorySettingsFinal settings = categorySettings.FirstOrDefault((CategorySettingsFinal cs) => cs.category == category);
		if (settings == null)
		{
			settings = new CategorySettingsFinal
			{
				category = category
			};
			settings.Update(GetActivePreset().GetCategoryPreset(category), GetCategorySettingsChanges(category));
			categorySettings.Add(settings);
		}
		return settings;
	}

	private void DoModIntegrationTab(Rect inRect)
	{
		Listing_Standard listingStandard = new Listing_Standard();
		listingStandard.Begin(inRect);
		float maxWidth = listingStandard.ColumnWidth;
		listingStandard.Indent(maxWidth / 4f);
		listingStandard.ColumnWidth = maxWidth / 2f;
		if (DubsMintMenus.active)
		{
			GUI.color = (DubsMintMenus.success ? LightGreen : LightYellow);
			string message = (DubsMintMenus.success ? "RR_setting_modCompat_active" : "RR_setting_modCompat_fail");
			listingStandard.Label(message.Translate("RR_setting_modCompat_dubsMintMenus".Translate()));
		}
		if (HumanoidAlienRaces.active)
		{
			GUI.color = (HumanoidAlienRaces.success ? LightGreen : LightYellow);
			string message2 = (HumanoidAlienRaces.success ? "RR_setting_modCompat_active" : "RR_setting_modCompat_fail");
			listingStandard.Label(message2.Translate("RR_setting_modCompat_humanoidAlienRaces".Translate()));
		}
		if (ResearchData.active)
		{
			GUI.color = (ResearchData.success ? LightGreen : LightYellow);
			string message3 = (ResearchData.success ? "RR_setting_modCompat_active" : "RR_setting_modCompat_fail");
			listingStandard.Label(message3.Translate("RR_setting_modCompat_researchData".Translate()));
			if (ResearchData.success)
			{
				listingStandard.EnumSelector("RR_setting_modCompat_researchData_mode".Translate(), ref researchDataCompatMode, "RR_modCompat_researchData_mode_");
			}
		}
		if (!DubsMintMenus.active)
		{
			GUI.color = Color.gray;
			listingStandard.Label("RR_setting_modCompat_notDetected".Translate("RR_setting_modCompat_dubsMintMenus".Translate()));
		}
		if (!HumanoidAlienRaces.active)
		{
			GUI.color = Color.gray;
			listingStandard.Label("RR_setting_modCompat_notDetected".Translate("RR_setting_modCompat_humanoidAlienRaces".Translate()));
		}
		if (!ResearchData.active)
		{
			GUI.color = Color.gray;
			listingStandard.Label("RR_setting_modCompat_notDetected".Translate("RR_setting_modCompat_researchData".Translate()));
		}
		listingStandard.End();
	}
}
