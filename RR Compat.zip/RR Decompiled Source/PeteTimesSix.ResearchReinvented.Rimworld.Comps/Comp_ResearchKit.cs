using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Rimworld.Comps.CompProperties;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.Comps;

public class Comp_ResearchKit : ThingComp
{
	public CompProperties_ResearchKit Props => (CompProperties_ResearchKit)props;

	public override IEnumerable<StatDrawEntry> SpecialDisplayStats()
	{
		if (Props.remotesThrough != null)
		{
			float remoteFactor = GetRemoteResearchSpeedFactor();
			string remoteFactorString = ((remoteFactor > 1f) ? remoteFactor.ToStringPercent() : "None");
			yield return new StatDrawEntry(StatCategoryDefOf.EquippedStatOffsets, "RR_UplinkResearchSpeedFactor".Translate(), remoteFactorString, "RR_UplinkResearchSpeedFactor_desc".Translate(), -1);
		}
	}

	public bool MeetsProjectRequirements(ResearchProjectDef project)
	{
		if (MeetsProjectRequirementsLocally(project))
		{
			return true;
		}
		if (MeetsProjectRequirementsRemotely(project))
		{
			return true;
		}
		return false;
	}

	public bool MeetsProjectRequirementsLocally(ResearchProjectDef project)
	{
		if (project.requiredResearchBuilding != null && Props.substitutedResearchBench != project.requiredResearchBuilding)
		{
			return false;
		}
		if (project.requiredResearchFacilities != null && project.requiredResearchFacilities.Any())
		{
			if (Props.substitutedFacilities == null)
			{
				return false;
			}
			foreach (ThingDef requiredFacility in project.requiredResearchFacilities)
			{
				if (!Props.substitutedFacilities.Contains(requiredFacility))
				{
					return false;
				}
			}
		}
		return true;
	}

	public bool MeetsProjectRequirementsRemotely(ResearchProjectDef project)
	{
		if (Props.remotesThrough == null)
		{
			return false;
		}
		List<Building_ResearchBench> remotableBenches = GetRemotableBenches(project);
		return remotableBenches.Any();
	}

	public float GetTotalResearchSpeedFactor(ResearchProjectDef project = null)
	{
		float localFactor = StatDefOf_Custom.FieldResearchSpeedMultiplier.defaultBaseValue + StatWorker.StatOffsetFromGear(parent, StatDefOf_Custom.FieldResearchSpeedMultiplier);
		if (Props.remotesThrough != null)
		{
			float remoteFactor = GetRemoteResearchSpeedFactor(project);
			if (remoteFactor > 1f)
			{
				localFactor *= remoteFactor;
			}
		}
		return localFactor;
	}

	public float GetRemoteResearchSpeedFactor(ResearchProjectDef project = null)
	{
		if (Props.remotesThrough == null)
		{
			return -1f;
		}
		float best = -1f;
		List<Building_ResearchBench> benchesToCheck = GetRemotableBenches(project);
		foreach (Building_ResearchBench researchBench in benchesToCheck)
		{
			float researchSpeedFactor = researchBench.GetStatValue(StatDefOf.ResearchSpeedFactor);
			if (researchSpeedFactor > best)
			{
				best = researchSpeedFactor;
			}
		}
		return best;
	}

	private List<Building_ResearchBench> GetRemotableBenches(ResearchProjectDef project = null)
	{
		Map map = parent.MapHeld;
		if (map == null)
		{
			return new List<Building_ResearchBench>();
		}
		List<Building> remoteBuildings = map.listerBuildings.AllBuildingsColonistOfDef(Props.remotesThrough).ToList();
		List<Building_ResearchBench> remotableBenches = new List<Building_ResearchBench>();
		foreach (Building building in remoteBuildings)
		{
			CompPowerTrader powerComp = building.TryGetComp<CompPowerTrader>();
			if (powerComp != null && !powerComp.PowerOn)
			{
				continue;
			}
			if (Props.remotesThrough.thingClass == typeof(Building_ResearchBench))
			{
				remotableBenches.AddRange(remoteBuildings.Cast<Building_ResearchBench>());
				continue;
			}
			CompFacility facility = building.TryGetComp<CompFacility>();
			if (facility == null)
			{
				continue;
			}
			foreach (Building_ResearchBench researchBench in facility.LinkedBuildings.Where((Thing t) => t is Building_ResearchBench).Cast<Building_ResearchBench>())
			{
				CompPowerTrader powerComp2 = researchBench.TryGetComp<CompPowerTrader>();
				if (powerComp2 == null || powerComp2.PowerOn)
				{
					remotableBenches.Add(researchBench);
				}
			}
		}
		if (project != null)
		{
			remotableBenches = remotableBenches.Where((Building_ResearchBench bench) => project.CanBeResearchedAt(bench, ignoreResearchBenchPowerStatus: false)).ToList();
		}
		return remotableBenches;
	}
}
