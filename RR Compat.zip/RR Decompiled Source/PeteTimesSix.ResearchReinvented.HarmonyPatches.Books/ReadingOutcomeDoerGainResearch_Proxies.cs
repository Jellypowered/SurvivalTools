using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Books;

public static class ReadingOutcomeDoerGainResearch_Proxies
{
	public delegate bool IsProjectVisibleDelegate(ReadingOutcomeDoerGainResearch comp, ResearchProjectDef project);

	public static AccessTools.FieldRef<ReadingOutcomeDoerGainResearch, Dictionary<ResearchProjectDef, float>> Values { get; set; }

	public static IsProjectVisibleDelegate IsProjectVisible { get; set; }

	static ReadingOutcomeDoerGainResearch_Proxies()
	{
		Values = AccessTools.FieldRefAccess<Dictionary<ResearchProjectDef, float>>(typeof(ReadingOutcomeDoerGainResearch), "values");
		IsProjectVisible = AccessTools.MethodDelegate<IsProjectVisibleDelegate>(AccessTools.Method(typeof(ReadingOutcomeDoerGainResearch), "IsProjectVisible"));
	}
}
