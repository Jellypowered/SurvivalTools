using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Books;

[HarmonyPatch(typeof(ReadingOutcomeDoerGainResearch), "OnReadingTick")]
public static class ReadingOutcomeDoerGainResearch_OnReadingTick_Patches
{
	[HarmonyPrefix]
	public static bool ReadingOutcomeDoerGainResearch_OnReadingTick_Prefix(ReadingOutcomeDoerGainResearch __instance, Pawn reader, float factor)
	{
		if (__instance is ReadingOutcomeDoerGainAnomalyResearch)
		{
			return true;
		}
		Dictionary<ResearchProjectDef, float> values = ReadingOutcomeDoerGainResearch_Proxies.Values(__instance);
		ResearchProjectDef researchProjectDef = default(ResearchProjectDef);
		float num = default(float);
		foreach (KeyValuePair<ResearchProjectDef, float> item in values)
		{
			item.Deconstruct(ref researchProjectDef, ref num);
			ResearchProjectDef project = researchProjectDef;
			float speed = num;
			if (ReadingOutcomeDoerGainResearch_Proxies.IsProjectVisible(__instance, project) && !project.IsFinished && !reader.WorkTypeIsDisabled(WorkTypeDefOf.Research))
			{
				ResearchOpportunityManager.Instance.GetOpportunitiesFilterForProjects(OpportunityAvailability.Available, HandlingMode.Special_Books, values.Keys, (ResearchOpportunity op) => op.requirement.MetBy(project)).FirstOrDefault()?.ResearchTickPerformed(speed * factor, reader);
			}
		}
		return false;
	}
}
