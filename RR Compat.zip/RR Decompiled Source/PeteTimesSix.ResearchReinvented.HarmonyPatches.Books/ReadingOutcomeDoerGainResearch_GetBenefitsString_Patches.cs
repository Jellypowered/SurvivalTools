using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using RimWorld;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Books;

[HarmonyPatch(typeof(ReadingOutcomeDoerGainResearch), "GetBenefitsString")]
public static class ReadingOutcomeDoerGainResearch_GetBenefitsString_Patches
{
	[HarmonyPrefix]
	public static bool ReadingOutcomeDoerGainResearch_GetBenefitsString_Prefix(ReadingOutcomeDoerGainResearch __instance, ref string __result, Pawn reader)
	{
		if (__instance is ReadingOutcomeDoerGainAnomalyResearch)
		{
			return true;
		}
		Dictionary<ResearchProjectDef, float> values = ReadingOutcomeDoerGainResearch_Proxies.Values(__instance);
		StringBuilder stringBuilder = new StringBuilder();
		ResearchProjectDef researchProjectDef = default(ResearchProjectDef);
		float num = default(float);
		foreach (KeyValuePair<ResearchProjectDef, float> item in values)
		{
			item.Deconstruct(ref researchProjectDef, ref num);
			ResearchProjectDef project = researchProjectDef;
			float speed = num;
			float amount = speed * 2500f;
			if (__instance.RoundTo != 0)
			{
				amount = Mathf.Round(amount / (float)__instance.RoundTo) * (float)__instance.RoundTo;
			}
			string text;
			if (project.IsFinished)
			{
				text = string.Format(string.Format(" - {0}: {1} ({2})", project.LabelCap, "PerHour".Translate(amount.ToStringDecimalIfSmall()), "AlreadyUnlocked".Translate()));
				text = text.Colorize(Color.gray);
			}
			else
			{
				ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetOpportunitiesFilterForProjects(OpportunityAvailability.Available, HandlingMode.Special_Books, values.Keys, (ResearchOpportunity op) => op.requirement.MetBy(project)).FirstOrDefault();
				if (opportunity == null)
				{
					text = string.Format(string.Format(" - {0}: {1} ({2})", project.LabelCap, "PerHour".Translate(amount.ToStringDecimalIfSmall()), "RR_CategoryFinishedBook".Translate()));
					text = text.Colorize(Color.gray);
				}
				else
				{
					amount *= opportunity.def.GetCategory(opportunity.relation).Settings.researchSpeedMultiplier;
					if (!ReadingOutcomeDoerGainResearch_Proxies.IsProjectVisible(__instance, project))
					{
						text = string.Format(string.Format(" - {0}: {1} ({2})", project.LabelCap, "PerHour".Translate(amount.ToStringDecimalIfSmall()), "WhenDiscovered".Translate()));
						text = text.Colorize(Color.gray);
					}
					else
					{
						text = string.Format(string.Format(" - {0}: {1}", project.LabelCap, "PerHour".Translate(amount.ToStringDecimalIfSmall())));
					}
				}
			}
			stringBuilder.AppendLine(text);
		}
		__result = stringBuilder.ToString();
		return false;
	}
}
