using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Books;

[HarmonyPatch(typeof(ReadingOutcomeDoerGainResearch), "DoesProvidesOutcome")]
public static class ReadingOutcomeDoerGainResearch_DoesProvidesOutcome_Patches
{
	[HarmonyPrefix]
	public static bool ReadingOutcomeDoerGainResearch_DoesProvidesOutcome_Prefix(ReadingOutcomeDoerGainResearch __instance, ref bool __result, Pawn reader)
	{
		if (__instance is ReadingOutcomeDoerGainAnomalyResearch)
		{
			return true;
		}
		Dictionary<ResearchProjectDef, float> values = ReadingOutcomeDoerGainResearch_Proxies.Values(__instance);
		ResearchProjectDef researchProjectDef = default(ResearchProjectDef);
		float num = default(float);
		foreach (KeyValuePair<ResearchProjectDef, float> item in values)
		{
			item.Deconstruct(ref researchProjectDef, ref num);
			ResearchProjectDef project = researchProjectDef;
			float speed = num;
			ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetOpportunitiesFilterForProjects(OpportunityAvailability.Available, HandlingMode.Special_Books, values.Keys, (ResearchOpportunity op) => op.requirement.MetBy(project)).FirstOrDefault();
			if (opportunity != null)
			{
				if (ResearchReinvented_Debug.debugPrintouts)
				{
					Log.Message($"pawn {reader.Label} wants to read book {__instance.Parent.Label} and there's opportunity {opportunity}");
				}
				__result = true;
				return false;
			}
		}
		__result = false;
		return false;
	}
}
