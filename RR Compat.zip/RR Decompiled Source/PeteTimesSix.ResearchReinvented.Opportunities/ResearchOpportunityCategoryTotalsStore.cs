using PeteTimesSix.ResearchReinvented.Defs;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Opportunities;

public class ResearchOpportunityCategoryTotalsStore : IExposable
{
	public float researchPoints;

	public ResearchProjectDef project;

	public ResearchOpportunityCategoryDef category;

	public void ExposeData()
	{
		Scribe_Values.Look(ref researchPoints, "allResearchPoints", 0f, forceSave: true);
		Scribe_Defs.Look(ref project, "project");
		Scribe_Defs.Look(ref category, "category");
	}
}
