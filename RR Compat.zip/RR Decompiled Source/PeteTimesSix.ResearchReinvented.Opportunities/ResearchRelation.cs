namespace PeteTimesSix.ResearchReinvented.Opportunities;

public enum ResearchRelation
{
	Direct,
	Ancestor,
	Descendant
}
