namespace PeteTimesSix.ResearchReinvented.Opportunities;

public static class ResearchOpportunityChecker
{
	public static bool IsValid(this ResearchOpportunity opportunity)
	{
		if (opportunity != null && opportunity.def != null && opportunity.project != null && opportunity.requirement != null)
		{
			return opportunity.requirement.IsValid;
		}
		return false;
	}
}
