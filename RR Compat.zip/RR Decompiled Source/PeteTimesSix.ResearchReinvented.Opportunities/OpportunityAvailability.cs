using System;

namespace PeteTimesSix.ResearchReinvented.Opportunities;

[Flags]
public enum OpportunityAvailability
{
	Available = 1,
	Disabled = 2,
	Finished = 4,
	ResearchTooLow = 8,
	ResearchTooHigh = 0x10,
	CategoryFinished = 0x20,
	ResearchPrerequisitesNotMet = 0x40,
	UnavailableReasonUnknown = 0x80
}
