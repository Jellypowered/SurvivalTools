using System;
using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using PeteTimesSix.ResearchReinvented.OpportunityJobPickers;
using PeteTimesSix.ResearchReinvented.Rimworld;
using RimWorld;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Opportunities;

public class ResearchOpportunity : IExposable, ILoadReferenceable
{
	public ResearchProjectDef project;

	public ResearchOpportunityTypeDef def;

	public ResearchOpportunityComp requirement;

	public string debug_source;

	private float maximumProgress;

	private float currentProgress;

	private bool isForcedRare;

	private bool isForcedFreebie;

	public ResearchRelation relation;

	public float importance;

	public int loadID = -1;

	private List<JobDef> _jobDefsCached;

	public float Progress => currentProgress;

	public float MaximumProgress
	{
		get
		{
			ResearchOpportunityCategoryDef category = def.GetCategory(relation);
			if (category.maxAsRemaining && category.Settings.infiniteOverflow)
			{
				return project.baseCost - project.ProgressReal + Progress;
			}
			return maximumProgress;
		}
	}

	public float ProgressFraction => Progress / MaximumProgress;

	public bool IsFinished => ProgressFraction >= 1f;

	public bool IsRare
	{
		get
		{
			if (!isForcedRare)
			{
				return requirement.IsRare;
			}
			return true;
		}
	}

	public bool IsFreebie
	{
		get
		{
			if (!isForcedFreebie)
			{
				return requirement.IsFreebie;
			}
			return true;
		}
	}

	public List<JobDef> JobDefs
	{
		get
		{
			if (_jobDefsCached == null)
			{
				_jobDefsCached = JobPickerMaker.MakePicker(def.jobPickerClass ?? typeof(JobPicker_FromOpportunityDef)).PickJobs(this);
			}
			return _jobDefsCached;
		}
	}

	public OpportunityAvailability CurrentAvailability
	{
		get
		{
			if (IsFinished)
			{
				return OpportunityAvailability.Finished;
			}
			return def.GetCategory(relation).GetCurrentAvailability(project);
		}
	}

	public TaggedString ShortDesc => $"[{project}] - [{def.GetCategory(relation).label}] - [{def.label}]: {requirement.ShortDesc} ({currentProgress} / {maximumProgress})";

	public TaggedString HintText
	{
		get
		{
			TaggedString text = def.GetShortDescCap(relation);
			TaggedString? taggedString = requirement?.Subject;
			string subject = (taggedString.HasValue ? ((string)taggedString.GetValueOrDefault()) : null);
			return text.Formatted(subject);
		}
	}

	public ResearchOpportunity()
	{
	}

	public ResearchOpportunity(ResearchProjectDef project, ResearchOpportunityTypeDef def, ResearchRelation relation, ResearchOpportunityComp requirement, string debug_source, float importance = 1f, bool forceRare = false, bool forceFreebie = false)
	{
		this.project = project;
		this.def = def;
		this.requirement = requirement;
		this.relation = relation;
		loadID = RR_UniqueIDsManager.instance.GetNextResearchOpportunityID();
		this.importance = importance;
		isForcedRare = forceRare;
		isForcedFreebie = forceFreebie;
		this.debug_source = debug_source;
	}

	public void SetMaxProgress(float maxProgress)
	{
		maximumProgress = maxProgress;
	}

	public void ExposeData()
	{
		Scribe_Defs.Look(ref project, "project");
		Scribe_Defs.Look(ref def, "def");
		Scribe_Deep.Look(ref requirement, "requirement");
		Scribe_Values.Look(ref maximumProgress, "maximumProgress", 0f);
		Scribe_Values.Look(ref currentProgress, "currentProgress", 0f);
		Scribe_Values.Look(ref loadID, "loadID", 0, forceSave: true);
		Scribe_Values.Look(ref relation, "relation", ResearchRelation.Direct);
		Scribe_Values.Look(ref importance, "importance", 0f);
		Scribe_Values.Look(ref isForcedRare, "isForcedRare", defaultValue: false);
	}

	private bool ResearchPerformed(float amount, Pawn researcher, float? moteAmount, string moteSubjectName = null, float moteOffsetHint = 0f)
	{
		amount *= Find.Storyteller.difficulty.researchSpeedFactor;
		amount *= def.GetCategory(relation).Settings.researchSpeedMultiplier;
		if (researcher != null && researcher.Faction != null)
		{
			amount /= project.CostFactor(researcher.Faction.def.techLevel);
		}
		if (DebugSettings.fastResearch)
		{
			amount *= 500f;
		}
		if (currentProgress + amount >= MaximumProgress)
		{
			amount = MaximumProgress - currentProgress;
		}
		if (moteAmount.HasValue && currentProgress + moteAmount >= MaximumProgress)
		{
			moteAmount = MaximumProgress - currentProgress;
		}
		currentProgress += amount;
		if (researcher != null)
		{
			researcher.records.AddTo(RecordDefOf.ResearchPointsResearched, amount);
			if (ResearchReinventedMod.Settings.showProgressMotes && moteAmount.HasValue)
			{
				DoResearchProgressMote(researcher, moteAmount.Value, moteSubjectName, moteOffsetHint);
			}
		}
		float total = Find.ResearchManager.GetProgress(project);
		total += amount;
		ResearchManagerAccess.Field_progress[project] = total;
		if (project.IsFinished)
		{
			ResearchOpportunityManager.Instance.FinishProject(project, doCompletionDialog: true, researcher);
		}
		if (!project.IsFinished)
		{
			return IsFinished;
		}
		return true;
	}

	public bool ResearchTickPerformed(float amount, Pawn researcher, int tickDelta = 1, int moteModulo = 600)
	{
		if (!researcher.WorkTypeIsDisabled(WorkTypeDefOf.Research))
		{
			researcher.skills.Learn(SkillDefOf.Intellectual, 0.1f * (float)tickDelta);
			float tickAmount = amount * (float)tickDelta;
			int? moteAmount = null;
			if (researcher.IsHashIntervalTick(moteModulo))
			{
				moteAmount = (int)(amount * (float)moteModulo);
			}
			return ResearchPerformed(tickAmount, researcher, moteAmount);
		}
		Log.Warning($"RR: Pawn {researcher} tried to do research tick despite being incapable of research");
		return false;
	}

	public bool ResearchChunkPerformed(Pawn researcher, HandlingMode mode, float amount, float modifier, float xp, string moteSubjectName = null, float moteOffsetHint = 0f)
	{
		float startAmount = amount;
		if (!researcher.WorkTypeIsDisabled(WorkTypeDefOf.Research))
		{
			researcher.skills.Learn(SkillDefOf.Intellectual, xp);
			amount *= modifier;
			amount = Math.Min(amount, MaximumProgress);
			if (ResearchReinvented_Debug.debugPrintouts)
			{
				Log.Message($"performing research chunk for {ShortDesc}: modifier: {modifier} startAmount: {startAmount} amount {amount} ({amount * def.GetCategory(relation).Settings.researchSpeedMultiplier} after speedmult) (of {MaximumProgress})");
			}
			return ResearchPerformed(amount, researcher, amount, moteSubjectName, moteOffsetHint);
		}
		Log.Warning($"RR: Pawn {researcher} tried to do research chunk despite being incapable of research");
		return false;
	}

	public void DoResearchProgressMote(Pawn pawn, float amount, string moteSubjectName = null, float moteOffsetHint = 0f)
	{
		Vector3 pos = pawn.DrawPos;
		pos.z += moteOffsetHint;
		MoteMaker.ThrowText(pos, pawn.Map, string.Format("{0} {1}: {2}", def.GetHeaderCap(relation), (moteSubjectName != null) ? ("(" + moteSubjectName + ")") : "", Math.Round(amount)), def.GetCategory(relation).color);
	}

	public override string ToString()
	{
		return ShortDesc;
	}

	public string GetUniqueLoadID()
	{
		return "ResearchOpportunity_" + loadID;
	}

	public void FinishImmediately()
	{
		ResearchPerformed(MaximumProgress, null, null);
	}
}
