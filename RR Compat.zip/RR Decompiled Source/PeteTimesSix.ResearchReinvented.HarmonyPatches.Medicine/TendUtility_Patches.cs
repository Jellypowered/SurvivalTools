using HarmonyLib;
using PeteTimesSix.ResearchReinvented.Data;
using PeteTimesSix.ResearchReinvented.Defs;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Medicine;

[HarmonyPatch(typeof(TendUtility), "DoTend")]
public static class TendUtility_Patches
{
	[HarmonyPrefix]
	public static void TendUtility_DoTend_Prefix(Pawn doctor, Pawn patient, RimWorld.Medicine medicine)
	{
		if (medicine != null)
		{
			DoForObserver(doctor, medicine.def, 0.5f);
			DoForObserver(patient, medicine.def);
		}
	}

	public static void DoForObserver(Pawn observer, ThingDef medicine, float offsetHint = 0f)
	{
		if (medicine != null && observer.CanNowDoResearch())
		{
			ResearchOpportunity opportunity = ResearchOpportunityManager.Instance.GetFirstFilteredOpportunity(OpportunityAvailability.Available, HandlingMode.Special_Medicine, medicine);
			if (opportunity != null)
			{
				float amount = BaseResearchAmounts.OnTendObserver;
				float modifier = observer.GetStatValue(StatDefOf.ResearchSpeed);
				float xp = ResearchXPAmounts.OnTendObserver;
				opportunity.ResearchChunkPerformed(observer, HandlingMode.Special_Medicine, amount, modifier, xp, medicine.LabelCap);
			}
		}
	}
}
