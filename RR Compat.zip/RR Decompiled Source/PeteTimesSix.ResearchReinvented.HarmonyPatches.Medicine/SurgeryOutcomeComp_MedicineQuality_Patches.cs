using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Medicine;

[HarmonyPatch(typeof(SurgeryOutcomeComp_MedicineQuality), "XGetter")]
public static class SurgeryOutcomeComp_MedicineQuality_Patches
{
	[HarmonyPrefix]
	public static void Recipe_Surgery_CheckSurgeryFail_Prefix(RecipeDef recipe, Pawn surgeon, Pawn patient, List<Thing> ingredients, BodyPartRecord part, Bill bill)
	{
		if (bill is Bill_Medical { consumedMedicine: not null } medicalBill)
		{
			{
				ThingDef thingDef = default(ThingDef);
				int num = default(int);
				foreach (KeyValuePair<ThingDef, int> item in medicalBill.consumedMedicine)
				{
					item.Deconstruct(ref thingDef, ref num);
					ThingDef medicine = thingDef;
					int count = num;
					if (count > 0)
					{
						TendUtility_Patches.DoForObserver(surgeon, medicine, 0.5f);
						TendUtility_Patches.DoForObserver(patient, medicine);
					}
				}
				return;
			}
		}
		foreach (Thing ingredient in ingredients)
		{
			if (ingredient.def.IsMedicine)
			{
				TendUtility_Patches.DoForObserver(surgeon, ingredient.def, 1f);
				TendUtility_Patches.DoForObserver(patient, ingredient.def);
				break;
			}
		}
	}
}
