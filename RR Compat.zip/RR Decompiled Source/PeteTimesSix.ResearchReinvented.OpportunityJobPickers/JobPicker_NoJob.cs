using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Opportunities;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityJobPickers;

public class JobPicker_NoJob : OpportunityJobPickerBase
{
	private static List<JobDef> emptyList = new List<JobDef>();

	public override List<JobDef> PickJobs(ResearchOpportunity opportunity)
	{
		return emptyList;
	}
}
