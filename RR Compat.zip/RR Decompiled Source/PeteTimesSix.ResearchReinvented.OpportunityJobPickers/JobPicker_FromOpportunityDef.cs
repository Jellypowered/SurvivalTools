using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Opportunities;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityJobPickers;

public class JobPicker_FromOpportunityDef : OpportunityJobPickerBase
{
	public override List<JobDef> PickJobs(ResearchOpportunity opportunity)
	{
		return new List<JobDef> { opportunity.def.jobDef };
	}
}
