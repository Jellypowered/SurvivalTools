using System.Collections.Generic;
using PeteTimesSix.ResearchReinvented.Opportunities;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityJobPickers;

public abstract class OpportunityJobPickerBase
{
	public abstract List<JobDef> PickJobs(ResearchOpportunity opportunity);
}
