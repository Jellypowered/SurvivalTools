using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Opportunities;
using PeteTimesSix.ResearchReinvented.OpportunityComps;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityJobPickers;

public class JobPicker_AnalyseInPlaceOrMinified : OpportunityJobPickerBase
{
	private static List<JobDef> InPlaceOnly = new List<JobDef> { JobDefOf_Custom.RR_AnalyseInPlace };

	private static List<JobDef> InPlaceOrMinifiedAtBench = new List<JobDef>
	{
		JobDefOf_Custom.RR_AnalyseInPlace,
		JobDefOf_Custom.RR_Analyse
	};

	private static List<JobDef> AtBenchOnly = new List<JobDef> { JobDefOf_Custom.RR_Analyse };

	public override List<JobDef> PickJobs(ResearchOpportunity opportunity)
	{
		if (!(opportunity.requirement is ROComp_RequiresThing thingRequirement))
		{
			Log.Error($"opportunity {opportunity} def {opportunity.def.defName} had JobPicker_AnalyseInPlaceOrMinified but does not require a thing!");
			return new List<JobDef>();
		}
		HashSet<JobDef> jobs = new HashSet<JobDef>();
		ThingDef[] allThings = thingRequirement.AllThings;
		foreach (ThingDef thingDef in allThings)
		{
			if (thingDef.EverHaulable)
			{
				jobs.AddRange(AtBenchOnly);
			}
			else if (thingDef.Minifiable)
			{
				jobs.AddRange(InPlaceOrMinifiedAtBench);
			}
			else
			{
				jobs.AddRange(InPlaceOnly);
			}
		}
		return jobs.ToList();
	}
}
