using System;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityComps;

public class ROComp_RequiresSchematicWithProject : ResearchOpportunityComp
{
	public ResearchProjectDef projectDef;

	public override string ShortDesc => string.Concat(projectDef?.label);

	public override TaggedString Subject => new TaggedString(projectDef?.label).Colorize(Color.cyan);

	public override bool TargetIsNull => projectDef == null;

	public override bool IsRare => false;

	public override bool IsFreebie => false;

	public override bool IsValid => projectDef != null;

	public override bool MetBy(Def def)
	{
		return projectDef == def;
	}

	public override bool MetBy(Thing thing)
	{
		throw new InvalidOperationException("This should never be called!");
	}

	public ROComp_RequiresSchematicWithProject()
	{
	}

	public ROComp_RequiresSchematicWithProject(ResearchProjectDef targetDef)
	{
		projectDef = targetDef;
	}

	public override void ExposeData()
	{
		base.ExposeData();
		Scribe_Defs.Look(ref projectDef, "projectDef");
	}
}
