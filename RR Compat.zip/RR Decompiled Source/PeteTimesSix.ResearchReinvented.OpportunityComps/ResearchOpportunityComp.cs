using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityComps;

public abstract class ResearchOpportunityComp : IExposable
{
	public abstract string ShortDesc { get; }

	public abstract TaggedString Subject { get; }

	public abstract bool TargetIsNull { get; }

	public abstract bool IsRare { get; }

	public abstract bool IsFreebie { get; }

	public abstract bool IsValid { get; }

	public virtual int AlternateCount => 0;

	public abstract bool MetBy(Def def);

	public abstract bool MetBy(Thing thing);

	public virtual void ListAlts()
	{
	}

	public virtual void ExposeData()
	{
	}
}
