using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityComps;

public class ROComp_RequiresFactionlessPawn : ResearchOpportunityComp
{
	public override string ShortDesc => "outsider";

	public override TaggedString Subject => "outsider";

	public override bool TargetIsNull => true;

	public override bool IsRare => false;

	public override bool IsFreebie => false;

	public override bool IsValid => true;

	public override bool MetBy(Def def)
	{
		return false;
	}

	public override bool MetBy(Thing thing)
	{
		if (thing is Pawn pawn)
		{
			if (pawn.Faction != null)
			{
				return pawn.Faction.temporary;
			}
			return true;
		}
		return false;
	}

	public override void ExposeData()
	{
		base.ExposeData();
	}
}
