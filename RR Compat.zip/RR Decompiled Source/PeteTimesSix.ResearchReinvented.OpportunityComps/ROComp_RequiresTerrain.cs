using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityComps;

public class ROComp_RequiresTerrain : ResearchOpportunityComp
{
	public AlternatesMode altsMode;

	private bool alternatesCached;

	private TerrainDef primaryTerrainDef;

	private TerrainDef[] alternates;

	private TerrainDef[] allTerrains;

	public TerrainDef[] Alternates
	{
		get
		{
			if (!alternatesCached)
			{
				CacheAlternates();
			}
			return alternates;
		}
	}

	public override int AlternateCount
	{
		get
		{
			if (!alternatesCached)
			{
				CacheAlternates();
			}
			TerrainDef[] array = alternates;
			if (array == null)
			{
				return 0;
			}
			return array.Length;
		}
	}

	public TerrainDef[] AllTerrains
	{
		get
		{
			if (allTerrains == null)
			{
				List<TerrainDef> tempList = new List<TerrainDef> { primaryTerrainDef };
				if (Alternates != null)
				{
					tempList.AddRange(Alternates);
				}
				allTerrains = tempList.ToArray();
			}
			return allTerrains;
		}
	}

	public TerrainDef ShownCycledTerrain
	{
		get
		{
			TerrainDef terrainDef = primaryTerrainDef;
			if (AlternateCount > 0 && Time.realtimeSinceStartupAsDouble % 2.0 > 1.0)
			{
				terrainDef = Alternates[(int)(Time.realtimeSinceStartupAsDouble / 2.0 % (double)AlternateCount)];
			}
			return terrainDef;
		}
	}

	public override string ShortDesc => string.Concat(ShownCycledTerrain?.label);

	public override TaggedString Subject => new TaggedString(ShownCycledTerrain?.label).Colorize(Color.cyan);

	public override bool TargetIsNull => primaryTerrainDef == null;

	public override bool IsRare => primaryTerrainDef.HasModExtension<RarityMarker>();

	public override bool IsFreebie => primaryTerrainDef.HasModExtension<FreebieMarker>();

	public override bool IsValid => primaryTerrainDef != null;

	public override bool MetBy(Def def)
	{
		if (!(def is TerrainDef))
		{
			return false;
		}
		if (def == primaryTerrainDef)
		{
			return true;
		}
		if (!alternatesCached)
		{
			CacheAlternates();
		}
		if (alternates != null && alternates.Contains(def))
		{
			return true;
		}
		return false;
	}

	public override bool MetBy(Thing thing)
	{
		return false;
	}

	public override void ListAlts()
	{
		Log.Message("alts for " + primaryTerrainDef.defName + ": " + string.Join(",", alternates.Select((TerrainDef a) => a.defName)));
	}

	public ROComp_RequiresTerrain()
	{
	}

	public ROComp_RequiresTerrain(TerrainDef terrainDef, AlternatesMode altsMode)
	{
		primaryTerrainDef = terrainDef;
		this.altsMode = altsMode;
	}

	public void CacheAlternates()
	{
		switch (altsMode)
		{
		case AlternatesMode.NONE:
			alternates = null;
			break;
		case AlternatesMode.EQUIVALENT:
		{
			if (AlternatesKeeper.alternateEquivalentTerrains.TryGetValue(primaryTerrainDef, out var alts2))
			{
				alternates = alts2;
			}
			break;
		}
		case AlternatesMode.SIMILAR:
		{
			if (AlternatesKeeper.alternateSimilarTerrains.TryGetValue(primaryTerrainDef, out var alts))
			{
				alternates = alts;
			}
			break;
		}
		}
		alternatesCached = true;
	}

	public override void ExposeData()
	{
		base.ExposeData();
		Scribe_Defs.Look(ref primaryTerrainDef, "terrainDef");
		Scribe_Values.Look(ref altsMode, "altsMode", AlternatesMode.NONE);
	}
}
