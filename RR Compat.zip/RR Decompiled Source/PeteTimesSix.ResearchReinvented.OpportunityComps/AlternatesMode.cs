namespace PeteTimesSix.ResearchReinvented.OpportunityComps;

public enum AlternatesMode
{
	NONE,
	EQUIVALENT,
	SIMILAR
}
