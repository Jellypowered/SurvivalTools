using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Rimworld.DefModExtensions;
using RimWorld;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityComps;

public class ROComp_RequiresThing : ResearchOpportunityComp
{
	public AlternatesMode altsMode;

	private bool alternatesCached;

	private ThingDef primaryThingDef;

	private ThingDef[] alternates;

	private ThingDef[] allThings;

	public ThingDef[] Alternates
	{
		get
		{
			if (!alternatesCached)
			{
				CacheAlternates();
			}
			return alternates;
		}
	}

	public override int AlternateCount
	{
		get
		{
			if (!alternatesCached)
			{
				CacheAlternates();
			}
			ThingDef[] array = alternates;
			if (array == null)
			{
				return 0;
			}
			return array.Length;
		}
	}

	public ThingDef[] AllThings
	{
		get
		{
			if (allThings == null)
			{
				List<ThingDef> tempList = new List<ThingDef> { primaryThingDef };
				if (Alternates != null)
				{
					tempList.AddRange(Alternates);
				}
				allThings = tempList.ToArray();
			}
			return allThings;
		}
	}

	public ThingDef ShownCycledThing
	{
		get
		{
			ThingDef thingDef = primaryThingDef;
			if (AlternateCount > 0 && Time.realtimeSinceStartupAsDouble % 2.0 > 1.0)
			{
				thingDef = Alternates[(int)(Time.realtimeSinceStartupAsDouble / 2.0 % (double)AlternateCount)];
			}
			return thingDef;
		}
	}

	public ThingDef PrimaryThingDef => primaryThingDef;

	public override string ShortDesc => string.Concat(ShownCycledThing?.label);

	public override TaggedString Subject => new TaggedString(ShownCycledThing?.label).Colorize(Color.cyan);

	public override bool TargetIsNull => primaryThingDef == null;

	public override bool IsRare => primaryThingDef.HasModExtension<RarityMarker>();

	public override bool IsFreebie => primaryThingDef.HasModExtension<FreebieMarker>();

	public override bool IsValid => primaryThingDef != null;

	public override bool MetBy(Def def)
	{
		if (!(def is ThingDef))
		{
			return false;
		}
		if (def == primaryThingDef)
		{
			return true;
		}
		if (!alternatesCached)
		{
			CacheAlternates();
		}
		if (alternates != null && alternates.Contains(def))
		{
			return true;
		}
		return false;
	}

	public override bool MetBy(Thing thing)
	{
		ThingDef def = thing.def;
		if (thing is MinifiedThing minified)
		{
			def = minified.InnerThing.def;
		}
		return MetBy(def);
	}

	public override void ListAlts()
	{
		Log.Message("alts for " + primaryThingDef.defName + ": " + string.Join(",", alternates.Select((ThingDef a) => a.defName)));
	}

	public ROComp_RequiresThing()
	{
	}

	public ROComp_RequiresThing(ThingDef targetDef, AlternatesMode altsMode)
	{
		primaryThingDef = targetDef;
		this.altsMode = altsMode;
		CacheAlternates();
	}

	public void CacheAlternates()
	{
		switch (altsMode)
		{
		case AlternatesMode.NONE:
			alternates = null;
			break;
		case AlternatesMode.EQUIVALENT:
		{
			if (AlternatesKeeper.alternatesEquivalent.TryGetValue(primaryThingDef, out var alts2))
			{
				alternates = alts2;
			}
			break;
		}
		case AlternatesMode.SIMILAR:
		{
			if (AlternatesKeeper.alternatesSimilar.TryGetValue(primaryThingDef, out var alts))
			{
				alternates = alts;
			}
			break;
		}
		}
		alternatesCached = true;
	}

	public override void ExposeData()
	{
		base.ExposeData();
		Scribe_Defs.Look(ref primaryThingDef, "targetDef");
		Scribe_Values.Look(ref altsMode, "altsMode", AlternatesMode.NONE);
	}
}
