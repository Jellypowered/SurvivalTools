using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.OpportunityComps;

public class ROComp_RequiresNothing : ResearchOpportunityComp
{
	public override string ShortDesc => "Generic research";

	public override TaggedString Subject => new TaggedString("none").Colorize(Color.red);

	public override bool TargetIsNull => false;

	public override bool IsRare => false;

	public override bool IsFreebie => false;

	public override bool IsValid => true;

	public override bool MetBy(Def def)
	{
		return false;
	}

	public override bool MetBy(Thing thing)
	{
		return false;
	}
}
