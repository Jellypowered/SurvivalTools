using HarmonyLib;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Opportunities;
using Verse;

namespace PeteTimesSix.ResearchReinvented.HarmonyPatches.Prot;

[HarmonyPatch(typeof(DesignationCategoryDef), "Visible", MethodType.Getter)]
public static class DesignationCategoryDef_Visible_Patches
{
	[HarmonyPostfix]
	public static void Postfix(DesignationCategoryDef __instance, ref bool __result)
	{
		if (__result || __instance.researchPrerequisites == null)
		{
			return;
		}
		foreach (ResearchProjectDef researchPrerequisiteProject in __instance.researchPrerequisites)
		{
			if (!researchPrerequisiteProject.IsFinished)
			{
				if (researchPrerequisiteProject != Find.ResearchManager.GetProject())
				{
					return;
				}
				OpportunityAvailability prototypingAvailability = ResearchOpportunityCategoryDefOf.Prototyping.GetCurrentAvailability(researchPrerequisiteProject);
				if (prototypingAvailability != OpportunityAvailability.Available && prototypingAvailability != OpportunityAvailability.Finished && prototypingAvailability != OpportunityAvailability.CategoryFinished)
				{
					return;
				}
			}
		}
		__result = true;
	}
}
