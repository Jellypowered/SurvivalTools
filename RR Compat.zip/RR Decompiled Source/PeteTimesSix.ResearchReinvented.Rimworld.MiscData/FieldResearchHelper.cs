using System.Collections.Generic;
using System.Linq;
using PeteTimesSix.ResearchReinvented.DefOfs;
using PeteTimesSix.ResearchReinvented.Rimworld.Comps;
using RimWorld;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.MiscData;

public class FieldResearchHelper
{
	public static IEnumerable<ThingWithComps> GetValidResearchKits(Pawn pawn, ResearchProjectDef project)
	{
		if (pawn?.apparel?.WornApparel == null)
		{
			return Enumerable.Empty<ThingWithComps>();
		}
		return from a in pawn.apparel.WornApparel
			where a.TryGetComp<Comp_ResearchKit>() != null
			where a.GetComp<Comp_ResearchKit>().MeetsProjectRequirements(project)
			select a;
	}

	public static float GetFieldResearchSpeedFactor(Pawn pawn, ResearchProjectDef project = null)
	{
		float localFactor = pawn.GetStatValue(StatDefOf_Custom.FieldResearchSpeedMultiplier);
		float bestRemote = -1f;
		ThingWithComps bestRemoteKit = BestRemoteResearchKit(pawn, project);
		if (bestRemoteKit != null)
		{
			bestRemote = bestRemoteKit.GetComp<Comp_ResearchKit>().GetRemoteResearchSpeedFactor(project);
		}
		if (bestRemote >= 1f)
		{
			localFactor *= bestRemote;
		}
		return localFactor;
	}

	private static ThingWithComps BestRemoteResearchKit(Pawn pawn, ResearchProjectDef project = null)
	{
		IEnumerable<Apparel> remoteResearchKits = pawn.apparel.WornApparel.Where(delegate(Apparel a)
		{
			Comp_ResearchKit comp_ResearchKit = a.TryGetComp<Comp_ResearchKit>();
			return comp_ResearchKit != null && comp_ResearchKit.Props.remotesThrough != null;
		});
		if (remoteResearchKits.Any())
		{
			return remoteResearchKits.OrderByDescending((Apparel kit) => kit.GetComp<Comp_ResearchKit>().GetRemoteResearchSpeedFactor(project)).First();
		}
		return null;
	}

	public static EffecterDef GetResearchEffect(Pawn pawn)
	{
		IEnumerable<Apparel> researchKits = pawn.apparel.WornApparel.Where((Apparel a) => a.TryGetComp<Comp_ResearchKit>() != null);
		if (!researchKits.Any())
		{
			return EffecterDefOf_Custom.RR_NoResearchKitEffect;
		}
		return researchKits.OrderBy((Apparel k) => k.GetComp<Comp_ResearchKit>().GetTotalResearchSpeedFactor()).First().GetComp<Comp_ResearchKit>()
			.Props.fieldworkEffect;
	}
}
