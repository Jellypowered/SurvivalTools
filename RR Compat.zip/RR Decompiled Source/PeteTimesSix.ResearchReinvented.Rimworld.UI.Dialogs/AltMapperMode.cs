namespace PeteTimesSix.ResearchReinvented.Rimworld.UI.Dialogs;

public enum AltMapperMode
{
	ALL_THINGS,
	BUILDABLE_THINGS,
	CRAFTABLE_THINGS,
	PLANTS,
	ALL_TERRAINS,
	BUILDABLE_TERRAINS,
	RECIPES
}
