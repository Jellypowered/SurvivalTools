using System;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.UI.Dialogs;

public class Dialog_FixupSettingsChange : Dialog_Confirm
{
	public Dialog_FixupSettingsChange(string title, Action onConfirm)
		: base(title, onConfirm)
	{
	}
}
