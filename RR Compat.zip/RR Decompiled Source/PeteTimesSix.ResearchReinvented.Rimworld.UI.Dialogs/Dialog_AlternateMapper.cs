using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PeteTimesSix.ResearchReinvented.Managers;
using PeteTimesSix.ResearchReinvented.Utilities;
using RimWorld;
using UnityEngine;
using Verse;

namespace PeteTimesSix.ResearchReinvented.Rimworld.UI.Dialogs;

public class Dialog_AlternateMapper : Window
{
	private float viewHeight;

	private Def selectedDef;

	private Def selectedAlternateDef;

	private HashSet<ThingDef> newAlternatesEquivalentForSelected = new HashSet<ThingDef>();

	private HashSet<TerrainDef> newAlternateTerrainsEquivalentForSelected = new HashSet<TerrainDef>();

	private HashSet<RecipeDef> newAlternateRecipesEquivalentForSelected = new HashSet<RecipeDef>();

	private HashSet<ThingDef> newAlternateSimilarForSelected = new HashSet<ThingDef>();

	private HashSet<TerrainDef> newAlternateTerrainSimilarForSelected = new HashSet<TerrainDef>();

	private HashSet<RecipeDef> newAlternateRecipesSimilarForSelected = new HashSet<RecipeDef>();

	private AltMapperMode mode;

	private List<Def> originalsDefs;

	private List<Def> alternatesDefs;

	private QuickSearchWidget searchWidgetOriginal = new QuickSearchWidget();

	private QuickSearchWidget searchWidgetAlternate = new QuickSearchWidget();

	public Vector2 scrollPosOriginal = new Vector2(0f, 0f);

	public float sizeCacheOriginal;

	public Vector2 scrollPosAlternate = new Vector2(0f, 0f);

	public float sizeCacheAlternate;

	public const float SCROLLBAR_WIDTH = 18f;

	public const float ICON_SIZE = 40f;

	public override Vector2 InitialSize => new Vector2(Mathf.Min(1000f, Verse.UI.screenWidth), Mathf.Min(1000f, Verse.UI.screenHeight));

	public Dialog_AlternateMapper()
	{
		forcePause = true;
		doCloseX = true;
		doCloseButton = true;
		closeOnClickedOutside = true;
		absorbInputAroundWindow = true;
		UpdateDefsFilter();
	}

	public override void PostClose()
	{
		base.PostClose();
	}

	public override void DoWindowContents(Rect inRect)
	{
		inRect.height -= Window.CloseButSize.y;
		inRect.y += Window.CloseButSize.y;
		Listing_Standard listingStandard = new Listing_Standard();
		listingStandard.Begin(inRect);
		listingStandard.EnumSelector(null, ref mode, "", "_tooltip", null, UpdateDefsFilter);
		Rect buttonRect = listingStandard.GetRect(25f);
		if (Widgets.ButtonText(buttonRect, "Generate alternates XML"))
		{
			GenerateAlternatesXML();
		}
		Rect labelsRect = listingStandard.GetRect(25f);
		Widgets.Label(labelsRect.RightPartPixels(160f).LeftHalf(), "Similar");
		Widgets.Label(labelsRect.RightPartPixels(160f).RightHalf(), "Equivalent");
		Rect restRect = listingStandard.GetRect(inRect.height - listingStandard.CurHeight);
		Rect searchRect = restRect.TopPartPixels(25f);
		Rect listsRect = restRect.BottomPartPixels(restRect.height - 25f);
		searchWidgetOriginal.OnGUI(searchRect.LeftHalf(), UpdateFilterOriginal, UpdateFilterOriginal);
		DrawDefOriginalsListing(listsRect.LeftHalf(), originalsDefs);
		if (selectedDef != null)
		{
			searchWidgetAlternate.OnGUI(searchRect.RightHalf(), UpdateFilterAlternate, UpdateFilterAlternate);
			DrawDefAlternatesListing(listsRect.RightHalf(), alternatesDefs);
		}
		listingStandard.End();
	}

	private IEnumerable<ThingDef> ReasonableThingDefs()
	{
		return DefDatabase<ThingDef>.AllDefsListForReading.Where((ThingDef d) => !d.IsBlueprint && !d.IsFrame && !d.IsFilth && d.mote == null && d.projectile == null && d.defName != "Flashstorm");
	}

	private void UpdateDefsFilter()
	{
		switch (mode)
		{
		case AltMapperMode.ALL_THINGS:
			alternatesDefs = ReasonableThingDefs().Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			originalsDefs = ReasonableThingDefs().Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			break;
		case AltMapperMode.BUILDABLE_THINGS:
			alternatesDefs = ReasonableThingDefs().Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			originalsDefs = (from d in ReasonableThingDefs()
				where d?.BuildableByPlayer ?? false
				select d).Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			break;
		case AltMapperMode.CRAFTABLE_THINGS:
		{
			alternatesDefs = ReasonableThingDefs().Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			List<RecipeDef> recipeDefs = DefDatabase<RecipeDef>.AllDefsListForReading;
			HashSet<ThingDef> recipeProducts = new HashSet<ThingDef>();
			foreach (RecipeDef recipe in recipeDefs)
			{
				if (recipe.products == null)
				{
					continue;
				}
				foreach (ThingDefCountClass product in recipe.products)
				{
					recipeProducts.Add(product.thingDef);
				}
			}
			originalsDefs = ((IEnumerable<ThingDef>)recipeProducts).Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			break;
		}
		case AltMapperMode.PLANTS:
			alternatesDefs = ReasonableThingDefs().Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			originalsDefs = (from d in ReasonableThingDefs()
				where d != null && d.plant != null
				select d).Select((Func<ThingDef, Def>)((ThingDef td) => td)).ToList();
			break;
		case AltMapperMode.ALL_TERRAINS:
			alternatesDefs = ((IEnumerable<TerrainDef>)DefDatabase<TerrainDef>.AllDefsListForReading).Select((Func<TerrainDef, Def>)((TerrainDef td) => td)).ToList();
			originalsDefs = ((IEnumerable<TerrainDef>)DefDatabase<TerrainDef>.AllDefsListForReading).Select((Func<TerrainDef, Def>)((TerrainDef td) => td)).ToList();
			break;
		case AltMapperMode.BUILDABLE_TERRAINS:
			alternatesDefs = ((IEnumerable<TerrainDef>)DefDatabase<TerrainDef>.AllDefsListForReading).Select((Func<TerrainDef, Def>)((TerrainDef td) => td)).ToList();
			originalsDefs = DefDatabase<TerrainDef>.AllDefsListForReading.Where((TerrainDef d) => d?.BuildableByPlayer ?? false).Select((Func<TerrainDef, Def>)((TerrainDef td) => td)).ToList();
			break;
		case AltMapperMode.RECIPES:
			alternatesDefs = ((IEnumerable<RecipeDef>)DefDatabase<RecipeDef>.AllDefsListForReading).Select((Func<RecipeDef, Def>)((RecipeDef td) => td)).ToList();
			originalsDefs = ((IEnumerable<RecipeDef>)DefDatabase<RecipeDef>.AllDefsListForReading).Select((Func<RecipeDef, Def>)((RecipeDef td) => td)).ToList();
			break;
		}
	}

	private void GenerateAlternatesXML()
	{
		if (selectedDef == null)
		{
			Log.Warning("RR: Selected def is null!");
			return;
		}
		if (selectedDef.modContentPack == null)
		{
			Log.Warning("RR: Selected def " + selectedDef.defName + " modContentPack is null!");
		}
		HashSet<string> requiredPackageIds = new HashSet<string>();
		CheckForMissingModContentPacks(newAlternatesEquivalentForSelected, "equivalent alts");
		CheckForMissingModContentPacks(newAlternateTerrainsEquivalentForSelected, "equivalent terrain alts");
		CheckForMissingModContentPacks(newAlternateRecipesEquivalentForSelected, "equivalent recipe alts");
		CheckForMissingModContentPacks(newAlternateSimilarForSelected, "similar alts");
		CheckForMissingModContentPacks(newAlternateTerrainSimilarForSelected, "similar terrain alts");
		CheckForMissingModContentPacks(newAlternateRecipesSimilarForSelected, "similar recipe alts");
		HashSet<Def> allAlts = new HashSet<Def>();
		allAlts.AddRange(newAlternatesEquivalentForSelected);
		allAlts.AddRange(newAlternateTerrainsEquivalentForSelected);
		allAlts.AddRange(newAlternateRecipesEquivalentForSelected);
		allAlts.AddRange(newAlternateSimilarForSelected);
		allAlts.AddRange(newAlternateTerrainSimilarForSelected);
		allAlts.AddRange(newAlternateRecipesSimilarForSelected);
		int combinedHash = allAlts.Select((Def td) => td.defNameHash).Aggregate((int hash, int acc) => HashCode.Combine<int, int>(hash, acc));
		StringBuilder result = new StringBuilder("\t<PeteTimesSix.ResearchReinvented.Defs.AlternateResearchSubjectsDef>\n");
		result.Append($"\t\t<defName>RR_alts_{combinedHash}_{selectedDef.defName}</defName>\n");
		if (selectedDef is ThingDef)
		{
			AddListOfDefs(result, new Def[1] { selectedDef }, "originals");
		}
		else if (selectedDef is TerrainDef)
		{
			AddListOfDefs(result, new Def[1] { selectedDef }, "originalTerrains");
		}
		else if (selectedDef is RecipeDef)
		{
			AddListOfDefs(result, new Def[1] { selectedDef }, "originalRecipes");
		}
		if (newAlternatesEquivalentForSelected.Count > 0)
		{
			AddListOfDefs(result, newAlternatesEquivalentForSelected, "alternatesEquivalent");
		}
		if (newAlternateTerrainsEquivalentForSelected.Count > 0)
		{
			AddListOfDefs(result, newAlternateTerrainsEquivalentForSelected, "alternateEquivalentTerrains");
		}
		if (newAlternateRecipesEquivalentForSelected.Count > 0)
		{
			AddListOfDefs(result, newAlternateRecipesEquivalentForSelected, "alternateEquivalentRecipes");
		}
		if (newAlternateSimilarForSelected.Count > 0)
		{
			AddListOfDefs(result, newAlternateSimilarForSelected, "alternatesSimilar");
		}
		if (newAlternateTerrainSimilarForSelected.Count > 0)
		{
			AddListOfDefs(result, newAlternateTerrainSimilarForSelected, "alternateSimilarTerrains");
		}
		if (newAlternateRecipesSimilarForSelected.Count > 0)
		{
			AddListOfDefs(result, newAlternateRecipesSimilarForSelected, "alternateSimilarRecipes");
		}
		result.Append("\t</PeteTimesSix.ResearchReinvented.Defs.AlternateResearchSubjectsDef>\n\n");
		GUIUtility.systemCopyBuffer = result.ToString();
		Messages.Message("Copied to clipboard", MessageTypeDefOf.NeutralEvent, historical: false);
	}

	private void AddListOfDefs(StringBuilder result, IEnumerable<Def> defs, string fieldName)
	{
		result.Append("\t\t<" + fieldName + ">\n");
		foreach (Def alt in defs)
		{
			ModContentPack modContentPack = alt.modContentPack;
			if (modContentPack == null || modContentPack.IsCoreMod)
			{
				result.Append("\t\t\t<li>" + alt.defName + "</li>\n");
				continue;
			}
			result.Append("\t\t\t<li MayRequire=\"" + alt.modContentPack.PackageId + "\">" + alt.defName + "</li>\n");
		}
		result.Append("\t\t</" + fieldName + ">\n");
	}

	private void CheckForMissingModContentPacks(IEnumerable<Def> collection, string label)
	{
		IEnumerable<string> noModContentPackDefs = from a in collection
			where a.modContentPack == null
			select a.defName;
		if (noModContentPackDefs.Any())
		{
			Log.Warning("RR: Missing modContentPack for " + label + ": " + string.Join(",", noModContentPackDefs));
		}
	}

	private void DrawDefOriginalsListing(Rect listRect, IEnumerable<Def> defsToDraw)
	{
		Rect internalRect = new Rect(listRect.x, listRect.y, listRect.width, listRect.height).Rounded();
		internalRect.height = sizeCacheOriginal;
		bool hasScrollbar = listRect.height < internalRect.height;
		if (hasScrollbar)
		{
			internalRect.width -= 18f;
		}
		Widgets.BeginScrollView(listRect, ref scrollPosOriginal, internalRect);
		float heightTotal = 0f;
		foreach (Def def in defsToDraw.Where((Def td) => searchWidgetOriginal.filter.Matches(td.label) || searchWidgetOriginal.filter.Matches(td.defName)))
		{
			if (def is ThingDef thingDef)
			{
				DrawOriginalThingEntry(listRect, internalRect, hasScrollbar, ref heightTotal, thingDef);
			}
			else if (def is TerrainDef terrainDef)
			{
				DrawOriginalTerrainEntry(listRect, internalRect, hasScrollbar, ref heightTotal, terrainDef);
			}
			else if (def is RecipeDef recipeDef)
			{
				DrawOriginalRecipeEntry(listRect, internalRect, hasScrollbar, ref heightTotal, recipeDef);
			}
			else
			{
				Log.Warning($"RR: unexpected def type '{def.GetType()}' for : {def.defName}");
			}
		}
		sizeCacheOriginal = heightTotal;
		Widgets.EndScrollView();
	}

	private void DrawOriginalThingEntry(Rect wrapperRect, Rect internalRect, bool hasScrollbar, ref float heightTotal, ThingDef thingDef)
	{
		Rect iconRect = new Rect(internalRect.x, internalRect.y + heightTotal, 40f, 40f).Rounded();
		Rect labelRect = new Rect(internalRect.x + 40f, internalRect.y + heightTotal, internalRect.width - 40f, 40f).Rounded();
		ResearchWidgets.ThingDefIcon(iconRect, thingDef);
		heightTotal = DrawOriginalSelectButton(heightTotal, thingDef, labelRect);
	}

	private void DrawOriginalTerrainEntry(Rect wrapperRect, Rect internalRect, bool hasScrollbar, ref float heightTotal, TerrainDef terrainDef)
	{
		Rect iconRect = new Rect(internalRect.x, internalRect.y + heightTotal, 40f, 40f).Rounded();
		Rect labelRect = new Rect(internalRect.x + 40f, internalRect.y + heightTotal, internalRect.width - 40f, 40f).Rounded();
		ResearchWidgets.TerrainDefIcon(iconRect, terrainDef);
		heightTotal = DrawOriginalSelectButton(heightTotal, terrainDef, labelRect);
	}

	private void DrawOriginalRecipeEntry(Rect wrapperRect, Rect internalRect, bool hasScrollbar, ref float heightTotal, RecipeDef recipeDef)
	{
		Rect iconRect = new Rect(internalRect.x, internalRect.y + heightTotal, 40f, 40f).Rounded();
		Rect labelRect = new Rect(internalRect.x + 40f, internalRect.y + heightTotal, internalRect.width - 40f, 40f).Rounded();
		ResearchWidgets.RecipeDefIcon(iconRect, recipeDef);
		heightTotal = DrawOriginalSelectButton(heightTotal, recipeDef, labelRect);
	}

	private float DrawOriginalSelectButton(float heightTotal, Def def, Rect labelRect)
	{
		if (def == selectedDef)
		{
			GUI.color = Color.green;
		}
		else if (selectedAlternateDef != null && AlternatesForDefContain(def, selectedAlternateDef))
		{
			GUI.color = Color.cyan;
		}
		if (Widgets.ButtonText(labelRect, def.defName + " / " + def.LabelCap))
		{
			if (selectedDef != def)
			{
				selectedDef = def;
			}
			else
			{
				selectedDef = null;
			}
			newAlternatesEquivalentForSelected.Clear();
			newAlternateTerrainsEquivalentForSelected.Clear();
			newAlternateRecipesEquivalentForSelected.Clear();
			newAlternateSimilarForSelected.Clear();
			newAlternateTerrainSimilarForSelected.Clear();
			newAlternateRecipesSimilarForSelected.Clear();
		}
		GUI.color = Color.white;
		heightTotal += 40f;
		return heightTotal;
	}

	private bool AlternatesForDefContain(Def def, Def candidate)
	{
		if (def is ThingDef)
		{
			if (!AlternatesKeeper.alternatesEquivalent.TryGetValue(def as ThingDef, out var alts1) || !alts1.Contains(candidate))
			{
				if (AlternatesKeeper.alternatesSimilar.TryGetValue(def as ThingDef, out var alts2))
				{
					return alts2.Contains(candidate);
				}
				return false;
			}
			return true;
		}
		if (def is TerrainDef)
		{
			if (!AlternatesKeeper.alternateEquivalentTerrains.TryGetValue(def as TerrainDef, out var alts3) || !alts3.Contains(candidate))
			{
				if (AlternatesKeeper.alternateSimilarTerrains.TryGetValue(def as TerrainDef, out var alts4))
				{
					return alts4.Contains(candidate);
				}
				return false;
			}
			return true;
		}
		if (def is RecipeDef)
		{
			if (!AlternatesKeeper.alternateEquivalentRecipes.TryGetValue(def as RecipeDef, out var alts5) || !alts5.Contains(candidate))
			{
				if (AlternatesKeeper.alternateSimilarRecipes.TryGetValue(def as RecipeDef, out var alts6))
				{
					return alts6.Contains(candidate);
				}
				return false;
			}
			return true;
		}
		return false;
	}

	private void DrawDefAlternatesListing(Rect listRect, IEnumerable<Def> defsToDraw)
	{
		Rect internalRect = new Rect(listRect.x, listRect.y, listRect.width, listRect.height).Rounded();
		internalRect.height = sizeCacheAlternate;
		bool hasScrollbar = listRect.height < internalRect.height;
		if (hasScrollbar)
		{
			internalRect.width -= 18f;
		}
		Widgets.BeginScrollView(listRect, ref scrollPosAlternate, internalRect);
		float heightTotal = 0f;
		foreach (Def def in defsToDraw.Where((Def td) => td != selectedDef && (searchWidgetAlternate.filter.Matches(td.label) || searchWidgetAlternate.filter.Matches(td.defName))))
		{
			if (def is ThingDef thingDef)
			{
				DrawAlternateThingEntry(listRect, internalRect, hasScrollbar, ref heightTotal, thingDef);
			}
			else if (def is TerrainDef terrainDef)
			{
				DrawAlternateTerrainEntry(listRect, internalRect, hasScrollbar, ref heightTotal, terrainDef);
			}
			else if (def is RecipeDef recipeDef)
			{
				DrawAlternateRecipeEntry(listRect, internalRect, hasScrollbar, ref heightTotal, recipeDef);
			}
			else
			{
				Log.Warning($"RR: unexpected def type '{def.GetType()}' for : {def.defName}");
			}
		}
		sizeCacheAlternate = heightTotal;
		Widgets.EndScrollView();
	}

	private void DrawAlternateThingEntry(Rect wrapperRect, Rect internalRect, bool hasScrollbar, ref float heightTotal, ThingDef thingDef)
	{
		Rect iconRect = new Rect(internalRect.x, internalRect.y + heightTotal, 40f, 40f).Rounded();
		Rect labelRect = new Rect(internalRect.x + 40f, internalRect.y + heightTotal, internalRect.width - 40f, 40f).Rounded();
		ResearchWidgets.ThingDefIcon(iconRect, thingDef);
		heightTotal = DrawAlternateCheckbox(internalRect, hasScrollbar, heightTotal, thingDef, labelRect);
	}

	private void DrawAlternateTerrainEntry(Rect wrapperRect, Rect internalRect, bool hasScrollbar, ref float heightTotal, TerrainDef terrainDef)
	{
		Rect iconRect = new Rect(internalRect.x, internalRect.y + heightTotal, 40f, 40f).Rounded();
		Rect labelRect = new Rect(internalRect.x + 40f, internalRect.y + heightTotal, internalRect.width - 40f, 40f).Rounded();
		ResearchWidgets.TerrainDefIcon(iconRect, terrainDef);
		heightTotal = DrawAlternateCheckbox(internalRect, hasScrollbar, heightTotal, terrainDef, labelRect);
	}

	private void DrawAlternateRecipeEntry(Rect wrapperRect, Rect internalRect, bool hasScrollbar, ref float heightTotal, RecipeDef recipeDef)
	{
		Rect iconRect = new Rect(internalRect.x, internalRect.y + heightTotal, 40f, 40f).Rounded();
		Rect labelRect = new Rect(internalRect.x + 40f, internalRect.y + heightTotal, internalRect.width - 40f, 40f).Rounded();
		ResearchWidgets.RecipeDefIcon(iconRect, recipeDef);
		heightTotal = DrawAlternateCheckbox(internalRect, hasScrollbar, heightTotal, recipeDef, labelRect);
	}

	private float DrawAlternateCheckbox(Rect internalRect, bool hasScrollbar, float heightTotal, Def def, Rect labelRect)
	{
		if (selectedDef == null)
		{
			return 0f;
		}
		if (def == selectedAlternateDef)
		{
			GUI.color = Color.green;
		}
		if (Widgets.ButtonTextSubtle(labelRect, def.defName + " / " + def.LabelCap))
		{
			if (selectedAlternateDef == def)
			{
				selectedAlternateDef = null;
			}
			else
			{
				selectedAlternateDef = def;
			}
		}
		GUI.color = Color.white;
		Rect checkboxAncestorRect = new Rect(internalRect.x + internalRect.width - (80f + (hasScrollbar ? 18f : 0f)), internalRect.y + heightTotal, 40f, 40f).Rounded();
		Rect checkboxRect = new Rect(internalRect.x + internalRect.width - (40f + (hasScrollbar ? 18f : 0f)), internalRect.y + heightTotal, 40f, 40f).Rounded();
		if (def is ThingDef thingDef)
		{
			if (newAlternateSimilarForSelected.Contains(thingDef))
			{
				if (Widgets.CheckboxMulti(checkboxAncestorRect, MultiCheckboxState.On, paintable: true) != MultiCheckboxState.On)
				{
					newAlternateSimilarForSelected.Remove(thingDef);
				}
			}
			else
			{
				ThingDef[] alts;
				MultiCheckboxState state = ((!AlternatesKeeper.alternatesSimilar.TryGetValue(selectedDef as ThingDef, out alts) || !alts.Contains(def)) ? MultiCheckboxState.Off : MultiCheckboxState.Partial);
				MultiCheckboxState retVal = Widgets.CheckboxMulti(checkboxAncestorRect, state, paintable: true);
				if (retVal != state)
				{
					newAlternateSimilarForSelected.Add(thingDef);
				}
			}
			if (newAlternatesEquivalentForSelected.Contains(thingDef))
			{
				if (Widgets.CheckboxMulti(checkboxRect, MultiCheckboxState.On, paintable: true) != MultiCheckboxState.On)
				{
					newAlternatesEquivalentForSelected.Remove(thingDef);
				}
			}
			else
			{
				ThingDef[] alts2;
				MultiCheckboxState state2 = ((!AlternatesKeeper.alternatesEquivalent.TryGetValue(selectedDef as ThingDef, out alts2) || !alts2.Contains(def)) ? MultiCheckboxState.Off : MultiCheckboxState.Partial);
				MultiCheckboxState retVal2 = Widgets.CheckboxMulti(checkboxRect, state2, paintable: true);
				if (retVal2 != state2)
				{
					newAlternatesEquivalentForSelected.Add(thingDef);
				}
			}
		}
		else if (def is TerrainDef terrainDef)
		{
			if (newAlternateTerrainSimilarForSelected.Contains(terrainDef))
			{
				if (Widgets.CheckboxMulti(checkboxAncestorRect, MultiCheckboxState.On, paintable: true) != MultiCheckboxState.On)
				{
					newAlternateTerrainSimilarForSelected.Remove(terrainDef);
				}
			}
			else
			{
				TerrainDef[] alts3;
				MultiCheckboxState state3 = ((!AlternatesKeeper.alternateSimilarTerrains.TryGetValue(selectedDef as TerrainDef, out alts3) || !alts3.Contains(def)) ? MultiCheckboxState.Off : MultiCheckboxState.Partial);
				MultiCheckboxState retVal3 = Widgets.CheckboxMulti(checkboxAncestorRect, state3, paintable: true);
				if (retVal3 != state3)
				{
					newAlternateTerrainSimilarForSelected.Add(terrainDef);
				}
			}
			if (newAlternateTerrainsEquivalentForSelected.Contains(terrainDef))
			{
				if (Widgets.CheckboxMulti(checkboxRect, MultiCheckboxState.On, paintable: true) != MultiCheckboxState.On)
				{
					newAlternateTerrainsEquivalentForSelected.Remove(terrainDef);
				}
			}
			else
			{
				TerrainDef[] alts4;
				MultiCheckboxState state4 = ((!AlternatesKeeper.alternateEquivalentTerrains.TryGetValue(selectedDef as TerrainDef, out alts4) || !alts4.Contains(def)) ? MultiCheckboxState.Off : MultiCheckboxState.Partial);
				MultiCheckboxState retVal4 = Widgets.CheckboxMulti(checkboxRect, state4, paintable: true);
				if (retVal4 != state4)
				{
					newAlternateTerrainsEquivalentForSelected.Add(terrainDef);
				}
			}
		}
		else if (def is RecipeDef recipeDef)
		{
			if (newAlternateRecipesSimilarForSelected.Contains(recipeDef))
			{
				if (Widgets.CheckboxMulti(checkboxAncestorRect, MultiCheckboxState.On, paintable: true) != MultiCheckboxState.On)
				{
					newAlternateRecipesSimilarForSelected.Remove(recipeDef);
				}
			}
			else
			{
				RecipeDef[] alts5;
				MultiCheckboxState state5 = ((!AlternatesKeeper.alternateSimilarRecipes.TryGetValue(selectedDef as RecipeDef, out alts5) || !alts5.Contains(def)) ? MultiCheckboxState.Off : MultiCheckboxState.Partial);
				MultiCheckboxState retVal5 = Widgets.CheckboxMulti(checkboxAncestorRect, state5, paintable: true);
				if (retVal5 != state5)
				{
					newAlternateRecipesSimilarForSelected.Add(recipeDef);
				}
			}
			if (newAlternateRecipesEquivalentForSelected.Contains(recipeDef))
			{
				if (Widgets.CheckboxMulti(checkboxRect, MultiCheckboxState.On, paintable: true) != MultiCheckboxState.On)
				{
					newAlternateRecipesEquivalentForSelected.Remove(recipeDef);
				}
			}
			else
			{
				RecipeDef[] alts6;
				MultiCheckboxState state6 = ((!AlternatesKeeper.alternateEquivalentRecipes.TryGetValue(selectedDef as RecipeDef, out alts6) || !alts6.Contains(def)) ? MultiCheckboxState.Off : MultiCheckboxState.Partial);
				MultiCheckboxState retVal6 = Widgets.CheckboxMulti(checkboxRect, state6, paintable: true);
				if (retVal6 != state6)
				{
					newAlternateRecipesEquivalentForSelected.Add(recipeDef);
				}
			}
		}
		heightTotal += 40f;
		return heightTotal;
	}

	private void UpdateFilterOriginal()
	{
	}

	private void UpdateFilterAlternate()
	{
	}
}
