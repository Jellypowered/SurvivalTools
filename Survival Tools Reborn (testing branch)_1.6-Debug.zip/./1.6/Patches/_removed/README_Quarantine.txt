This directory holds deprecated PatchOps quarantined during Phase 9 consolidation.
All functional XML patch files have been removed to prevent RimWorld from attempting to load placeholder PatchOperation nodes.
History:
 - WorkGivers_MiningYieldDigging_Deprecated.xml : removed (MiningYieldDigging demoted to optional)
If reinstating a patch, move it out of _removed and restore .xml extension explicitly.
